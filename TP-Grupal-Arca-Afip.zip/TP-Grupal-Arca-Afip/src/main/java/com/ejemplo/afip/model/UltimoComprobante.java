package com.ejemplo.afip.model;

import java.util.List;

public record UltimoComprobante(long numero, List<String> errores, List<String> eventos) {
    public boolean tieneErrores() {
        return errores != null && !errores.isEmpty();
    }
}
