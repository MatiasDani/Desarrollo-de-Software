package com.ejemplo.afip;

import com.ejemplo.afip.client.AfipWsaaClient;
import com.ejemplo.afip.client.AfipWsfeClient;
import com.ejemplo.afip.dto.AfipConexionDTO;
import com.ejemplo.afip.dto.AfipEstadoDTO;
import com.ejemplo.afip.dto.MonedasSyncDTO;
import com.ejemplo.afip.model.AfipAuth;
import com.ejemplo.afip.model.CaeResultado;
import com.ejemplo.afip.model.ComprobanteAfip;
import com.ejemplo.afip.model.EstadoServidores;
import com.ejemplo.afip.model.MonedaAfip;
import com.ejemplo.afip.model.UltimoComprobante;
import com.ejemplo.dto.CatalogoDTO;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.repository.TipoMonedaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Service
public class AfipService {
    private static final Logger log = LoggerFactory.getLogger(AfipService.class);
    private static final java.time.ZoneId ZONA_AR = java.time.ZoneId.of("America/Argentina/Buenos_Aires");
    private static final int DIAS_TOLERANCIA_FECHA = 5;

    private final AfipProperties properties;
    private final AfipWsaaClient wsaaClient;
    private final AfipWsfeClient wsfeClient;
    private final TipoMonedaRepository tipoMonedaRepository;

    public AfipService(AfipProperties properties, AfipWsaaClient wsaaClient, AfipWsfeClient wsfeClient,
                       TipoMonedaRepository tipoMonedaRepository) {
        this.properties = properties;
        this.wsaaClient = wsaaClient;
        this.wsfeClient = wsfeClient;
        this.tipoMonedaRepository = tipoMonedaRepository;
    }

    public AfipEstadoDTO estado() {
        boolean habilitado = properties.getModo() != AfipProperties.Modo.DESHABILITADO;
        boolean simulado = properties.esSimulado();
        String mensaje;

        if (!habilitado) {
            mensaje = "La integración con AFIP está deshabilitada (afip.modo=DESHABILITADO).";
        } else if (simulado) {
            mensaje = "Modo SIMULADO: se generan CAE ficticios, sin conectarse a AFIP. " +
                    "Cambiá afip.modo a HOMOLOGACION y configurá las credenciales para emitir de verdad.";
        } else if (!properties.tieneCredenciales()) {
            mensaje = "Modo " + properties.getModo() + ": faltan las credenciales. " +
                    "Configurá afip.pfx-path o afip.certificado-path + afip.clave-path.";
        } else if (properties.cuitNormalizado() == null || properties.cuitNormalizado().length() != 11) {
            mensaje = "Modo " + properties.getModo() + ": el CUIT configurado (afip.cuit) no es válido.";
        } else {
            mensaje = "Modo " + properties.getModo() + ": integración lista para operar contra AFIP.";
        }

        return new AfipEstadoDTO(
                habilitado,
                properties.getModo() == null ? "DESCONOCIDO" : properties.getModo().name(),
                simulado,
                properties.cuitNormalizado(),
                properties.tieneCredenciales(),
                properties.getTipoComprobante(),
                properties.getAlicuotaIva(),
                properties.getWsaaUrl(),
                properties.getWsfeUrl(),
                wsfeClient.clienteActivo(),
                mensaje);
    }

    public AfipConexionDTO probarConexion() {
        String modo = properties.getModo() == null ? "DESCONOCIDO" : properties.getModo().name();

        if (properties.getModo() == AfipProperties.Modo.DESHABILITADO) {
            return new AfipConexionDTO(false, modo, null,
                    "La integración está deshabilitada.");
        }
        if (properties.esSimulado()) {
            return new AfipConexionDTO(true, modo,
                    new EstadoServidores("OK (simulado)", "OK (simulado)", "OK (simulado)"),
                    "Diagnóstico simulado: no se realizó ninguna llamada a AFIP.");
        }

        try {
            EstadoServidores servidores = wsfeClient.dummy();
            return new AfipConexionDTO(servidores.todoOk(), modo, servidores,
                    servidores.todoOk()
                            ? "Conexión con WSFEv1 verificada correctamente."
                            : "AFIP respondió, pero algún servidor no está OK.");
        } catch (AfipException e) {
            return new AfipConexionDTO(false, modo, null, e.getMessage());
        }
    }

    public MonedasSyncDTO sincronizarMonedas() {
        String modo = properties.getModo() == null ? "DESCONOCIDO" : properties.getModo().name();

        if (properties.getModo() == AfipProperties.Modo.DESHABILITADO || properties.esSimulado()) {
            return new MonedasSyncDTO(false, modo,
                    "La sincronización real requiere afip.modo=HOMOLOGACION o PRODUCCION con credenciales. " +
                            "Se mantiene el catálogo local (" + tipoMonedaRepository.count() + " monedas).",
                    0, 0, tipoMonedaRepository.count(), monedas());
        }

        validarConfiguracionReal();
        AfipAuth auth = wsaaClient.obtenerAuth();
        List<MonedaAfip> remotas = wsfeClient.tiposMonedas(auth);

        int nuevas = 0;
        int actualizadas = 0;
        for (MonedaAfip remota : remotas) {
            String codigoAfip = remota.codigo();
            if (codigoAfip == null || codigoAfip.isBlank()) {
                continue;
            }
            TipoMoneda moneda = tipoMonedaRepository.findByCodigoAfip(codigoAfip).orElse(null);
            boolean esNueva = moneda == null;
            if (esNueva) {
                moneda = new TipoMoneda();
                moneda.setCodigoAfip(codigoAfip);
                moneda.setCodigo(MonedasAfip.codigoIso(codigoAfip));
                moneda.setSimbolo(MonedasAfip.simbolo(MonedasAfip.codigoIso(codigoAfip)));
                moneda.setCotizacion("PES".equalsIgnoreCase(codigoAfip) ? 1 : 0);
            }
            moneda.setDenominacion(remota.denominacion());
            tipoMonedaRepository.save(moneda);
            if (esNueva) {
                nuevas++;
            } else {
                actualizadas++;
            }
        }

        String mensaje = "Sincronizadas " + remotas.size() + " monedas desde AFIP ("
                + nuevas + " nuevas, " + actualizadas + " actualizadas).";
        log.info(mensaje);
        return new MonedasSyncDTO(true, modo, mensaje, nuevas, actualizadas,
                tipoMonedaRepository.count(), monedas());
    }

    public List<CatalogoDTO.MonedaItem> monedas() {
        return tipoMonedaRepository.findAll().stream()
                .sorted(Comparator.comparing(TipoMoneda::getCodigo))
                .map(tm -> new CatalogoDTO.MonedaItem(
                        tm.getId(), tm.getCodigo(), tm.getCodigoAfip(),
                        tm.getDenominacion(), tm.getSimbolo(), tm.getCotizacion()))
                .toList();
    }

    public CaeResultado emitir(FacturaVenta factura, Integer tipoComprobanteSolicitado) {
        if (properties.getModo() == AfipProperties.Modo.DESHABILITADO) {
            throw new AfipException("La integración con AFIP está deshabilitada.");
        }
        if (factura == null || factura.getId() == null) {
            throw new AfipException("La factura no existe.");
        }
        if (factura.getCae() != null && !factura.getCae().isBlank()) {
            throw new IllegalStateException("La factura ya tiene un CAE asignado (" + factura.getCae() + ").");
        }
        if ("ANULADA".equalsIgnoreCase(factura.getEstado())) {
            throw new IllegalStateException("No se puede emitir el CAE de una factura anulada.");
        }
        validarFechaComprobante(factura);

        int tipo = resolverTipoComprobante(factura, tipoComprobanteSolicitado);

        if (properties.esSimulado()) {
            return simular(factura, tipo);
        }

        validarConfiguracionReal();

        int puntoVenta = factura.getPuntoVenta().getNumero();
        AfipAuth auth = wsaaClient.obtenerAuth();

        UltimoComprobante ultimo = wsfeClient.ultimoComprobante(auth, puntoVenta, tipo);
        long numero = ultimo.numero() + 1;

        ComprobanteAfip comprobante = construirComprobante(factura, tipo, numero, auth);
        log.info("Solicitando CAE a AFIP: ptoVta={} tipo={} nro={} total={}",
                puntoVenta, tipo, numero, comprobante.importeTotal());

        return wsfeClient.solicitarCae(auth, comprobante);
    }

    public int resolverTipoComprobante(FacturaVenta factura, Integer solicitado) {
        if (solicitado != null && solicitado > 0) {
            return solicitado;
        }
        if (factura.getTipoComprobante() != null && factura.getTipoComprobante() > 0) {
            return factura.getTipoComprobante();
        }
        return properties.getTipoComprobante();
    }

    void validarFechaComprobante(FacturaVenta factura) {
        LocalDate fecha = aLocalDate(factura);
        LocalDate hoy = LocalDate.now(ZONA_AR);
        LocalDate desde = hoy.minusDays(DIAS_TOLERANCIA_FECHA);
        LocalDate hasta = hoy.plusDays(DIAS_TOLERANCIA_FECHA);
        if (fecha.isBefore(desde) || fecha.isAfter(hasta)) {
            throw new IllegalStateException("La fecha de emisión (" + fecha + ") está fuera del rango que acepta AFIP "
                    + "para productos: entre " + desde + " y " + hasta + ". Modificá la fecha de la factura "
                    + "antes de solicitar el CAE.");
        }
    }

    private void validarConfiguracionReal() {
        if (!properties.tieneCredenciales()) {
            throw new AfipException("Faltan credenciales AFIP. Configurá afip.pfx-path o " +
                    "afip.certificado-path + afip.clave-path.");
        }
        String cuit = properties.cuitNormalizado();
        if (cuit == null || cuit.length() != 11) {
            throw new AfipException("Configurá un CUIT válido de 11 dígitos en afip.cuit.");
        }
    }

    private ComprobanteAfip construirComprobante(FacturaVenta factura, int tipo, long numero, AfipAuth auth) {
        Cliente cliente = factura.getCliente();
        String cuitCliente = cliente == null ? null : limpiarNumero(cliente.getCuitCuil());
        boolean tieneCuit = cuitCliente != null && cuitCliente.length() == 11;

        int docTipo = tieneCuit ? 80 : 99;
        long docNro = tieneCuit ? Long.parseLong(cuitCliente) : 0L;

        TipoMoneda moneda = factura.getTipoMoneda();
        String codigoMoneda = codigoAfipDe(moneda);
        double cotizacion = resolverCotizacion(auth, moneda, codigoMoneda);

        int condicionIvaReceptor = factura.getCondicionIva() == null
                ? 5
                : factura.getCondicionIva().getCodigoAfip();

        return new ComprobanteAfip(
                factura.getPuntoVenta().getNumero(),
                tipo,
                numero,
                aLocalDate(factura),
                factura.getImporteTotal(),
                docTipo,
                docNro,
                codigoMoneda,
                cotizacion,
                properties.getAlicuotaIva(),
                tipo == 1 || tipo == 6,
                condicionIvaReceptor);
    }

    private static String codigoAfipDe(TipoMoneda moneda) {
        if (moneda == null) {
            return "PES";
        }
        if (moneda.getCodigoAfip() != null && !moneda.getCodigoAfip().isBlank()) {
            return moneda.getCodigoAfip();
        }
        return MonedasAfip.codigoAfip(moneda.getCodigo());
    }

    private double resolverCotizacion(AfipAuth auth, TipoMoneda moneda, String codigoAfip) {
        if (moneda != null && moneda.getCotizacion() > 0) {
            return moneda.getCotizacion();
        }
        if (codigoAfip == null || "PES".equalsIgnoreCase(codigoAfip)) {
            return 1.0;
        }
        try {
            Double cotizacion = wsfeClient.cotizacion(auth, codigoAfip, LocalDate.now());
            if (cotizacion != null && cotizacion > 0) {
                log.info("WSFEv1: cotización {} = {}", codigoAfip, cotizacion);
                return cotizacion;
            }
        } catch (AfipException e) {
            log.warn("WSFEv1: no se pudo obtener la cotización de {}: {}", codigoAfip, e.getMessage());
        }
        log.warn("WSFEv1: se informa cotización 1.0 para {} (sin dato disponible)", codigoAfip);
        return 1.0;
    }

    private CaeResultado simular(FacturaVenta factura, int tipo) {
        long numero = factura.getNumeroAfip() != null
                ? factura.getNumeroAfip()
                : (factura.getNumero() == null ? 1 : factura.getNumero());

        long base = Math.abs((System.currentTimeMillis() * 31 + numero * 7919)
                % 100_000_000_000_000L);
        String cae = String.format("%014d", base);
        LocalDate vencimiento = aLocalDate(factura).plusDays(10);

        log.info("AFIP SIMULADO: factura={} tipo={} nro={} CAE={}", factura.getId(), tipo, numero, cae);

        return CaeResultado.aprobado(
                cae,
                vencimiento,
                numero,
                tipo,
                "SIMULADO",
                List.of("CAE generado en modo SIMULADO: no se contactó a AFIP. " +
                        "Configurá credenciales y afip.modo=HOMOLOGACION para emitir realmente."));
    }

    private static LocalDate aLocalDate(FacturaVenta factura) {
        if (factura.getFechaEmision() == null) {
            return LocalDate.now();
        }
        return new java.sql.Date(factura.getFechaEmision().getTime()).toLocalDate();
    }

    private static String limpiarNumero(String valor) {
        return valor == null ? null : valor.replaceAll("[^0-9]", "");
    }
}
