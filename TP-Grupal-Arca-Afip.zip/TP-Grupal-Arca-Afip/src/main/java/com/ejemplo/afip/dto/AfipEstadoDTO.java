package com.ejemplo.afip.dto;

public record AfipEstadoDTO(
        boolean habilitado,
        String modo,
        boolean simulado,
        String cuit,
        boolean credencialesConfiguradas,
        int tipoComprobanteDefault,
        double alicuotaIva,
        String wsaaUrl,
        String wsfeUrl,
        String cliente,
        String mensaje
) {
}
