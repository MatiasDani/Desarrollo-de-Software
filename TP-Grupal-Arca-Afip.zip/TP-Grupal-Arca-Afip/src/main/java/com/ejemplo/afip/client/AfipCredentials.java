package com.ejemplo.afip.client;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

public record AfipCredentials(PrivateKey clavePrivada, X509Certificate certificado) {
}
