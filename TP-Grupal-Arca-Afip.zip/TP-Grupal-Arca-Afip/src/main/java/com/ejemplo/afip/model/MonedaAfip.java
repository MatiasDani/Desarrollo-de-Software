package com.ejemplo.afip.model;

public record MonedaAfip(String codigo, String denominacion, String vigenciaDesde, String vigenciaHasta) {
}
