package com.ejemplo.afip;

public class AfipException extends RuntimeException {
    public AfipException(String mensaje) {
        super(mensaje);
    }

    public AfipException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
