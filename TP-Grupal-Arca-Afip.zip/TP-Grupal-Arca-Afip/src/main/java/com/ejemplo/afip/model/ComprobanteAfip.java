package com.ejemplo.afip.model;

import java.time.LocalDate;

public record ComprobanteAfip(
        int puntoVenta,
        int tipoComprobante,
        long numero,
        LocalDate fecha,
        double importeTotal,
        int docTipo,
        long docNro,
        String moneda,
        double cotizacion,
        double alicuotaIva,
        boolean discriminaIva,
        int condicionIvaReceptor
) {
    public boolean esFacturaC() {
        return tipoComprobante == 11;
    }
}
