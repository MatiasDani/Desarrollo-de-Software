package com.ejemplo.afip.model;

import java.time.LocalDateTime;

public record AfipAuth(String token, String sign, long cuit, LocalDateTime vencimiento) {
}
