package com.ejemplo.afip.dto;

public record EmisionCaeRequestDTO(Integer tipoComprobante) {
}
