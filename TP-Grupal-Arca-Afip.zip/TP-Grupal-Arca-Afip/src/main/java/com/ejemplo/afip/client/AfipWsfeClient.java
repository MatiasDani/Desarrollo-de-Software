package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.model.AfipAuth;
import com.ejemplo.afip.model.CaeResultado;
import com.ejemplo.afip.model.ComprobanteAfip;
import com.ejemplo.afip.model.EstadoServidores;
import com.ejemplo.afip.model.MonedaAfip;
import com.ejemplo.afip.model.UltimoComprobante;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
public class AfipWsfeClient {
    private static final Logger log = LoggerFactory.getLogger(AfipWsfeClient.class);

    private final AfipProperties properties;
    private final AfipWsfeJaxwsClient jaxws;
    private final AfipWsfeSoapClient soap;

    private volatile Boolean jaxwsDisponible;

    public AfipWsfeClient(AfipProperties properties,
                          AfipWsfeJaxwsClient jaxws,
                          AfipWsfeSoapClient soap) {
        this.properties = properties;
        this.jaxws = jaxws;
        this.soap = soap;
    }

    public EstadoServidores dummy() {
        if (!properties.isUsarJaxws()) {
            return soap.dummy();
        }
        try {
            EstadoServidores estado = jaxws.dummy();
            marcarJaxwsDisponible(true, null);
            return estado;
        } catch (RuntimeException e) {
            if (jaxwsDisponible == null) {
                marcarJaxwsDisponible(false, e);
                return soap.dummy();
            }
            throw e;
        }
    }

    public UltimoComprobante ultimoComprobante(AfipAuth auth, int puntoVenta, int tipoComprobante) {
        return usarJaxws()
                ? jaxws.ultimoComprobante(auth, puntoVenta, tipoComprobante)
                : soap.ultimoComprobante(auth, puntoVenta, tipoComprobante);
    }

    public CaeResultado solicitarCae(AfipAuth auth, ComprobanteAfip comprobante) {
        return usarJaxws()
                ? jaxws.solicitarCae(auth, comprobante)
                : soap.solicitarCae(auth, comprobante);
    }

    public List<MonedaAfip> tiposMonedas(AfipAuth auth) {
        return usarJaxws() ? jaxws.tiposMonedas(auth) : soap.tiposMonedas(auth);
    }

    public Double cotizacion(AfipAuth auth, String monId, LocalDate fecha) {
        return usarJaxws() ? jaxws.cotizacion(auth, monId, fecha) : soap.cotizacion(auth, monId, fecha);
    }

    public String clienteActivo() {
        if (!properties.isUsarJaxws()) {
            return "SOAP manual (forzado)";
        }
        if (Boolean.FALSE.equals(jaxwsDisponible)) {
            return "SOAP manual (respaldo)";
        }
        return "JAX-WS (stubs generados)";
    }

    private boolean usarJaxws() {
        if (!properties.isUsarJaxws()) {
            return false;
        }
        Boolean disponible = jaxwsDisponible;
        if (disponible != null) {
            return disponible;
        }
        synchronized (this) {
            if (jaxwsDisponible != null) {
                return jaxwsDisponible;
            }
            try {
                jaxws.dummy();
                marcarJaxwsDisponible(true, null);
                return true;
            } catch (RuntimeException e) {
                marcarJaxwsDisponible(false, e);
                return false;
            }
        }
    }

    private void marcarJaxwsDisponible(boolean disponible, RuntimeException error) {
        if (jaxwsDisponible != null) {
            return;
        }
        jaxwsDisponible = disponible;
        if (disponible) {
            log.info("WSFEv1: usando el cliente JAX-WS generado (com.ejemplo.afip.wsfe).");
        } else {
            log.warn("WSFEv1: el cliente JAX-WS no está disponible ({}). "
                            + "Se usa el cliente SOAP manual. Configurá afip.usar-jaxws=false "
                            + "para evitar el sondeo.",
                    error == null ? "sin detalle" : error.getMessage());
        }
    }
}
