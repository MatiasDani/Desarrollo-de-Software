package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class SoapSupport {
    private SoapSupport() {
    }

    public static String enviar(String url, String soapXml, String soapAction, int timeoutMs) {
        HttpURLConnection conexion = null;
        try {
            conexion = (HttpURLConnection) new URL(url).openConnection();
            conexion.setRequestMethod("POST");
            conexion.setConnectTimeout(timeoutMs);
            conexion.setReadTimeout(timeoutMs);
            conexion.setDoOutput(true);
            conexion.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
            conexion.setRequestProperty("Accept", "text/xml");
            if (soapAction != null) {
                conexion.setRequestProperty("SOAPAction",
                        soapAction.isEmpty() ? "" : "\"" + soapAction + "\"");
            }

            try (OutputStream salida = conexion.getOutputStream()) {
                salida.write(soapXml.getBytes(StandardCharsets.UTF_8));
            }

            int estado = conexion.getResponseCode();
            InputStream stream = estado >= 400 ? conexion.getErrorStream() : conexion.getInputStream();
            if (stream == null) {
                throw new AfipException("AFIP respondió HTTP " + estado + " sin cuerpo.");
            }

            String respuesta;
            try (BufferedReader lector = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String linea;
                while ((linea = lector.readLine()) != null) {
                    sb.append(linea);
                }
                respuesta = sb.toString();
            }

            if (estado >= 400) {
                throw new AfipException("AFIP respondió HTTP " + estado + ": " + extracto(respuesta));
            }
            return respuesta;
        } catch (AfipException e) {
            throw e;
        } catch (Exception e) {
            throw new AfipException("No se pudo conectar con AFIP (" + url + "): " + e.getMessage(), e);
        } finally {
            if (conexion != null) {
                conexion.disconnect();
            }
        }
    }

    public static Document parsear(String xml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            return builder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new AfipException("No se pudo interpretar la respuesta XML de AFIP: " + e.getMessage(), e);
        }
    }

    public static Element primerElemento(Node raiz, String nombreLocal) {
        if (raiz == null) {
            return null;
        }
        if (raiz.getNodeType() == Node.ELEMENT_NODE && nombreLocal.equals(raiz.getLocalName())) {
            return (Element) raiz;
        }
        NodeList hijos = raiz.getChildNodes();
        for (int i = 0; i < hijos.getLength(); i++) {
            Element encontrado = primerElemento(hijos.item(i), nombreLocal);
            if (encontrado != null) {
                return encontrado;
            }
        }
        return null;
    }

    public static List<Element> elementos(Node raiz, String nombreLocal) {
        List<Element> resultado = new ArrayList<>();
        if (raiz == null) {
            return resultado;
        }
        if (raiz.getNodeType() == Node.ELEMENT_NODE && nombreLocal.equals(raiz.getLocalName())) {
            resultado.add((Element) raiz);
        }
        NodeList hijos = raiz.getChildNodes();
        for (int i = 0; i < hijos.getLength(); i++) {
            resultado.addAll(elementos(hijos.item(i), nombreLocal));
        }
        return resultado;
    }

    public static Element hijo(Element padre, String nombreLocal) {
        if (padre == null) {
            return null;
        }
        NodeList hijos = padre.getChildNodes();
        for (int i = 0; i < hijos.getLength(); i++) {
            Node nodo = hijos.item(i);
            if (nodo.getNodeType() == Node.ELEMENT_NODE && nombreLocal.equals(nodo.getLocalName())) {
                return (Element) nodo;
            }
        }
        return null;
    }

    public static String texto(Element padre, String nombreLocal) {
        Element elemento = hijo(padre, nombreLocal);
        if (elemento == null) {
            return null;
        }
        String valor = elemento.getTextContent();
        return valor == null ? null : valor.trim();
    }

    public static double decimal(Element padre, String nombreLocal, double porDefecto) {
        String valor = texto(padre, nombreLocal);
        if (valor == null || valor.isBlank()) {
            return porDefecto;
        }
        try {
            return Double.parseDouble(valor);
        } catch (NumberFormatException e) {
            return porDefecto;
        }
    }

    public static long entero(Element padre, String nombreLocal, long porDefecto) {
        String valor = texto(padre, nombreLocal);
        if (valor == null || valor.isBlank()) {
            return porDefecto;
        }
        try {
            return Long.parseLong(valor);
        } catch (NumberFormatException e) {
            return porDefecto;
        }
    }

    public static List<String> leerMensajes(Element contenedor, String nombreItem) {
        List<String> mensajes = new ArrayList<>();
        if (contenedor == null) {
            return mensajes;
        }
        for (Element item : elementos(contenedor, nombreItem)) {
            String codigo = texto(item, "Code");
            String mensaje = texto(item, "Msg");
            if (mensaje == null) {
                mensaje = item.getTextContent() == null ? "" : item.getTextContent().trim();
            }
            mensajes.add(codigo == null || codigo.isBlank() ? mensaje : "[" + codigo + "] " + mensaje);
        }
        return mensajes;
    }

    public static String escapar(String valor) {
        if (valor == null) {
            return "";
        }
        return valor.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    public static String desescaparXml(String valor) {
        if (valor == null) {
            return null;
        }
        return valor
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }

    public static void lanzarSiFault(Document document) {
        Element fault = primerElemento(document.getDocumentElement(), "Fault");
        if (fault != null) {
            String mensaje = texto(fault, "faultstring");
            if (mensaje == null || mensaje.isBlank()) {
                mensaje = fault.getTextContent();
            }
            throw new AfipException("AFIP devolvió un error SOAP: " + mensaje);
        }
    }

    private static String extracto(String texto) {
        if (texto == null) {
            return "";
        }
        String limpio = texto.replaceAll("\\s+", " ").trim();
        return limpio.length() > 500 ? limpio.substring(0, 500) + "..." : limpio;
    }
}
