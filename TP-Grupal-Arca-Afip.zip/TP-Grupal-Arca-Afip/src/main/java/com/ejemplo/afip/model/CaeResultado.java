package com.ejemplo.afip.model;

import java.time.LocalDate;
import java.util.List;

public record CaeResultado(
        boolean aprobado,
        String resultado,
        String cae,
        LocalDate caeVencimiento,
        long numeroComprobante,
        int tipoComprobante,
        String modo,
        List<String> observaciones,
        List<String> errores,
        List<String> eventos
) {
    public static CaeResultado aprobado(String cae, LocalDate vto, long numero, int tipoComprobante,
                                        String modo, List<String> observaciones) {
        return new CaeResultado(true, "A", cae, vto, numero, tipoComprobante, modo,
                observaciones == null ? List.of() : observaciones, List.of(), List.of());
    }

    public static CaeResultado rechazado(String resultado, long numero, int tipoComprobante,
                                         String modo, List<String> observaciones, List<String> errores) {
        return new CaeResultado(false, resultado, null, null, numero, tipoComprobante, modo,
                observaciones == null ? List.of() : observaciones,
                errores == null ? List.of() : errores, List.of());
    }
}
