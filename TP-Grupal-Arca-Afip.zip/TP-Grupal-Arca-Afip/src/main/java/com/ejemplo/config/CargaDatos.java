package com.ejemplo.config;

import com.ejemplo.afip.MonedasAfip;
import com.ejemplo.entity.Articulo;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.CondicionIva;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.Contacto;
import com.ejemplo.entity.Domicilio;
import com.ejemplo.entity.ListaPrecio;
import com.ejemplo.entity.ListaPrecioArticulo;
import com.ejemplo.entity.Marca;
import com.ejemplo.entity.Rubro;
import com.ejemplo.entity.Usuario;
import com.ejemplo.entity.UsuarioActual;
import com.ejemplo.entity.PuntoVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.repository.ArticuloRepository;
import com.ejemplo.repository.ClienteRepository;
import com.ejemplo.repository.CondicionIvaRepository;
import com.ejemplo.repository.FacturaVentaRepository;
import com.ejemplo.repository.ListaPrecioRepository;
import com.ejemplo.repository.MarcaRepository;
import com.ejemplo.repository.RubroRepository;
import com.ejemplo.repository.UsuarioRepository;
import com.ejemplo.repository.PuntoVentaRepository;
import com.ejemplo.repository.TipoMonedaRepository;
import com.ejemplo.service.ReporteService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CargaDatos implements CommandLineRunner {
    private final CondicionIvaRepository condicionIvaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final ClienteRepository clienteRepository;
    private final ArticuloRepository articuloRepository;
    private final FacturaVentaRepository facturaVentaRepository;
    private final ReporteService reporteService;
    private final ListaPrecioRepository listaPrecioRepository;
    private final UsuarioRepository usuarioRepository;
    private final MarcaRepository marcaRepository;
    private final RubroRepository rubroRepository;

    private final Map<Articulo, Double> precioBase = new HashMap<>();
    private final Map<Articulo, ListaPrecioArticulo> minorista = new HashMap<>();
    private List<Usuario> usuarios;
    private int facturasCargadas;

    public CargaDatos(CondicionIvaRepository condicionIvaRepository, TipoMonedaRepository tipoMonedaRepository,
                      PuntoVentaRepository puntoVentaRepository, ClienteRepository clienteRepository,
                      ArticuloRepository articuloRepository, FacturaVentaRepository facturaVentaRepository,
                      ReporteService reporteService, ListaPrecioRepository listaPrecioRepository,
                      UsuarioRepository usuarioRepository, MarcaRepository marcaRepository,
                      RubroRepository rubroRepository) {
        this.condicionIvaRepository = condicionIvaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.clienteRepository = clienteRepository;
        this.articuloRepository = articuloRepository;
        this.facturaVentaRepository = facturaVentaRepository;
        this.reporteService = reporteService;
        this.listaPrecioRepository = listaPrecioRepository;
        this.usuarioRepository = usuarioRepository;
        this.marcaRepository = marcaRepository;
        this.rubroRepository = rubroRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        Usuario admin = crearUsuario("admin", "admin123", "Administrador", "Sistema");
        Usuario cajero1 = crearUsuario("mlopez", "cajero123", "María", "López");
        Usuario cajero2 = crearUsuario("rgarcia", "cajero123", "Ramiro", "García");
        UsuarioActual.establecer(admin);
        usuarios = List.of(admin, cajero1, cajero2);

        CondicionIva responsableInscripto = crearCondicionIva(1, "IVA Responsable Inscripto");
        CondicionIva exento = crearCondicionIva(4, "IVA Sujeto Exento");
        CondicionIva consumidorFinal = crearCondicionIva(5, "Consumidor Final");
        CondicionIva monotributo = crearCondicionIva(6, "Responsable Monotributo");

        TipoMoneda pesos = null;
        for (MonedasAfip.Definicion definicion : MonedasAfip.catalogo()) {
            TipoMoneda moneda = new TipoMoneda();
            moneda.setCodigo(definicion.codigoIso());
            moneda.setCodigoAfip(definicion.codigoAfip());
            moneda.setDenominacion(definicion.denominacion());
            moneda.setSimbolo(MonedasAfip.simbolo(definicion.codigoIso()));
            moneda.setCotizacion("PES".equals(definicion.codigoAfip()) ? 1 : 0);
            moneda = tipoMonedaRepository.save(moneda);
            if ("PES".equals(definicion.codigoAfip())) {
                pesos = moneda;
            }
        }

        PuntoVenta central = crearPuntoVenta(1, "Sucursal Central", "San Martín 1200, Mendoza");
        PuntoVenta godoyCruz = crearPuntoVenta(2, "Sucursal Godoy Cruz", "Perú 450, Godoy Cruz");
        crearPuntoVenta(5, "Depósito Luján", "Ruta 7 km 1020, Luján de Cuyo");

        Cliente empresaTech = crearCliente("Empresa Tech S.A.", "30-71234567-8", "compras@empresatech.com",
                "0261-4251000", "Av. Colón", "350", responsableInscripto);
        Cliente distribuidora = crearCliente("Distribuidora Andina S.R.L.", "30-70987654-3", "admin@andina.com",
                "0261-4398200", "Belgrano", "1180", responsableInscripto);
        Cliente juanPerez = crearCliente("Juan Pérez", "20-30111222-5", "juanperez@gmail.com",
                "261-155123456", "Rivadavia", "742", monotributo);
        Cliente fundacion = crearCliente("Fundación Educar", "30-69876543-1", "contacto@educar.org",
                "0261-4207700", "Mitre", "95", exento);

        Rubro computacion = crearRubro(1, "Computación");
        Rubro electronica = crearRubro(2, "Electrónica");
        Rubro accesorios = crearRubro(3, "Accesorios");

        Marca lenovo = crearMarca(1, "Lenovo");
        Marca logitech = crearMarca(2, "Logitech");
        Marca samsung = crearMarca(3, "Samsung");
        Marca kingston = crearMarca(4, "Kingston");

        Articulo notebook = crearArticulo("A001", "Notebook 15 pulgadas", 950000, computacion, lenovo);
        Articulo mouse = crearArticulo("A002", "Mouse inalámbrico", 18000, accesorios, logitech);
        Articulo teclado = crearArticulo("A003", "Teclado mecánico", 65000, accesorios, logitech);
        Articulo monitor = crearArticulo("A004", "Monitor 24 pulgadas", 280000, electronica, samsung);
        Articulo auriculares = crearArticulo("A005", "Auriculares", 45000, electronica, logitech);
        Articulo webcam = crearArticulo("A006", "Webcam HD", 38000, electronica, logitech);
        Articulo cableHdmi = crearArticulo("A007", "Cable HDMI", 6500, accesorios, null);
        Articulo pendrive = crearArticulo("A008", "Pendrive 64GB", 12000, computacion, kingston);
        Articulo parlante = crearArticulo("A009", "Parlante Bluetooth", 54000, electronica, samsung);

        ListaPrecio listaMinorista = new ListaPrecio("LP-01", "Minorista");
        for (Articulo a : List.of(notebook, mouse, teclado, monitor, auriculares, webcam, cableHdmi, pendrive, parlante)) {
            minorista.put(a, listaMinorista.agregarArticulo(a, precioBase.get(a)));
        }
        listaPrecioRepository.save(listaMinorista);

        ListaPrecio mayorista = new ListaPrecio("LP-02", "Mayorista");
        for (Articulo a : List.of(notebook, mouse, teclado, monitor, cableHdmi, pendrive)) {
            mayorista.agregarArticulo(a, Math.round(precioBase.get(a) * 0.85));
        }
        listaPrecioRepository.save(mayorista);

        ListaPrecio revendedores = new ListaPrecio("LP-03", "Revendedores");
        for (Articulo a : List.of(mouse, teclado, cableHdmi, pendrive)) {
            revendedores.agregarArticulo(a, Math.round(precioBase.get(a) * 0.75));
        }
        listaPrecioRepository.save(revendedores);

        FacturaVenta f1 = crearFactura(1001L, "2026-03-15", central, null, consumidorFinal, pesos, "EMITIDA");
        f1.agregarDetalle(precio(mouse), 1);
        f1.agregarDetalle(precio(cableHdmi), 2);
        guardarFactura(f1);

        FacturaVenta f2 = crearFactura(1002L, "2026-03-20", central, empresaTech, responsableInscripto, pesos, "EMITIDA");
        f2.agregarDetalle(precio(notebook), 2);
        f2.agregarDetalle(precio(monitor), 2);
        f2.agregarDetalle(precio(teclado), 2);
        f2.agregarDetalle(precio(mouse), 2);
        f2.agregarDetalle(precio(webcam), 1);
        guardarFactura(f2);

        FacturaVenta f3 = crearFactura(1003L, "2026-03-28", godoyCruz, juanPerez, monotributo, pesos, "ANULADA");
        f3.agregarDetalle(precio(auriculares), 1);
        f3.agregarDetalle(precio(pendrive), 3);
        f3.setFechaAnulacion(Date.valueOf("2026-03-29"));
        f3.setObservaciones("Error en los datos del cliente");
        guardarFactura(f3);

        FacturaVenta f4 = crearFactura(1004L, "2026-04-02", godoyCruz, distribuidora, responsableInscripto, pesos, "EMITIDA");
        f4.agregarDetalle(precio(monitor), 5);
        f4.agregarDetalle(precio(cableHdmi), 10);
        f4.agregarDetalle(precio(teclado), 5);
        guardarFactura(f4);

        FacturaVenta f5 = crearFactura(1005L, "2026-04-10", godoyCruz, null, consumidorFinal, pesos, "EMITIDA");
        f5.agregarDetalle(precio(pendrive), 2);
        f5.agregarDetalle(precio(mouse), 1);
        guardarFactura(f5);

        FacturaVenta f6 = crearFactura(1006L, "2026-04-18", central, empresaTech, responsableInscripto, pesos, "EMITIDA");
        f6.agregarDetalle(precio(webcam), 4);
        f6.agregarDetalle(precio(auriculares), 4);
        f6.agregarDetalle(precio(mouse), 4);
        f6.agregarDetalle(precio(teclado), 4);
        guardarFactura(f6);

        FacturaVenta f7 = crearFactura(1007L, "2026-05-05", central, fundacion, exento, pesos, "EMITIDA");
        f7.agregarDetalle(precio(notebook), 3);
        f7.agregarDetalle(precio(mouse), 3);
        guardarFactura(f7);

        FacturaVenta f8 = crearFactura(1008L, "2026-05-12", central, distribuidora, responsableInscripto, pesos, "ANULADA");
        f8.agregarDetalle(precio(monitor), 1);
        f8.agregarDetalle(precio(cableHdmi), 1);
        f8.agregarDetalle(precio(webcam), 1);
        f8.setFechaAnulacion(Date.valueOf("2026-05-13"));
        f8.setObservaciones("El cliente rechazó la compra");
        guardarFactura(f8);

        List<Articulo> articulos = List.of(notebook, mouse, teclado, monitor,
                auriculares, webcam, cableHdmi, pendrive);
        cargarFacturasVariadas(articulos, central, godoyCruz, empresaTech, distribuidora,
                juanPerez, fundacion, responsableInscripto, exento, consumidorFinal, monotributo, pesos);

        System.out.println("Se cargaron " + facturaVentaRepository.count() + " facturas de ejemplo");

        reporteService.guardarArchivos();
    }

    private void cargarFacturasVariadas(List<Articulo> articulos, PuntoVenta central, PuntoVenta godoyCruz,
                                        Cliente empresaTech, Cliente distribuidora, Cliente juanPerez,
                                        Cliente fundacion, CondicionIva responsableInscripto, CondicionIva exento,
                                        CondicionIva consumidorFinal, CondicionIva monotributo, TipoMoneda pesos) {
        LocalDate fechaBase = LocalDate.of(2026, 1, 5);

        for (int i = 101; i <= 200; i++) {
            long numero = 1000L + i;
            LocalDate fecha = i % 10 == 5 ? LocalDate.now() : fechaBase.plusDays((i - 101) * 2L);
            int tipoComprobante = i % 3 == 0 ? 1 : (i % 3 == 1 ? 6 : 11);

            Cliente cliente;
            CondicionIva condicionIva;
            if (tipoComprobante == 1) {
                cliente = i % 2 == 0 ? empresaTech : distribuidora;
                condicionIva = responsableInscripto;
            } else if (tipoComprobante == 6) {
                int variante = i % 3;
                if (variante == 0) {
                    cliente = null;
                    condicionIva = consumidorFinal;
                } else if (variante == 1) {
                    cliente = juanPerez;
                    condicionIva = monotributo;
                } else {
                    cliente = fundacion;
                    condicionIva = exento;
                }
            } else {
                int variante = i % 4;
                if (variante == 0) {
                    cliente = null;
                    condicionIva = consumidorFinal;
                } else if (variante == 1) {
                    cliente = juanPerez;
                    condicionIva = monotributo;
                } else if (variante == 2) {
                    cliente = fundacion;
                    condicionIva = exento;
                } else {
                    cliente = distribuidora;
                    condicionIva = responsableInscripto;
                }
            }

            String estado;
            if (i % 10 == 0) {
                estado = "ANULADA";
            } else if (i % 10 == 5) {
                estado = "ACTIVA";
            } else {
                estado = "EMITIDA";
            }

            if ("ACTIVA".equals(estado)) {
                cliente = null;
                condicionIva = consumidorFinal;
                tipoComprobante = 11;
            }

            FacturaVenta factura = crearFacturaGenerada(
                    numero, fecha.toString(), i % 2 == 0 ? central : godoyCruz,
                    cliente, condicionIva, pesos, estado, tipoComprobante,
                    !"ACTIVA".equals(estado));

            if ("ANULADA".equals(estado)) {
                factura.setFechaAnulacion(Date.valueOf(fecha.plusDays(1)));
                factura.setObservaciones("Anulación de carga masiva");
            } else if ("ACTIVA".equals(estado)) {
                factura.setObservaciones("Pendiente de emisión de CAE (masivo)");
            }

            int cantidadItems = 1 + (i % 4);
            for (int j = 0; j < cantidadItems; j++) {
                Articulo articulo = articulos.get((i + j * 3) % articulos.size());
                double cantidad = 1 + ((i + j) % 5);
                factura.agregarDetalle(precio(articulo), cantidad);
            }
            guardarFactura(factura);
        }
    }

    private FacturaVenta crearFacturaGenerada(Long numero, String fecha, PuntoVenta puntoVenta, Cliente cliente,
                                              CondicionIva condicionIva, TipoMoneda moneda, String estado,
                                              int tipoComprobante, boolean conCae) {
        FacturaVenta factura = FacturaVenta.builder()
                .numero(numero)
                .fechaEmision(Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .cliente(cliente)
                .condicionIva(condicionIva)
                .tipoMoneda(moneda)
                .estado(estado)
                .tipoComprobante(tipoComprobante)
                .build();

        if (conCae) {
            factura.setNumeroAfip(numero);
            factura.setResultadoAfip("A");
            factura.setCae("7400000000" + numero);
            factura.setCaeFechaVencimiento(Date.valueOf(LocalDate.parse(fecha).plusDays(10)));
        }
        return factura;
    }

    private ListaPrecioArticulo precio(Articulo articulo) {
        return minorista.get(articulo);
    }

    private Usuario crearUsuario(String usuario, String clave, String nombre, String apellido) {
        return usuarioRepository.save(new Usuario(usuario, clave, nombre, apellido));
    }

    private Rubro crearRubro(int codigo, String denominacion) {
        return rubroRepository.save(new Rubro(denominacion, codigo));
    }

    private Marca crearMarca(int codigo, String denominacion) {
        return marcaRepository.save(new Marca(denominacion, codigo));
    }

    private CondicionIva crearCondicionIva(int codigo, String denominacion) {
        CondicionIva condicionIva = new CondicionIva();
        condicionIva.setCodigoAfip(codigo);
        condicionIva.setDenominacion(denominacion);
        return condicionIvaRepository.save(condicionIva);
    }

    private PuntoVenta crearPuntoVenta(int numero, String descripcion, String domicilio) {
        PuntoVenta puntoVenta = new PuntoVenta();
        puntoVenta.setNumero(numero);
        puntoVenta.setDescripcion(descripcion);
        puntoVenta.setTipoEmision("CAE - Web Services");
        puntoVenta.setDomicilioComercial(domicilio);
        return puntoVentaRepository.save(puntoVenta);
    }

    private Cliente crearCliente(String denominacion, String cuitCuil, String email, String telefono,
                                 String calle, String numero, CondicionIva condicionIva) {
        Contacto contacto = new Contacto();
        contacto.setEmail(email);
        contacto.setTelefono(telefono);

        Domicilio domicilio = new Domicilio();
        domicilio.setNombreCalle(calle);
        domicilio.setNumeroCalle(numero);

        Cliente cliente = new Cliente();
        cliente.setDenominacion(denominacion);
        cliente.setCuitCuil(cuitCuil);
        cliente.setContacto(contacto);
        cliente.setDomicilio(domicilio);
        cliente.setCondicionIva(condicionIva);
        return clienteRepository.save(cliente);
    }

    private Articulo crearArticulo(String codigo, String denominacion, double precio, Rubro rubro, Marca marca) {
        Articulo articulo = new Articulo();
        articulo.setCodigo(codigo);
        articulo.setDenominacion(denominacion);
        articulo.setRubro(rubro);
        articulo.setMarca(marca);
        articulo = articuloRepository.save(articulo);
        precioBase.put(articulo, precio);
        return articulo;
    }

    private FacturaVenta crearFactura(Long numero, String fecha, PuntoVenta puntoVenta, Cliente cliente,
                                      CondicionIva condicionIva, TipoMoneda moneda, String estado) {
        return FacturaVenta.builder()
                .numero(numero)
                .numeroAfip(numero)
                .fechaEmision(Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .cliente(cliente)
                .condicionIva(condicionIva)
                .tipoMoneda(moneda)
                .estado(estado)
                .tipoComprobante(condicionIva.getCodigoAfip() == 1 ? 1 : 11)
                .resultadoAfip("A")
                .cae("7400000000" + numero)
                .caeFechaVencimiento(Date.valueOf(LocalDate.parse(fecha).plusDays(10)))
                .build();
    }

    private void guardarFactura(FacturaVenta factura) {
        Usuario cargo = usuarios.get(facturasCargadas++ % usuarios.size());
        factura.setUsuarioCarga(cargo);
        factura.setUsuarioModificacion(cargo);
        if ("ANULADA".equals(factura.getEstado())) {
            factura.setFechaBaja(factura.getFechaAnulacion());
            factura.setUsuarioBaja(cargo);
        }
        factura.calcularTotal();
        factura.setImporteCobrado(factura.getImporteTotal());
        factura.calcularTotal();
        facturaVentaRepository.save(factura);
    }
}
