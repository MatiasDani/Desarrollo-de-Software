package com.ejemplo.dto;

import java.util.List;

public record CatalogoDTO(
        List<PuntoVentaItem> puntosVenta,
        List<ClienteItem> clientes,
        List<CondicionIvaItem> condicionesIva,
        List<MonedaItem> tiposMoneda,
        List<ArticuloItem> articulos,
        List<ListaPrecioItem> listasPrecios,
        List<ListaPrecioArticuloItem> listaPrecioArticulos
) {
    public record PuntoVentaItem(Long id, int numero, String descripcion, String domicilioComercial,
                                 String tipoEmision) {
    }

    public record ClienteItem(Long id, String denominacion, String cuitCuil, String email, String telefono,
                              String domicilio, Long condicionIvaId, String condicionIva) {
    }

    public record CondicionIvaItem(Long id, int codigoAfip, String denominacion) {
    }

    public record MonedaItem(Long id, String codigo, String codigoAfip, String denominacion, String simbolo,
                             double cotizacion) {
    }

    public record ArticuloItem(Long id, String codigo, String denominacion, String marca, String rubro) {
    }

    public record ListaPrecioItem(Long id, String codigo, String denominacion) {
    }

    public record ListaPrecioArticuloItem(Long id, Long listaPrecioId, Long articuloId, double precioVenta) {
    }
}
