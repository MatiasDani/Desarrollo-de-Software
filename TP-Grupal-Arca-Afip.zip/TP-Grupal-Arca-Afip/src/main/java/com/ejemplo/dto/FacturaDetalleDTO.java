package com.ejemplo.dto;

import java.util.Date;
import java.util.List;

public record FacturaDetalleDTO(
        Long id,
        Long numeroFactura,
        Long numeroAfip,
        Date fechaEmision,
        Long clienteId,
        String clienteDenominacion,
        String clienteCuit,
        Long condicionIvaId,
        String condicionIva,
        Long puntoVentaId,
        String puntoVentaDescripcion,
        int puntoVentaNumero,
        Long tipoMonedaId,
        String tipoMonedaCodigo,
        String tipoMonedaDenominacion,
        double importeCobrado,
        double importeSaldo,
        double importeTotal,
        String estado,
        String observaciones,
        String cae,
        Date caeFechaVencimiento,
        String resultadoAfip,
        String motivoRechazo,
        Integer tipoComprobante,
        Date fechaAnulacion,
        List<Item> items
) {
    public record Item(
            Long listaPrecioArticuloId,
            Long articuloId,
            String codigo,
            String denominacion,
            String descripcion,
            Long listaPrecioId,
            String listaPrecio,
            String marca,
            double cantidad,
            double precioUnitario,
            double porcentajeBonificacion,
            double importeNeto,
            double importeIva,
            double importeSubtotal
    ) {
    }
}
