package com.ejemplo.dto;

/** Un artículo dentro de una lista de precios, tal como se muestra en el explorador de productos. */
public record ProductoCatalogoDTO(
        Long listaPrecioArticuloId,
        Long articuloId,
        String codigo,
        String denominacion,
        String rubro,
        String marca,
        Long listaPrecioId,
        String listaPrecio,
        double precioVenta) {
}
