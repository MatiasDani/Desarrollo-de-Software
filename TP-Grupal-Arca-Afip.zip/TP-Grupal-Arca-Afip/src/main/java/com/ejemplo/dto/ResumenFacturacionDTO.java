package com.ejemplo.dto;

import java.util.List;

public record ResumenFacturacionDTO(
        double totalFacturado,
        long vigentes,
        long conCae,
        long pendientes,
        long anuladas,
        List<FacturaReporteDTO> ultimasFacturas) {
}
