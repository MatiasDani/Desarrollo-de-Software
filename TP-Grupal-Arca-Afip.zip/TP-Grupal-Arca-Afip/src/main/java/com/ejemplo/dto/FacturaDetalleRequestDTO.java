package com.ejemplo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FacturaDetalleRequestDTO {
    private Long listaPrecioArticuloId;
    private double cantidad;
    private Double porcentajeBonificacion;
    private String descripcion;
}
