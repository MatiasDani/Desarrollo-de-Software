package com.ejemplo.service;

import com.ejemplo.afip.AfipProperties;
import com.ejemplo.dto.FacturaDetalleDTO;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Arma el comprobante de una factura en PDF para verlo o imprimirlo (GET /api/facturas/{id}/pdf). */
@Service
public class ComprobantePdfService {
    private static final Color GRIS = new Color(235, 235, 230);
    private final FacturaService facturaService;
    private final AfipProperties afipProperties;

    public ComprobantePdfService(FacturaService facturaService, AfipProperties afipProperties) {
        this.facturaService = facturaService;
        this.afipProperties = afipProperties;
    }

    public byte[] generar(Long id) {
        FacturaDetalleDTO f = facturaService.obtenerDetalle(id);
        boolean discriminaIva = f.tipoComprobante() != null && (f.tipoComprobante() == 1 || f.tipoComprobante() == 6);
        String moneda = f.tipoMonedaCodigo() == null ? "ARS" : f.tipoMonedaCodigo();

        Font titulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
        Font letra = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 30);
        Font negrita = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9);
        Font normal = FontFactory.getFont(FontFactory.HELVETICA, 9);
        Font chica = FontFactory.getFont(FontFactory.HELVETICA, 8, Color.DARK_GRAY);

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter.getInstance(doc, salida);
        doc.open();

        if ("ANULADA".equalsIgnoreCase(f.estado())) {
            Paragraph anulada = new Paragraph("COMPROBANTE ANULADO",
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, new Color(163, 38, 31)));
            anulada.setAlignment(Element.ALIGN_CENTER);
            doc.add(anulada);
        }

        // Encabezado: emisor | letra | datos del comprobante
        PdfPTable cabecera = new PdfPTable(new float[]{4.5f, 1f, 4.5f});
        cabecera.setWidthPercentage(100);
        PdfPCell emisor = celda(null, Rectangle.BOX);
        emisor.addElement(new Paragraph("Facturación ARCA · AFIP", titulo));
        emisor.addElement(new Paragraph(f.puntoVentaDescripcion(), normal));
        emisor.addElement(new Paragraph("CUIT emisor: " + nvl(afipProperties.getCuit()), normal));
        cabecera.addCell(emisor);
        PdfPCell celdaLetra = celda(new Phrase(letra(f.tipoComprobante()), letra), Rectangle.BOX);
        celdaLetra.setHorizontalAlignment(Element.ALIGN_CENTER);
        celdaLetra.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cabecera.addCell(celdaLetra);
        PdfPCell datos = celda(null, Rectangle.BOX);
        datos.addElement(new Paragraph("FACTURA " + letra(f.tipoComprobante()), titulo));
        datos.addElement(new Paragraph("N° " + String.format("%05d-%08d", f.puntoVentaNumero(),
                f.numeroAfip() != null ? f.numeroAfip() : (f.numeroFactura() == null ? 0L : f.numeroFactura())), negrita));
        datos.addElement(new Paragraph("Fecha de emisión: " + fecha(f.fechaEmision()), normal));
        datos.addElement(new Paragraph("Moneda: " + moneda + " · " + nvl(f.tipoMonedaDenominacion()), normal));
        cabecera.addCell(datos);
        doc.add(cabecera);

        // Receptor
        PdfPTable receptor = new PdfPTable(new float[]{1f, 1f});
        receptor.setWidthPercentage(100);
        receptor.setSpacingBefore(8);
        receptor.addCell(celda(new Phrase("Cliente: " + (f.clienteDenominacion() == null ? "Consumidor Final" : f.clienteDenominacion()), negrita), Rectangle.BOX));
        receptor.addCell(celda(new Phrase("CUIT/CUIL: " + (f.clienteCuit() == null ? "—" : f.clienteCuit()), normal), Rectangle.BOX));
        PdfPCell condicion = celda(new Phrase("Condición frente al IVA: " + nvl(f.condicionIva()), normal), Rectangle.BOX);
        condicion.setColspan(2);
        receptor.addCell(condicion);
        doc.add(receptor);

        // Ítems
        PdfPTable items = new PdfPTable(new float[]{1.1f, 3.6f, 0.9f, 1.6f, 0.9f, 1.5f, 1.7f});
        items.setWidthPercentage(100);
        items.setSpacingBefore(10);
        for (String encabezado : new String[]{"Código", "Producto", "Cant.", "Precio unit.", "Bonif.", "IVA 21%", "Subtotal"}) {
            PdfPCell c = celda(new Phrase(encabezado, negrita), Rectangle.BOTTOM);
            c.setBackgroundColor(GRIS);
            items.addCell(c);
        }
        for (FacturaDetalleDTO.Item it : f.items()) {
            items.addCell(celda(new Phrase(nvl(it.codigo()), normal), Rectangle.BOTTOM));
            items.addCell(celda(new Phrase(nvl(it.descripcion()), normal), Rectangle.BOTTOM));
            items.addCell(numero(cantidad(it.cantidad()), normal));
            items.addCell(numero(dinero(it.precioUnitario(), moneda), normal));
            items.addCell(numero(it.porcentajeBonificacion() > 0 ? cantidad(it.porcentajeBonificacion()) + " %" : "—", normal));
            items.addCell(numero(discriminaIva ? dinero(it.importeIva(), moneda) : "—", normal));
            items.addCell(numero(dinero(it.importeSubtotal(), moneda), negrita));
        }
        doc.add(items);

        // Totales
        double iva = f.items().stream().mapToDouble(FacturaDetalleDTO.Item::importeIva).sum();
        Font total = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        PdfPTable totales = new PdfPTable(new float[]{1.6f, 1.6f});
        totales.setWidthPercentage(55);
        totales.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totales.setSpacingBefore(10);
        if (discriminaIva) {
            totales.addCell(celda(new Phrase("Importe neto gravado", normal), Rectangle.NO_BORDER));
            totales.addCell(numero(dinero(f.importeTotal() - iva, moneda), normal, Rectangle.NO_BORDER));
            totales.addCell(celda(new Phrase("IVA 21%", normal), Rectangle.NO_BORDER));
            totales.addCell(numero(dinero(iva, moneda), normal, Rectangle.NO_BORDER));
        }
        totales.addCell(celda(new Phrase("TOTAL", total), Rectangle.TOP));
        totales.addCell(numero(dinero(f.importeTotal(), moneda), total, Rectangle.TOP));
        doc.add(totales);

        if (!discriminaIva) {
            doc.add(new Paragraph("Factura C: el importe total no discrimina IVA.", chica));
        }
        if (f.observaciones() != null && !f.observaciones().isBlank()) {
            Paragraph obs = new Paragraph("Observaciones: " + f.observaciones(), normal);
            obs.setSpacingBefore(8);
            doc.add(obs);
        }

        // Datos fiscales de ARCA
        PdfPTable fiscal = new PdfPTable(1);
        fiscal.setWidthPercentage(100);
        fiscal.setSpacingBefore(16);
        String textoFiscal = f.cae() != null && !f.cae().isBlank()
                ? "CAE N°: " + f.cae() + "     Vencimiento del CAE: " + fecha(f.caeFechaVencimiento())
                : "Comprobante sin CAE: todavía no fue informado a ARCA y no es válido como factura.";
        PdfPCell celdaFiscal = celda(new Phrase(textoFiscal, negrita), Rectangle.BOX);
        celdaFiscal.setBackgroundColor(GRIS);
        fiscal.addCell(celdaFiscal);
        doc.add(fiscal);
        if (afipProperties.esSimulado()) {
            doc.add(new Paragraph("Modo simulado: el CAE es ficticio y no fue emitido por ARCA.", chica));
        }

        doc.close();
        return salida.toByteArray();
    }

    private static String letra(Integer tipo) {
        if (tipo == null) return "C";
        return switch (tipo) {
            case 1 -> "A";
            case 6 -> "B";
            default -> "C";
        };
    }

    private static PdfPCell celda(Phrase contenido, int borde) {
        PdfPCell c = contenido == null ? new PdfPCell() : new PdfPCell(contenido);
        c.setBorder(borde);
        c.setPadding(6);
        return c;
    }

    private static PdfPCell numero(String texto, Font fuente) {
        return numero(texto, fuente, Rectangle.BOTTOM);
    }

    private static PdfPCell numero(String texto, Font fuente, int borde) {
        PdfPCell c = celda(new Phrase(texto, fuente), borde);
        c.setHorizontalAlignment(Element.ALIGN_RIGHT);
        return c;
    }

    private static String dinero(double valor, String moneda) {
        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("es", "AR"));
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        return ("ARS".equals(moneda) ? "$ " : moneda + " ") + nf.format(valor);
    }

    private static String cantidad(double valor) {
        return valor == Math.rint(valor) ? String.valueOf((long) valor) : String.valueOf(valor);
    }

    private static String fecha(Date d) {
        return d == null ? "—" : new SimpleDateFormat("dd/MM/yyyy").format(d);
    }

    private static String nvl(Object o) {
        return o == null ? "—" : o.toString();
    }
}
