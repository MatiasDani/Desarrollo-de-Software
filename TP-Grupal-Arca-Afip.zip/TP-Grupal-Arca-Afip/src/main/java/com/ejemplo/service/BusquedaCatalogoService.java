package com.ejemplo.service;

import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ProductoCatalogoDTO;
import com.ejemplo.entity.Cliente;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

/**
 * Búsquedas paginadas de los pop-ups (productos y clientes). Igual que el listado de facturas:
 * primero un COUNT con los mismos filtros y después solo la página pedida (setFirstResult/setMaxResults).
 */
@Service
@Transactional(readOnly = true)
public class BusquedaCatalogoService {
    private final EntityManager em;

    public BusquedaCatalogoService(EntityManager em) {
        this.em = em;
    }

    public PaginaDTO<ProductoCatalogoDTO> buscarProductos(String buscar, Long listaPrecioId, int pagina, int tamanio) {
        Map<String, Object> params = new HashMap<>();
        StringBuilder where = new StringBuilder("WHERE 1=1 ");
        if (listaPrecioId != null) {
            where.append("AND lp.id = :listaPrecioId ");
            params.put("listaPrecioId", listaPrecioId);
        }
        // Cada palabra tiene que aparecer en el código, la denominación, el rubro, la marca o la lista.
        String[] palabras = buscar == null ? new String[0] : sinTildes(buscar.trim().toLowerCase(Locale.ROOT)).split("\\s+");
        int i = 0;
        for (String palabra : palabras) {
            if (palabra.isBlank()) continue;
            String p = ":p" + i;
            where.append("AND (").append(sinTildesJpql("a.codigo")).append(" LIKE ").append(p)
                    .append(" OR ").append(sinTildesJpql("a.denominacion")).append(" LIKE ").append(p)
                    .append(" OR ").append(sinTildesJpql("COALESCE(r.denominacion, '')")).append(" LIKE ").append(p)
                    .append(" OR ").append(sinTildesJpql("COALESCE(m.denominacion, '')")).append(" LIKE ").append(p)
                    .append(" OR ").append(sinTildesJpql("lp.denominacion")).append(" LIKE ").append(p).append(") ");
            params.put("p" + i, "%" + palabra + "%");
            i++;
        }
        String from = "FROM ListaPrecioArticulo lpa JOIN lpa.articulo a JOIN lpa.listaPrecio lp "
                + "LEFT JOIN a.rubro r LEFT JOIN a.marca m ";
        String select = "SELECT new com.ejemplo.dto.ProductoCatalogoDTO(lpa.id, a.id, a.codigo, a.denominacion, "
                + "r.denominacion, m.denominacion, lp.id, lp.denominacion, lpa.precioVenta) ";
        return paginar("SELECT COUNT(lpa) " + from + where,
                select + from + where + "ORDER BY a.codigo, lp.denominacion, lpa.id",
                ProductoCatalogoDTO.class, params, pagina, tamanio, Function.identity());
    }

    public <R> PaginaDTO<R> buscarClientes(String cuit, String razonSocial, int pagina, int tamanio,
                                           Function<Cliente, R> mapper) {
        Map<String, Object> params = new HashMap<>();
        StringBuilder where = new StringBuilder("WHERE 1=1 ");
        String digitos = cuit == null ? "" : cuit.replaceAll("\\D", "");
        if (!digitos.isEmpty()) {
            // CUIT con o sin guiones: se comparan solo los dígitos.
            where.append("AND REPLACE(COALESCE(c.cuitCuil, ''), '-', '') LIKE :cuit ");
            params.put("cuit", "%" + digitos + "%");
        }
        if (razonSocial != null && !razonSocial.isBlank()) {
            where.append("AND ").append(sinTildesJpql("c.denominacion")).append(" LIKE :razon ");
            params.put("razon", "%" + sinTildes(razonSocial.trim().toLowerCase(Locale.ROOT)) + "%");
        }
        return paginar("SELECT COUNT(c) FROM Cliente c " + where,
                "SELECT c FROM Cliente c " + where + "ORDER BY c.denominacion, c.id",
                Cliente.class, params, pagina, tamanio, mapper);
    }

    private <T, R> PaginaDTO<R> paginar(String jpqlConteo, String jpqlPagina, Class<T> tipo, Map<String, Object> params,
                                        int pagina, int tamanio, Function<T, R> mapper) {
        int tamanioPagina = Math.min(Math.max(tamanio, 1), 100);
        TypedQuery<Long> conteo = em.createQuery(jpqlConteo, Long.class);
        params.forEach(conteo::setParameter);
        long total = conteo.getSingleResult();

        int totalPaginas = total == 0 ? 0 : (int) Math.ceil(total / (double) tamanioPagina);
        int paginaActual = totalPaginas == 0 ? 0 : Math.min(Math.max(pagina, 0), totalPaginas - 1);

        TypedQuery<T> query = em.createQuery(jpqlPagina, tipo);
        params.forEach(query::setParameter);
        query.setFirstResult(paginaActual * tamanioPagina);
        query.setMaxResults(tamanioPagina);
        List<R> contenido = query.getResultList().stream().map(mapper).toList();

        return new PaginaDTO<>(contenido, paginaActual, tamanioPagina, total, totalPaginas,
                paginaActual == 0, totalPaginas == 0 || paginaActual >= totalPaginas - 1);
    }

    /** LOWER y sin tildes en JPQL, para que "computacion" encuentre "Computación". */
    private static String sinTildesJpql(String expresion) {
        String e = "LOWER(" + expresion + ")";
        for (String[] par : new String[][]{{"á", "a"}, {"é", "e"}, {"í", "i"}, {"ó", "o"}, {"ú", "u"}}) {
            e = "REPLACE(" + e + ", '" + par[0] + "', '" + par[1] + "')";
        }
        return e;
    }

    private static String sinTildes(String texto) {
        return java.text.Normalizer.normalize(texto, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
}
