package com.ejemplo.service;

import com.ejemplo.afip.AfipException;
import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.AfipService;
import com.ejemplo.afip.model.CaeResultado;
import com.ejemplo.dto.FacturaDetalleDTO;
import com.ejemplo.dto.FacturaDetalleRequestDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ResumenFacturacionDTO;
import com.ejemplo.entity.Articulo;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.CondicionIva;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.FacturaVentaDetalle;
import com.ejemplo.entity.ListaPrecioArticulo;
import com.ejemplo.entity.PuntoVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.exception.RecursoNoEncontradoException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class FacturaService {
    private static final String SELECT_REPORTE =
            "SELECT new com.ejemplo.dto.FacturaReporteDTO(" +
            "    f.id, COALESCE(f.numeroAfip, f.numero), f.fechaEmision, " +
            "    COALESCE(c.denominacion, 'Consumidor Final'), ci.denominacion, pv.descripcion, " +
            "    f.importeTotal, COUNT(d), f.estado, f.cae, f.caeFechaVencimiento, " +
            "    f.resultadoAfip, f.tipoComprobante" +
            ") " +
            "FROM FacturaVenta f " +
            "LEFT JOIN f.cliente c " +
            "JOIN f.condicionIva ci " +
            "JOIN f.puntoVenta pv " +
            "LEFT JOIN f.detalles d ";

    private static final String GROUP_BY_REPORTE =
            "GROUP BY f.id, f.numeroAfip, f.numero, f.fechaEmision, c.denominacion, " +
            "ci.denominacion, pv.descripcion, f.importeTotal, f.estado, f.cae, " +
            "f.caeFechaVencimiento, f.resultadoAfip, f.tipoComprobante ";

    /** Orden del listado si no se pide otro: de la más reciente a la más antigua. */
    public static final String ORDEN_POR_DEFECTO = "fecha_desc";

    /**
     * Órdenes permitidos para el listado. El usuario elige una clave y la cláusula sale de esta lista
     * cerrada, así nunca se concatena texto del request en el JPQL. El id desempata (dos facturas del mismo día).
     */
    private static final Map<String, String> ORDENES = new LinkedHashMap<>();
    static {
        ORDENES.put("fecha_desc", "f.fechaEmision DESC, f.id DESC");
        ORDENES.put("fecha_asc", "f.fechaEmision ASC, f.id ASC");
        ORDENES.put("numero_desc", "COALESCE(f.numeroAfip, f.numero) DESC, f.id DESC");
        ORDENES.put("numero_asc", "COALESCE(f.numeroAfip, f.numero) ASC, f.id ASC");
        ORDENES.put("importe_desc", "f.importeTotal DESC, f.id DESC");
        ORDENES.put("importe_asc", "f.importeTotal ASC, f.id ASC");
        ORDENES.put("cliente_asc", "COALESCE(c.denominacion, 'Consumidor Final') ASC, f.id DESC");
        ORDENES.put("cliente_desc", "COALESCE(c.denominacion, 'Consumidor Final') DESC, f.id DESC");
    }

    private final EntityManager em;
    private final AfipService afipService;
    private final AfipProperties afipProperties;

    public FacturaService(EntityManager em, AfipService afipService, AfipProperties afipProperties) {
        this.em = em;
        this.afipService = afipService;
        this.afipProperties = afipProperties;
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> obtenerReporte() {
        String jpql = SELECT_REPORTE + GROUP_BY_REPORTE + "ORDER BY f.id";
        return em.createQuery(jpql, FacturaReporteDTO.class).getResultList();
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        return buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo, null);
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado,
                                                           Double montoMinimo, String orden) {
        return buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo, null, null, orden);
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado,
                                                           Double montoMinimo, String cliente, Long numero,
                                                           String orden) {
        return buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo, null, cliente, numero, orden);
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado,
                                                           Double montoMinimo, Long clienteId, String cliente,
                                                           Long numero, String orden) {
        String ordenarPor = clausulaOrden(orden);
        Map<String, Object> params = new HashMap<>();
        String filtros = construirFiltros(fechaDesde, fechaHasta, estado, montoMinimo, clienteId, cliente, numero, params);

        String jpql = SELECT_REPORTE + "WHERE 1=1 " + filtros + GROUP_BY_REPORTE + "ORDER BY " + ordenarPor;

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql, FacturaReporteDTO.class);
        params.forEach(query::setParameter);

        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public ResumenFacturacionDTO obtenerResumen(int cantidadUltimas) {
        Double total = em.createQuery(
                "SELECT COALESCE(SUM(f.importeTotal), 0) FROM FacturaVenta f WHERE f.estado <> 'ANULADA'",
                Double.class).getSingleResult();

        long vigentes = contar("f.estado <> 'ANULADA'");
        long conCae = contar("f.estado <> 'ANULADA' AND f.cae IS NOT NULL AND f.cae <> ''");
        long anuladas = contar("f.estado = 'ANULADA'");

        List<FacturaReporteDTO> ultimas = em.createQuery(
                        SELECT_REPORTE + GROUP_BY_REPORTE + "ORDER BY f.id DESC", FacturaReporteDTO.class)
                .setMaxResults(Math.min(Math.max(cantidadUltimas, 1), 20))
                .getResultList();

        return new ResumenFacturacionDTO(total == null ? 0 : total, vigentes, conCae, vigentes - conCae,
                anuladas, ultimas);
    }

    /** Traduce la clave de orden pedida a su cláusula ORDER BY; una clave desconocida es un 400. */
    private static String clausulaOrden(String orden) {
        String clave = orden == null || orden.isBlank() ? ORDEN_POR_DEFECTO : orden.trim().toLowerCase(Locale.ROOT);
        String clausula = ORDENES.get(clave);
        if (clausula == null) {
            throw new IllegalArgumentException("Orden no válido: '" + orden + "'. Valores posibles: "
                    + String.join(", ", ORDENES.keySet()) + ".");
        }
        return clausula;
    }

    private long contar(String condicion) {
        return em.createQuery("SELECT COUNT(f) FROM FacturaVenta f WHERE " + condicion, Long.class)
                .getSingleResult();
    }

    @Transactional(readOnly = true)
    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(Date fechaDesde, Date fechaHasta, String estado,
                                                                Double montoMinimo, int pagina, int tamanio) {
        return buscarFacturasPaginadas(fechaDesde, fechaHasta, estado, montoMinimo, pagina, tamanio, null);
    }

    @Transactional(readOnly = true)
    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(Date fechaDesde, Date fechaHasta, String estado,
                                                                Double montoMinimo, int pagina, int tamanio,
                                                                String orden) {
        return buscarFacturasPaginadas(fechaDesde, fechaHasta, estado, montoMinimo, null, null,
                pagina, tamanio, orden);
    }

    @Transactional(readOnly = true)
    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(Date fechaDesde, Date fechaHasta, String estado,
                                                                Double montoMinimo, String cliente, Long numero,
                                                                int pagina, int tamanio, String orden) {
        return buscarFacturasPaginadas(fechaDesde, fechaHasta, estado, montoMinimo, null, cliente, numero,
                pagina, tamanio, orden);
    }

    @Transactional(readOnly = true)
    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(Date fechaDesde, Date fechaHasta, String estado,
                                                                Double montoMinimo, Long clienteId, String cliente,
                                                                Long numero, int pagina, int tamanio, String orden) {
        String ordenarPor = clausulaOrden(orden);
        int tamanioPagina = Math.min(Math.max(tamanio, 1), 100);

        Map<String, Object> params = new HashMap<>();
        String filtros = construirFiltros(fechaDesde, fechaHasta, estado, montoMinimo, clienteId, cliente, numero, params);

        // LEFT JOIN al cliente (relación a uno: no multiplica filas) para poder filtrar por su nombre o CUIT.
        TypedQuery<Long> conteo = em.createQuery(
                "SELECT COUNT(f) FROM FacturaVenta f LEFT JOIN f.cliente c WHERE 1=1 " + filtros, Long.class);
        params.forEach(conteo::setParameter);
        long total = conteo.getSingleResult();

        int totalPaginas = total == 0 ? 0 : (int) Math.ceil(total / (double) tamanioPagina);
        int paginaActual = totalPaginas == 0 ? 0 : Math.min(Math.max(pagina, 0), totalPaginas - 1);

        String jpql = SELECT_REPORTE + "WHERE 1=1 " + filtros + GROUP_BY_REPORTE + "ORDER BY " + ordenarPor;

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql, FacturaReporteDTO.class);
        params.forEach(query::setParameter);
        query.setFirstResult(paginaActual * tamanioPagina);
        query.setMaxResults(tamanioPagina);

        List<FacturaReporteDTO> contenido = query.getResultList();

        return new PaginaDTO<>(
                contenido,
                paginaActual,
                tamanioPagina,
                total,
                totalPaginas,
                paginaActual == 0,
                totalPaginas == 0 || paginaActual >= totalPaginas - 1);
    }

    private String construirFiltros(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo,
                                    String cliente, Long numero, Map<String, Object> params) {
        return construirFiltros(fechaDesde, fechaHasta, estado, montoMinimo, null, cliente, numero, params);
    }

    private String construirFiltros(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo,
                                    Long clienteId, String cliente, Long numero, Map<String, Object> params) {
        StringBuilder filtros = new StringBuilder();

        // Cliente elegido en el buscador (pop-up): filtro exacto por su id.
        if (clienteId != null) {
            filtros.append("AND c.id = :clienteId ");
            params.put("clienteId", clienteId);
        }

        // Cliente: parte del nombre o del CUIT. Las facturas sin cliente se encuentran como "Consumidor Final".
        if (cliente != null && !cliente.trim().isEmpty()) {
            String digitos = cliente.replaceAll("\\D", "");
            filtros.append("AND (LOWER(COALESCE(c.denominacion, 'Consumidor Final')) LIKE :cliente ");
            if (!digitos.isEmpty()) {
                // El CUIT se compara solo por sus dígitos: 20-12345678-9 y 20123456789 son lo mismo.
                filtros.append("OR REPLACE(COALESCE(c.cuitCuil, ''), '-', '') LIKE :clienteCuit ");
                params.put("clienteCuit", "%" + digitos + "%");
            }
            filtros.append(") ");
            params.put("cliente", "%" + cliente.trim().toLowerCase(Locale.ROOT) + "%");
        }
        // Número de comprobante: el que se ve en el listado (el de AFIP si ya tiene CAE, si no el interno).
        if (numero != null) {
            filtros.append("AND COALESCE(f.numeroAfip, f.numero) = :numero ");
            params.put("numero", numero);
        }

        if (fechaDesde != null) {
            filtros.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            filtros.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            filtros.append("AND f.estado = :estado ");
            params.put("estado", estado.trim().toUpperCase());
        }
        if (montoMinimo != null) {
            filtros.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }

        return filtros.toString();
    }

    @Transactional(readOnly = true)
    public FacturaDetalleDTO obtenerDetalle(Long id) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }
        return toDetalle(factura);
    }

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.getPuntoVentaId() == null || dto.getCondicionIvaId() == null || dto.getTipoMonedaId() == null) {
            throw new IllegalArgumentException("Los IDs de PuntoVenta, CondicionIva y TipoMoneda son requeridos");
        }
        exigirRenglones(dto.getDetalles());

        PuntoVenta puntoVenta = em.find(PuntoVenta.class, dto.getPuntoVentaId());
        CondicionIva condicionIva = em.find(CondicionIva.class, dto.getCondicionIvaId());
        TipoMoneda tipoMoneda = em.find(TipoMoneda.class, dto.getTipoMonedaId());

        if (puntoVenta == null) throw new RecursoNoEncontradoException("Punto de venta no encontrado con ID: " + dto.getPuntoVentaId());
        if (condicionIva == null) throw new RecursoNoEncontradoException("Condición de IVA no encontrada con ID: " + dto.getCondicionIvaId());
        if (tipoMoneda == null) throw new RecursoNoEncontradoException("Tipo de moneda no encontrado con ID: " + dto.getTipoMonedaId());

        Cliente cliente = null;
        if (dto.getClienteId() != null) {
            cliente = em.find(Cliente.class, dto.getClienteId());
            if (cliente == null) throw new RecursoNoEncontradoException("Cliente no encontrado con ID: " + dto.getClienteId());
        }

        FacturaVenta factura = new FacturaVenta();
        factura.setFechaEmision(dto.getFechaEmision() != null ? dto.getFechaEmision() : new Date());
        factura.setPuntoVenta(puntoVenta);
        factura.setCondicionIva(condicionIva);
        factura.setTipoMoneda(tipoMoneda);
        factura.setCliente(cliente);
        factura.setImporteCobrado(dto.getImporteCobrado());
        factura.setObservaciones(dto.getObservaciones());
        factura.setTipoComprobante(dto.getTipoComprobante());
        factura.setEstado(dto.getEstado() != null && !dto.getEstado().trim().isEmpty()
                ? dto.getEstado().trim().toUpperCase()
                : "ACTIVA");

        Long maxNum = em.createQuery("SELECT MAX(f.numero) FROM FacturaVenta f", Long.class).getSingleResult();
        factura.setNumero(maxNum == null ? 1 : maxNum + 1);

        agregarDetalles(factura, dto.getDetalles());

        em.persist(factura);
        em.flush();

        if (afipProperties.isAutoEmitir()
                && afipProperties.getModo() != AfipProperties.Modo.DESHABILITADO) {
            try {
                CaeResultado resultado = afipService.emitir(factura, factura.getTipoComprobante());
                aplicarResultadoCae(factura, resultado);
                em.flush();
            } catch (AfipException e) {
                factura.setMotivoRechazo(e.getMessage());
            }
        }

        return toReporte(factura);
    }

    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }

        if (tieneCae(factura)) {
            validarEdicionConCae(factura, dto);
        }

        if (dto.getEstado() != null && !dto.getEstado().trim().isEmpty()) {
            String nuevoEstado = dto.getEstado().trim().toUpperCase();
            factura.setEstado(nuevoEstado);
            if ("ANULADA".equals(nuevoEstado) && factura.getFechaAnulacion() == null) {
                factura.setFechaAnulacion(new Date());
                factura.darDeBaja();
            }
        }

        if (dto.getObservaciones() != null) {
            factura.setObservaciones(dto.getObservaciones());
        }

        if (dto.getFechaEmision() != null) {
            factura.setFechaEmision(dto.getFechaEmision());
        }

        if (dto.getPuntoVentaId() != null) {
            PuntoVenta pv = em.find(PuntoVenta.class, dto.getPuntoVentaId());
            if (pv == null) throw new RecursoNoEncontradoException("Punto de venta no encontrado con ID: " + dto.getPuntoVentaId());
            factura.setPuntoVenta(pv);
        }

        if (dto.isSinCliente()) {
            factura.setCliente(null);
        } else if (dto.getClienteId() != null) {
            Cliente cli = em.find(Cliente.class, dto.getClienteId());
            if (cli == null) throw new RecursoNoEncontradoException("Cliente no encontrado con ID: " + dto.getClienteId());
            factura.setCliente(cli);
        }

        if (dto.getCondicionIvaId() != null) {
            CondicionIva ci = em.find(CondicionIva.class, dto.getCondicionIvaId());
            if (ci == null) throw new RecursoNoEncontradoException("Condición de IVA no encontrada con ID: " + dto.getCondicionIvaId());
            factura.setCondicionIva(ci);
        }

        if (dto.getTipoMonedaId() != null) {
            TipoMoneda tm = em.find(TipoMoneda.class, dto.getTipoMonedaId());
            if (tm == null) throw new RecursoNoEncontradoException("Tipo de moneda no encontrado con ID: " + dto.getTipoMonedaId());
            factura.setTipoMoneda(tm);
        }

        if (dto.getTipoComprobante() != null) {
            factura.setTipoComprobante(dto.getTipoComprobante());
        }

        if (dto.getImporteCobrado() > 0) {
            factura.setImporteCobrado(dto.getImporteCobrado());
        }

        if (dto.getDetalles() != null) {
            exigirRenglones(dto.getDetalles());
            factura.getDetalles().clear();
            agregarDetalles(factura, dto.getDetalles());
        }

        factura.calcularTotal();
        em.merge(factura);

        return toReporte(factura);
    }

    @Transactional
    public FacturaDetalleDTO emitirCae(Long id, Integer tipoComprobante) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }

        CaeResultado resultado = afipService.emitir(factura, tipoComprobante);
        aplicarResultadoCae(factura, resultado);
        em.flush();

        return toDetalle(factura);
    }

    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }
        if (tieneCae(factura)) {
            throw new IllegalStateException("No se puede eliminar la factura: ya fue autorizada por AFIP (CAE "
                    + factura.getCae() + "). Un comprobante autorizado se anula emitiendo una Nota de Crédito.");
        }
        em.remove(factura);
    }

    /** Una factura necesita al menos un renglón: sin ítems no hay nada que facturar (se informa como 400). */
    private void exigirRenglones(List<FacturaDetalleRequestDTO> detalles) {
        if (detalles == null || detalles.isEmpty()) {
            throw new IllegalArgumentException("La factura debe tener al menos un renglón (detalles).");
        }
    }

    private void agregarDetalles(FacturaVenta factura, List<FacturaDetalleRequestDTO> detalles) {
        if (detalles == null) return;
        for (FacturaDetalleRequestDTO detDto : detalles) {
            if (detDto.getListaPrecioArticuloId() == null) {
                throw new IllegalArgumentException("Cada renglón debe indicar listaPrecioArticuloId "
                        + "(el artículo de una lista de precios).");
            }
            ListaPrecioArticulo precio = em.find(ListaPrecioArticulo.class, detDto.getListaPrecioArticuloId());
            if (precio == null) {
                throw new RecursoNoEncontradoException("Artículo de lista de precios no encontrado con ID: "
                        + detDto.getListaPrecioArticuloId());
            }
            String nombre = precio.getArticulo().getDenominacion();
            if (!(detDto.getCantidad() > 0) || Double.isInfinite(detDto.getCantidad())) {
                throw new IllegalArgumentException("La cantidad de " + nombre + " debe ser mayor a cero.");
            }
            if (detDto.getCantidad() != Math.rint(detDto.getCantidad())) {
                throw new IllegalArgumentException("La cantidad de " + nombre + " debe ser un número entero.");
            }
            double bonificacion = detDto.getPorcentajeBonificacion() == null ? 0 : detDto.getPorcentajeBonificacion();
            if (bonificacion < 0 || bonificacion > 100 || Double.isNaN(bonificacion)) {
                throw new IllegalArgumentException("La bonificación de " + nombre + " debe estar entre 0 y 100.");
            }
            if (detDto.getDescripcion() != null && detDto.getDescripcion().length() > 255) {
                throw new IllegalArgumentException("La descripción de " + nombre + " no puede superar 255 caracteres.");
            }
            factura.agregarDetalle(precio, detDto.getCantidad(), bonificacion, detDto.getDescripcion());
        }
    }

    private static boolean tieneCae(FacturaVenta factura) {
        return factura.getCae() != null && !factura.getCae().isBlank();
    }

    private void validarEdicionConCae(FacturaVenta factura, FacturaRequestDTO dto) {
        List<String> campos = new java.util.ArrayList<>();
        if (dto.getDetalles() != null) campos.add("ítems");
        if (dto.getFechaEmision() != null && !mismaFecha(dto.getFechaEmision(), factura.getFechaEmision())) {
            campos.add("fecha de emisión");
        }
        if (dto.getPuntoVentaId() != null && !dto.getPuntoVentaId().equals(factura.getPuntoVenta().getId())) {
            campos.add("punto de venta");
        }
        if (dto.getClienteId() != null
                && (factura.getCliente() == null || !dto.getClienteId().equals(factura.getCliente().getId()))) {
            campos.add("cliente");
        }
        if (dto.isSinCliente() && factura.getCliente() != null && !campos.contains("cliente")) {
            campos.add("cliente");
        }
        if (dto.getCondicionIvaId() != null && !dto.getCondicionIvaId().equals(factura.getCondicionIva().getId())) {
            campos.add("condición de IVA");
        }
        if (dto.getTipoMonedaId() != null && !dto.getTipoMonedaId().equals(factura.getTipoMoneda().getId())) {
            campos.add("moneda");
        }
        if (dto.getTipoComprobante() != null && !dto.getTipoComprobante().equals(factura.getTipoComprobante())) {
            campos.add("tipo de comprobante");
        }
        // Una factura informada a ARCA ya no se edita: lo único permitido es la baja lógica (anularla),
        // y las observaciones solo como motivo de esa anulación.
        boolean anulando = dto.getEstado() != null && "ANULADA".equalsIgnoreCase(dto.getEstado().trim());
        if (dto.getEstado() != null && !dto.getEstado().trim().isEmpty() && !anulando
                && !dto.getEstado().trim().equalsIgnoreCase(factura.getEstado())) {
            campos.add("estado");
        }
        if (dto.getObservaciones() != null && !anulando
                && !dto.getObservaciones().equals(factura.getObservaciones())) {
            campos.add("observaciones");
        }
        if (!campos.isEmpty()) {
            throw new IllegalStateException("La factura ya tiene CAE: no se puede modificar "
                    + String.join(", ", campos) + ". Solo se permite anularla (baja lógica).");
        }
    }

    private static boolean mismaFecha(Date a, Date b) {
        if (a == null || b == null) return a == b;
        return new java.sql.Date(a.getTime()).toLocalDate().equals(
                new java.sql.Date(b.getTime()).toLocalDate());
    }

    private void aplicarResultadoCae(FacturaVenta factura, CaeResultado resultado) {
        factura.setTipoComprobante(resultado.tipoComprobante());
        factura.calcularTotal();

        if (resultado.aprobado()) {
            factura.setCae(resultado.cae());
            factura.setCaeFechaVencimiento(resultado.caeVencimiento() == null
                    ? null
                    : java.sql.Date.valueOf(resultado.caeVencimiento()));
            factura.setResultadoAfip(resultado.resultado());
            factura.setNumeroAfip(resultado.numeroComprobante());
            factura.setMotivoRechazo(null);
            factura.setEstado("EMITIDA");
        } else {
            factura.setResultadoAfip(resultado.resultado() == null ? "R" : resultado.resultado());
            factura.setMotivoRechazo(construirMotivo(resultado));
        }
    }

    private String construirMotivo(CaeResultado resultado) {
        StringBuilder motivo = new StringBuilder();
        if (resultado.errores() != null && !resultado.errores().isEmpty()) {
            motivo.append(String.join(" | ", resultado.errores()));
        }
        if (resultado.observaciones() != null && !resultado.observaciones().isEmpty()) {
            if (motivo.length() > 0) motivo.append(" | ");
            motivo.append(String.join(" | ", resultado.observaciones()));
        }
        return motivo.length() == 0 ? "AFIP no autorizó el comprobante." : motivo.toString();
    }

    private FacturaReporteDTO toReporte(FacturaVenta factura) {
        return new FacturaReporteDTO(
                factura.getId(),
                factura.getNumeroAfip() != null ? factura.getNumeroAfip() : factura.getNumero(),
                factura.getFechaEmision(),
                factura.getCliente() != null ? factura.getCliente().getDenominacion() : "Consumidor Final",
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getImporteTotal(),
                factura.getDetalles() == null ? 0 : factura.getDetalles().size(),
                factura.getEstado(),
                factura.getCae(),
                factura.getCaeFechaVencimiento(),
                factura.getResultadoAfip(),
                factura.getTipoComprobante());
    }

    private FacturaDetalleDTO toDetalle(FacturaVenta factura) {
        List<FacturaDetalleDTO.Item> items = factura.getDetalles().stream()
                .map(this::toItem)
                .toList();

        Cliente cliente = factura.getCliente();
        return new FacturaDetalleDTO(
                factura.getId(),
                factura.getNumeroAfip() != null ? factura.getNumeroAfip() : factura.getNumero(),
                factura.getNumeroAfip(),
                factura.getFechaEmision(),
                cliente == null ? null : cliente.getId(),
                cliente == null ? "Consumidor Final" : cliente.getDenominacion(),
                cliente == null ? null : cliente.getCuitCuil(),
                factura.getCondicionIva().getId(),
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getId(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getPuntoVenta().getNumero(),
                factura.getTipoMoneda().getId(),
                factura.getTipoMoneda().getCodigo(),
                factura.getTipoMoneda().getDenominacion(),
                factura.getImporteCobrado(),
                factura.getImporteSaldo(),
                factura.getImporteTotal(),
                factura.getEstado(),
                factura.getObservaciones(),
                factura.getCae(),
                factura.getCaeFechaVencimiento(),
                factura.getResultadoAfip(),
                factura.getMotivoRechazo(),
                factura.getTipoComprobante(),
                factura.getFechaAnulacion(),
                items);
    }

    private FacturaDetalleDTO.Item toItem(FacturaVentaDetalle detalle) {
        ListaPrecioArticulo precio = detalle.getListaPrecioArticulo();
        Articulo articulo = precio.getArticulo();
        return new FacturaDetalleDTO.Item(
                precio.getId(),
                articulo.getId(),
                articulo.getCodigo(),
                articulo.getDenominacion(),
                detalle.getDescripcion(),
                precio.getListaPrecio().getId(),
                precio.getListaPrecio().getDenominacion(),
                articulo.getMarca() == null ? null : articulo.getMarca().getDenominacion(),
                detalle.getCantidad(),
                detalle.getPrecioUnitario(),
                detalle.getPorcentajeBonificacion(),
                detalle.getImporteNeto(),
                detalle.getImporteIva(),
                detalle.getImporteSubtotal());
    }
}
