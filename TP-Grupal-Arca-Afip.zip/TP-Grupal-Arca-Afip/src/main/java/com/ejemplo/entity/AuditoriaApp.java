package com.ejemplo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true, exclude = {"usuarioCarga", "usuarioBaja", "usuarioModificacion"})
public abstract class AuditoriaApp extends EntityId {
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaAlta;

    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaBaja;

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaModificacion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_carga_id", nullable = false, updatable = false)
    protected Usuario usuarioCarga;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_baja_id")
    protected Usuario usuarioBaja;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_modificacion_id", nullable = false)
    protected Usuario usuarioModificacion;

    @PrePersist
    public void prePersist() {
        Date ahora = new Date();
        fechaAlta = ahora;
        fechaModificacion = ahora;
        if (usuarioCarga == null) {
            usuarioCarga = UsuarioActual.obtener();
        }
        if (usuarioModificacion == null) {
            usuarioModificacion = usuarioCarga;
        }
    }

    @PreUpdate
    public void preUpdate() {
        fechaModificacion = new Date();
        if (UsuarioActual.obtener() != null) {
            usuarioModificacion = UsuarioActual.obtener();
        }
    }

    public void darDeBaja() {
        fechaBaja = new Date();
        usuarioBaja = UsuarioActual.obtener();
    }
}
