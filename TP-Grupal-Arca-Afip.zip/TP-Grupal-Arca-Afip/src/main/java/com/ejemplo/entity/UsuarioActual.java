package com.ejemplo.entity;

public final class UsuarioActual {
    private static volatile Usuario usuario;

    private UsuarioActual() {
    }

    public static void establecer(Usuario nuevo) {
        usuario = nuevo;
    }

    public static Usuario obtener() {
        return usuario;
    }
}
