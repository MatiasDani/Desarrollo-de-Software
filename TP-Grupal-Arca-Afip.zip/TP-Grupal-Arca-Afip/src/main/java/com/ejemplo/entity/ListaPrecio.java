package com.ejemplo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lista_precio")
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"articulos"})
@EqualsAndHashCode(callSuper = true, exclude = {"articulos"})
public class ListaPrecio extends AuditoriaApp {
    @Column(nullable = false, unique = true)
    private String codigo;

    @Column(nullable = false)
    private String denominacion;

    @OneToMany(mappedBy = "listaPrecio", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ListaPrecioArticulo> articulos = new ArrayList<>();

    public ListaPrecio(String codigo, String denominacion) {
        this.codigo = codigo;
        this.denominacion = denominacion;
    }

    public ListaPrecioArticulo agregarArticulo(Articulo articulo, double precioVenta) {
        ListaPrecioArticulo item = new ListaPrecioArticulo();
        item.setListaPrecio(this);
        item.setArticulo(articulo);
        item.setPrecioVenta(precioVenta);
        articulos.add(item);
        return item;
    }
}
