package com.ejemplo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "lista_precio_articulo",
        uniqueConstraints = @UniqueConstraint(columnNames = {"lista_precio_id", "articulo_id"}))
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"listaPrecio"})
@EqualsAndHashCode(callSuper = true, exclude = {"listaPrecio"})
public class ListaPrecioArticulo extends AuditoriaApp {
    @ManyToOne
    @JoinColumn(name = "lista_precio_id", nullable = false)
    private ListaPrecio listaPrecio;

    @Column(nullable = false)
    private double precioVenta;

    @ManyToOne
    @JoinColumn(name = "articulo_id", nullable = false)
    private Articulo articulo;
}
