package com.ejemplo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.Transient;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "factura_venta")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = true, exclude = {"detalles"})
@ToString(exclude = {"detalles"})
public class FacturaVenta extends AuditoriaApp {
    private Long numero;

    private Long numeroAfip;

    private Integer tipoComprobante;

    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaEmision;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "punto_venta_id", nullable = false)
    private PuntoVenta puntoVenta;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id", nullable = true)
    private Cliente cliente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "condicion_iva_id", nullable = false)
    private CondicionIva condicionIva;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tipo_moneda_id", nullable = false)
    private TipoMoneda tipoMoneda;

    private double importeCobrado;
    private double importeSaldo;

    @Column(nullable = false)
    private double importeTotal;
    private String cae;
    @Temporal(TemporalType.DATE)
    private Date caeFechaVencimiento;
    private String resultadoAfip;
    private String motivoRechazo;

    @Column(nullable = false)
    private String estado;

    @Temporal(TemporalType.DATE)
    private Date fechaAnulacion;
    private String observaciones;

    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<FacturaVentaDetalle> detalles = new ArrayList<>();

    /**
     * Neto gravado e IVA de toda la factura. Son @Transient: JPA no los guarda en la tabla
     * (no hay columna) porque se calculan a partir de los renglones en calcularTotal().
     */
    @Transient
    private double importeNetoGravado;

    @Transient
    private double importeIvaTotal;

    public static final double ALICUOTA_IVA = 21.0;

    public void addDetalle(FacturaVentaDetalle detalle) {
        detalle.setFactura(this);
        detalles.add(detalle);
        calcularTotal();
    }

    public void agregarDetalle(ListaPrecioArticulo precio, double cantidad) {
        agregarDetalle(precio, cantidad, 0, null);
    }

    public void agregarDetalle(ListaPrecioArticulo precio, double cantidad, double porcentajeBonificacion,
                               String descripcion) {
        FacturaVentaDetalle detalle = new FacturaVentaDetalle();
        detalle.setListaPrecioArticulo(precio);
        detalle.setDescripcion(descripcion == null || descripcion.isBlank()
                ? precio.getArticulo().getDenominacion()
                : descripcion.trim());
        detalle.setCantidad(cantidad);
        detalle.setPrecioUnitario(precio.getPrecioVenta());
        detalle.setPorcentajeBonificacion(porcentajeBonificacion);
        addDetalle(detalle);
    }

    public void calcularTotal() {
        boolean discriminaIva = tipoComprobante != null && (tipoComprobante == 1 || tipoComprobante == 6);
        double total = 0;
        double netoTotal = 0;
        double ivaTotal = 0;
        for (FacturaVentaDetalle d : detalles) {
            double subtotal = redondear(d.getCantidad() * d.getPrecioUnitario()
                    * (1 - d.getPorcentajeBonificacion() / 100));
            double neto = discriminaIva ? redondear(subtotal / (1 + ALICUOTA_IVA / 100)) : subtotal;
            d.setImporteSubtotal(subtotal);
            d.setImporteNeto(neto);
            d.setImporteIva(redondear(subtotal - neto));
            total = total + subtotal;
            netoTotal = netoTotal + d.getImporteNeto();
            ivaTotal = ivaTotal + d.getImporteIva();
        }
        importeTotal = redondear(total);
        importeNetoGravado = redondear(netoTotal);
        importeIvaTotal = redondear(ivaTotal);
        importeSaldo = redondear(importeTotal - importeCobrado);
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
