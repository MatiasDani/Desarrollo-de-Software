package com.ejemplo.controller;

import com.ejemplo.afip.dto.EmisionCaeRequestDTO;
import com.ejemplo.dto.FacturaDetalleDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ResumenFacturacionDTO;
import com.ejemplo.service.FacturaService;
import com.ejemplo.service.ReporteService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Date;
import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/facturas")
public class FacturaRestController {
    private final FacturaService facturaService;
    private final ReporteService reporteService;
    private final com.ejemplo.service.ComprobantePdfService comprobantePdfService;

    public FacturaRestController(FacturaService facturaService, ReporteService reporteService,
                                 com.ejemplo.service.ComprobantePdfService comprobantePdfService) {
        this.facturaService = facturaService;
        this.reporteService = reporteService;
        this.comprobantePdfService = comprobantePdfService;
    }

    @GetMapping
    public ResponseEntity<List<FacturaReporteDTO>> buscarFacturas(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(required = false) Long clienteId,
            @RequestParam(required = false) String cliente,
            @RequestParam(required = false) Long numero,
            @RequestParam(required = false) String orden) {
        List<FacturaReporteDTO> facturas = facturaService.buscarFacturasFiltradas(
                fechaDesde, fechaHasta, estado, montoMinimo, clienteId, cliente, numero, orden);
        return ResponseEntity.ok(facturas);
    }

    @GetMapping("/paginado")
    public ResponseEntity<PaginaDTO<FacturaReporteDTO>> buscarFacturasPaginadas(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(required = false) Long clienteId,
            @RequestParam(required = false) String cliente,
            @RequestParam(required = false) Long numero,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamanio,
            @RequestParam(required = false) String orden) {
        PaginaDTO<FacturaReporteDTO> resultado = facturaService.buscarFacturasPaginadas(
                fechaDesde, fechaHasta, estado, montoMinimo, clienteId, cliente, numero, pagina, tamanio, orden);
        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/resumen")
    public ResponseEntity<ResumenFacturacionDTO> obtenerResumen(
            @RequestParam(defaultValue = "5") int ultimas) {
        return ResponseEntity.ok(facturaService.obtenerResumen(ultimas));
    }

    @GetMapping("/{id}")
    public ResponseEntity<FacturaDetalleDTO> obtenerFactura(@PathVariable Long id) {
        return ResponseEntity.ok(facturaService.obtenerDetalle(id));
    }

    /** Comprobante de una factura en PDF, para ver o imprimir (se abre en el navegador). */
    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> imprimirFactura(@PathVariable Long id) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=factura-" + id + ".pdf")
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE)
                .body(comprobantePdfService.generar(id));
    }

    @GetMapping("/reporte/pdf")
    public ResponseEntity<byte[]> descargarPdf() {
        byte[] pdf = reporteService.generarPdf();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.pdf")
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE)
                .body(pdf);
    }

    @GetMapping("/reporte/excel")
    public ResponseEntity<byte[]> descargarExcel() throws IOException {
        byte[] excel = reporteService.generarExcel();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.xlsx")
                .header(HttpHeaders.CONTENT_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                .body(excel);
    }

    @GetMapping("/reporte/txt")
    public ResponseEntity<byte[]> descargarTxt() {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.txt")
                .header(HttpHeaders.CONTENT_TYPE, "text/tab-separated-values; charset=UTF-8")
                .body(reporteService.generarTxt());
    }

    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crearFactura(@RequestBody FacturaRequestDTO dto) {
        FacturaReporteDTO reporte = facturaService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(reporte);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FacturaReporteDTO> actualizarFactura(@PathVariable Long id, @RequestBody FacturaRequestDTO dto) {
        FacturaReporteDTO reporte = facturaService.actualizar(id, dto);
        return ResponseEntity.ok(reporte);
    }

    @PostMapping("/{id}/emitir")
    public ResponseEntity<FacturaDetalleDTO> emitirCae(
            @PathVariable Long id,
            @RequestBody(required = false) EmisionCaeRequestDTO request) {
        Integer tipo = request == null ? null : request.tipoComprobante();
        return ResponseEntity.ok(facturaService.emitirCae(id, tipo));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarFactura(@PathVariable Long id) {
        facturaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
