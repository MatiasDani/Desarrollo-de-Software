package com.ejemplo.controller;

import com.ejemplo.dto.CatalogoDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ProductoCatalogoDTO;
import com.ejemplo.service.BusquedaCatalogoService;
import com.ejemplo.entity.Cliente;
import com.ejemplo.repository.ArticuloRepository;
import com.ejemplo.repository.ClienteRepository;
import com.ejemplo.repository.CondicionIvaRepository;
import com.ejemplo.repository.ListaPrecioArticuloRepository;
import com.ejemplo.repository.ListaPrecioRepository;
import com.ejemplo.repository.PuntoVentaRepository;
import com.ejemplo.repository.TipoMonedaRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/catalogos")
@Transactional(readOnly = true)
public class CatalogoController {
    private final PuntoVentaRepository puntoVentaRepository;
    private final ClienteRepository clienteRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final ArticuloRepository articuloRepository;
    private final ListaPrecioRepository listaPrecioRepository;
    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;
    private final BusquedaCatalogoService busquedaCatalogoService;

    public CatalogoController(PuntoVentaRepository puntoVentaRepository,
                              ClienteRepository clienteRepository,
                              CondicionIvaRepository condicionIvaRepository,
                              TipoMonedaRepository tipoMonedaRepository,
                              ArticuloRepository articuloRepository,
                              ListaPrecioRepository listaPrecioRepository,
                              ListaPrecioArticuloRepository listaPrecioArticuloRepository,
                              BusquedaCatalogoService busquedaCatalogoService) {
        this.busquedaCatalogoService = busquedaCatalogoService;
        this.puntoVentaRepository = puntoVentaRepository;
        this.clienteRepository = clienteRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.articuloRepository = articuloRepository;
        this.listaPrecioRepository = listaPrecioRepository;
        this.listaPrecioArticuloRepository = listaPrecioArticuloRepository;
    }

    @GetMapping
    public CatalogoDTO obtenerCatalogos() {
        return new CatalogoDTO(
                puntosVenta(), clientes(), condicionesIva(), monedas(), articulos(),
                listasPrecio(), listaPrecioArticulos());
    }

    @GetMapping("/puntos-venta")
    public List<CatalogoDTO.PuntoVentaItem> puntosVenta() {
        return puntoVentaRepository.findAll().stream()
                .map(pv -> new CatalogoDTO.PuntoVentaItem(pv.getId(), pv.getNumero(), pv.getDescripcion(),
                        pv.getDomicilioComercial(), pv.getTipoEmision()))
                .toList();
    }

    @GetMapping("/clientes")
    public List<CatalogoDTO.ClienteItem> clientes() {
        return clienteRepository.findAll().stream().map(CatalogoController::toClienteItem).toList();
    }

    @GetMapping("/condiciones-iva")
    public List<CatalogoDTO.CondicionIvaItem> condicionesIva() {
        return condicionIvaRepository.findAll().stream()
                .map(ci -> new CatalogoDTO.CondicionIvaItem(ci.getId(), ci.getCodigoAfip(), ci.getDenominacion()))
                .toList();
    }

    @GetMapping("/monedas")
    public List<CatalogoDTO.MonedaItem> monedas() {
        return tipoMonedaRepository.findAll().stream()
                .map(tm -> new CatalogoDTO.MonedaItem(tm.getId(), tm.getCodigo(), tm.getCodigoAfip(),
                        tm.getDenominacion(), tm.getSimbolo(), tm.getCotizacion()))
                .toList();
    }

    @GetMapping("/articulos")
    public List<CatalogoDTO.ArticuloItem> articulos() {
        return articuloRepository.findAll().stream()
                .map(a -> new CatalogoDTO.ArticuloItem(a.getId(), a.getCodigo(), a.getDenominacion(),
                        a.getMarca() == null ? null : a.getMarca().getDenominacion(),
                        a.getRubro() == null ? null : a.getRubro().getDenominacion()))
                .toList();
    }

    @GetMapping("/listas-precio")
    public List<CatalogoDTO.ListaPrecioItem> listasPrecio() {
        return listaPrecioRepository.findAll().stream()
                .map(lp -> new CatalogoDTO.ListaPrecioItem(lp.getId(), lp.getCodigo(), lp.getDenominacion()))
                .toList();
    }

    @GetMapping("/lista-precio-articulos")
    public List<CatalogoDTO.ListaPrecioArticuloItem> listaPrecioArticulos() {
        return listaPrecioArticuloRepository.findAll().stream()
                .map(lpa -> new CatalogoDTO.ListaPrecioArticuloItem(lpa.getId(), lpa.getListaPrecio().getId(),
                        lpa.getArticulo().getId(), lpa.getPrecioVenta()))
                .toList();
    }

    /** Explorador de productos: búsqueda (código, denominación, rubro, marca o lista) paginada en la base. */
    @GetMapping("/productos")
    public PaginaDTO<ProductoCatalogoDTO> buscarProductos(
            @RequestParam(required = false) String buscar,
            @RequestParam(required = false) Long listaPrecioId,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "8") int tamanio) {
        return busquedaCatalogoService.buscarProductos(buscar, listaPrecioId, pagina, tamanio);
    }

    /** Pop-up "Buscar cliente": por CUIT/CUIL (con o sin guiones) o razón social, paginado en la base. */
    @GetMapping("/clientes/buscar")
    public PaginaDTO<CatalogoDTO.ClienteItem> buscarClientes(
            @RequestParam(required = false) String cuit,
            @RequestParam(required = false) String razonSocial,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "8") int tamanio) {
        return busquedaCatalogoService.buscarClientes(cuit, razonSocial, pagina, tamanio,
                CatalogoController::toClienteItem);
    }

    private static CatalogoDTO.ClienteItem toClienteItem(Cliente c) {
        return new CatalogoDTO.ClienteItem(
                c.getId(),
                c.getDenominacion(),
                c.getCuitCuil(),
                c.getContacto() == null ? null : c.getContacto().getEmail(),
                c.getContacto() == null ? null : c.getContacto().getTelefono(),
                c.getDomicilio() == null ? null : c.getDomicilio().toString(),
                c.getCondicionIva() == null ? null : c.getCondicionIva().getId(),
                c.getCondicionIva() == null ? null : c.getCondicionIva().getDenominacion());
    }
}
