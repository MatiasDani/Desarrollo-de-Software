import type {
    AfipConexionDTO,
    AfipEstadoDTO,
    CatalogoDTO,
    ClienteItem,
    ProductoCatalogoDTO,
    FacturaDetalleDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO,
    MonedaItem,
    MonedasSyncDTO,
    OrdenFacturas,
    PaginaDTO,
    ResumenFacturacionDTO
} from './models/factura.dto.js';

/** Cliente HTTP de la API REST (async/await + fetch). Centraliza todas las llamadas al backend. */
export class FacturaService {
    constructor(private readonly baseUrl: string = '/api') {}

    private async request<T>(path: string, options: RequestInit = {}): Promise<T> {
        const { headers, ...rest } = options;
        const response = await fetch(`${this.baseUrl}${path}`, {
            ...rest,
            headers: { 'Accept': 'application/json', ...(headers as Record<string, string> | undefined) }
        });

        const contentType = response.headers.get('content-type') || '';
        let data: { message?: string } | null = null;

        if (contentType.includes('application/json')) {
            data = await response.json().catch(() => null);
        } else {
            const text = await response.text().catch(() => '');
            data = text ? { message: text } : null;
        }

        if (!response.ok) {
            const message = data && data.message
                ? data.message
                : `Error HTTP ${response.status} al comunicarse con el servidor.`;
            throw new Error(message);
        }
        return data as T;
    }

    private static parametrosDeFiltros(filtros?: FacturaFiltrosDTO): URLSearchParams {
        const params = new URLSearchParams();
        if (filtros) {
            if (filtros.clienteId) params.append('clienteId', String(filtros.clienteId));
            if (filtros.cliente) params.append('cliente', filtros.cliente);
            if (filtros.numero !== undefined && filtros.numero !== null && !isNaN(filtros.numero)) {
                params.append('numero', String(filtros.numero));
            }
            if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
            if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
            if (filtros.estado) params.append('estado', filtros.estado);
            if (filtros.montoMinimo !== undefined && filtros.montoMinimo !== null && !isNaN(filtros.montoMinimo)) {
                params.append('montoMinimo', filtros.montoMinimo.toString());
            }
        }
        return params;
    }

    // --- Facturas ----------------------------------------------------------

    /** GET /api/facturas (filtros opcionales: fechaDesde, fechaHasta, estado, montoMinimo; orden opcional). */
    obtenerFacturas(filtros?: FacturaFiltrosDTO, orden?: OrdenFacturas): Promise<FacturaReporteDTO[]> {
        const params = FacturaService.parametrosDeFiltros(filtros);
        if (orden) params.append('orden', orden);
        const qs = params.toString();
        return this.request<FacturaReporteDTO[]>(`/facturas${qs ? `?${qs}` : ''}`);
    }

    /** GET /api/facturas/resumen: totales del panel calculados en la base. */
    obtenerResumen(ultimas = 5): Promise<ResumenFacturacionDTO> {
        return this.request<ResumenFacturacionDTO>(`/facturas/resumen?ultimas=${ultimas}`);
    }

    /** GET /api/facturas/paginado (pagina en base 0; sin orden, el backend usa fecha_desc). */
    obtenerFacturasPaginadas(
        filtros?: FacturaFiltrosDTO,
        pagina = 0,
        tamanio = 10,
        orden?: OrdenFacturas
    ): Promise<PaginaDTO<FacturaReporteDTO>> {
        const params = FacturaService.parametrosDeFiltros(filtros);
        params.append('pagina', String(Math.max(0, pagina)));
        params.append('tamanio', String(tamanio));
        if (orden) params.append('orden', orden);
        return this.request<PaginaDTO<FacturaReporteDTO>>(`/facturas/paginado?${params.toString()}`);
    }

    /** GET /api/facturas/{id}: detalle completo con ítems y datos fiscales. */
    obtenerFactura(id: number): Promise<FacturaDetalleDTO> {
        return this.request<FacturaDetalleDTO>(`/facturas/${id}`);
    }

    /** POST /api/facturas (responde 201 Created con el FacturaReporteDTO). */
    crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        return this.request<FacturaReporteDTO>('/facturas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
    }

    /** PUT /api/facturas/{id}. */
    actualizarFactura(id: number, factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        return this.request<FacturaReporteDTO>(`/facturas/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
    }

    /** Atajo de PUT para anular o cambiar observaciones. */
    actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO> {
        return this.actualizarFactura(id, { estado, observaciones });
    }

    /** POST /api/facturas/{id}/emitir: solicita el CAE (real o simulado). */
    emitirCae(id: number, tipoComprobante?: number): Promise<FacturaDetalleDTO> {
        return this.request<FacturaDetalleDTO>(`/facturas/${id}/emitir`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tipoComprobante ? { tipoComprobante } : {})
        });
    }

    /** URL del comprobante en PDF (GET /api/facturas/{id}/pdf) para verlo o imprimirlo. */
    urlPdfFactura(id: number): string {
        return `${this.baseUrl}/facturas/${id}/pdf`;
    }

    /** DELETE /api/facturas/{id} (responde 204 No Content). */
    eliminarFactura(id: number): Promise<void> {
        return this.request<void>(`/facturas/${id}`, { method: 'DELETE' });
    }

    // --- Catálogos ---------------------------------------------------------

    obtenerCatalogos(): Promise<CatalogoDTO> {
        return this.request<CatalogoDTO>('/catalogos');
    }

    /** GET /api/catalogos/productos: búsqueda paginada en la base (COUNT + página). */
    buscarProductos(buscar: string, listaPrecioId: number | null, pagina = 0, tamanio = 8): Promise<PaginaDTO<ProductoCatalogoDTO>> {
        const params = new URLSearchParams({ pagina: String(pagina), tamanio: String(tamanio) });
        if (buscar.trim()) params.append('buscar', buscar.trim());
        if (listaPrecioId) params.append('listaPrecioId', String(listaPrecioId));
        return this.request<PaginaDTO<ProductoCatalogoDTO>>(`/catalogos/productos?${params.toString()}`);
    }

    /** GET /api/catalogos/clientes/buscar: por CUIT/CUIL o razón social, paginado en la base. */
    buscarClientes(cuit: string, razonSocial: string, pagina = 0, tamanio = 8): Promise<PaginaDTO<ClienteItem>> {
        const params = new URLSearchParams({ pagina: String(pagina), tamanio: String(tamanio) });
        if (cuit.trim()) params.append('cuit', cuit.trim());
        if (razonSocial.trim()) params.append('razonSocial', razonSocial.trim());
        return this.request<PaginaDTO<ClienteItem>>(`/catalogos/clientes/buscar?${params.toString()}`);
    }

    // --- AFIP --------------------------------------------------------------

    obtenerEstadoAfip(): Promise<AfipEstadoDTO> {
        return this.request<AfipEstadoDTO>('/afip/estado');
    }

    probarConexionAfip(): Promise<AfipConexionDTO> {
        return this.request<AfipConexionDTO>('/afip/dummy', { method: 'POST' });
    }

    limpiarCacheAfip(): Promise<void> {
        return this.request<void>('/afip/cache', { method: 'DELETE' });
    }

    obtenerMonedasAfip(): Promise<MonedaItem[]> {
        return this.request<MonedaItem[]>('/afip/monedas');
    }

    sincronizarMonedasAfip(): Promise<MonedasSyncDTO> {
        return this.request<MonedasSyncDTO>('/afip/monedas/sincronizar', { method: 'POST' });
    }
}
