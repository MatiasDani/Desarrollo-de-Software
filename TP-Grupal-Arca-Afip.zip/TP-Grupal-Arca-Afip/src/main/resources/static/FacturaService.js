/** Cliente HTTP de la API REST (async/await + fetch). Centraliza todas las llamadas al backend. */
export class FacturaService {
    baseUrl;
    constructor(baseUrl = '/api') {
        this.baseUrl = baseUrl;
    }
    async request(path, options = {}) {
        const { headers, ...rest } = options;
        const response = await fetch(`${this.baseUrl}${path}`, {
            ...rest,
            headers: { 'Accept': 'application/json', ...headers }
        });
        const contentType = response.headers.get('content-type') || '';
        let data = null;
        if (contentType.includes('application/json')) {
            data = await response.json().catch(() => null);
        }
        else {
            const text = await response.text().catch(() => '');
            data = text ? { message: text } : null;
        }
        if (!response.ok) {
            const message = data && data.message
                ? data.message
                : `Error HTTP ${response.status} al comunicarse con el servidor.`;
            throw new Error(message);
        }
        return data;
    }
    static parametrosDeFiltros(filtros) {
        const params = new URLSearchParams();
        if (filtros) {
            if (filtros.clienteId)
                params.append('clienteId', String(filtros.clienteId));
            if (filtros.cliente)
                params.append('cliente', filtros.cliente);
            if (filtros.numero !== undefined && filtros.numero !== null && !isNaN(filtros.numero)) {
                params.append('numero', String(filtros.numero));
            }
            if (filtros.fechaDesde)
                params.append('fechaDesde', filtros.fechaDesde);
            if (filtros.fechaHasta)
                params.append('fechaHasta', filtros.fechaHasta);
            if (filtros.estado)
                params.append('estado', filtros.estado);
            if (filtros.montoMinimo !== undefined && filtros.montoMinimo !== null && !isNaN(filtros.montoMinimo)) {
                params.append('montoMinimo', filtros.montoMinimo.toString());
            }
        }
        return params;
    }
    // --- Facturas ----------------------------------------------------------
    /** GET /api/facturas (filtros opcionales: fechaDesde, fechaHasta, estado, montoMinimo; orden opcional). */
    obtenerFacturas(filtros, orden) {
        const params = FacturaService.parametrosDeFiltros(filtros);
        if (orden)
            params.append('orden', orden);
        const qs = params.toString();
        return this.request(`/facturas${qs ? `?${qs}` : ''}`);
    }
    /** GET /api/facturas/resumen: totales del panel calculados en la base. */
    obtenerResumen(ultimas = 5) {
        return this.request(`/facturas/resumen?ultimas=${ultimas}`);
    }
    /** GET /api/facturas/paginado (pagina en base 0; sin orden, el backend usa fecha_desc). */
    obtenerFacturasPaginadas(filtros, pagina = 0, tamanio = 10, orden) {
        const params = FacturaService.parametrosDeFiltros(filtros);
        params.append('pagina', String(Math.max(0, pagina)));
        params.append('tamanio', String(tamanio));
        if (orden)
            params.append('orden', orden);
        return this.request(`/facturas/paginado?${params.toString()}`);
    }
    /** GET /api/facturas/{id}: detalle completo con ítems y datos fiscales. */
    obtenerFactura(id) {
        return this.request(`/facturas/${id}`);
    }
    /** POST /api/facturas (responde 201 Created con el FacturaReporteDTO). */
    crearFactura(factura) {
        return this.request('/facturas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
    }
    /** PUT /api/facturas/{id}. */
    actualizarFactura(id, factura) {
        return this.request(`/facturas/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
    }
    /** Atajo de PUT para anular o cambiar observaciones. */
    actualizarEstado(id, estado, observaciones) {
        return this.actualizarFactura(id, { estado, observaciones });
    }
    /** POST /api/facturas/{id}/emitir: solicita el CAE (real o simulado). */
    emitirCae(id, tipoComprobante) {
        return this.request(`/facturas/${id}/emitir`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tipoComprobante ? { tipoComprobante } : {})
        });
    }
    /** URL del comprobante en PDF (GET /api/facturas/{id}/pdf) para verlo o imprimirlo. */
    urlPdfFactura(id) {
        return `${this.baseUrl}/facturas/${id}/pdf`;
    }
    /** DELETE /api/facturas/{id} (responde 204 No Content). */
    eliminarFactura(id) {
        return this.request(`/facturas/${id}`, { method: 'DELETE' });
    }
    // --- Catálogos ---------------------------------------------------------
    obtenerCatalogos() {
        return this.request('/catalogos');
    }
    /** GET /api/catalogos/productos: búsqueda paginada en la base (COUNT + página). */
    buscarProductos(buscar, listaPrecioId, pagina = 0, tamanio = 8) {
        const params = new URLSearchParams({ pagina: String(pagina), tamanio: String(tamanio) });
        if (buscar.trim())
            params.append('buscar', buscar.trim());
        if (listaPrecioId)
            params.append('listaPrecioId', String(listaPrecioId));
        return this.request(`/catalogos/productos?${params.toString()}`);
    }
    /** GET /api/catalogos/clientes/buscar: por CUIT/CUIL o razón social, paginado en la base. */
    buscarClientes(cuit, razonSocial, pagina = 0, tamanio = 8) {
        const params = new URLSearchParams({ pagina: String(pagina), tamanio: String(tamanio) });
        if (cuit.trim())
            params.append('cuit', cuit.trim());
        if (razonSocial.trim())
            params.append('razonSocial', razonSocial.trim());
        return this.request(`/catalogos/clientes/buscar?${params.toString()}`);
    }
    // --- AFIP --------------------------------------------------------------
    obtenerEstadoAfip() {
        return this.request('/afip/estado');
    }
    probarConexionAfip() {
        return this.request('/afip/dummy', { method: 'POST' });
    }
    limpiarCacheAfip() {
        return this.request('/afip/cache', { method: 'DELETE' });
    }
    obtenerMonedasAfip() {
        return this.request('/afip/monedas');
    }
    sincronizarMonedasAfip() {
        return this.request('/afip/monedas/sincronizar', { method: 'POST' });
    }
}
