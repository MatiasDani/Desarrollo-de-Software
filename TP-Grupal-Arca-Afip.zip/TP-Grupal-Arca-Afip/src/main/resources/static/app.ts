import { FacturaService } from './FacturaService.js';
import type {
    AfipEstadoDTO,
    ArticuloItem,
    CatalogoDTO,
    ClienteItem,
    FacturaDetalleDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO,
    OrdenFacturas,
    PaginaDTO,
    ProductoCatalogoDTO,
    ListaPrecioArticuloItem,
    ListaPrecioItem,
    MonedaItem,
    ResumenFacturacionDTO
} from './models/factura.dto.js';

const api = new FacturaService();

type Vista = 'dashboard' | 'facturas' | 'nueva' | 'afip';
type TipoToast = 'info' | 'success' | 'warning' | 'error';

/** Renglón de la factura que se está armando en el formulario (todavía no enviado). */
interface ItemFactura {
    listaPrecioArticuloId: number;
    listaNombre: string;
    precio: number;
    cantidad: number;
    bonificacion: number;
    articulo: { codigo: string; denominacion: string };
}

interface Estado {
    facturas: FacturaReporteDTO[];
    resumen: ResumenFacturacionDTO | null;
    catalogos: CatalogoDTO;
    afip: AfipEstadoDTO | null;
    detalles: ItemFactura[];
    /** Id de la factura que se está editando (null = alta nueva). */
    editandoId: number | null;
    editandoNumero: string | null;
    detalleActual: FacturaDetalleDTO | null;
    /** Id de ListaPrecioArticulo elegido en el explorador (todavía no agregado como renglón). */
    productoElegido: number | null;
    filtros: FacturaFiltrosDTO;
    /** Orden elegido en "Ordenar por"; se mantiene al filtrar, limpiar filtros o cambiar de página. */
    orden: OrdenFacturas;
    paginacion: { pagina: number; tamanio: number; totalPaginas: number; totalElementos: number };
    vista: Vista;
}

const state: Estado = {
    facturas: [],
    resumen: null,
    catalogos: {
        puntosVenta: [],
        clientes: [],
        condicionesIva: [],
        tiposMoneda: [],
        articulos: [],
        listasPrecios: [],
        listaPrecioArticulos: []
    },
    afip: null,
    detalles: [],
    editandoId: null,
    editandoNumero: null,
    detalleActual: null,
    productoElegido: null,
    filtros: {},
    orden: 'fecha_desc',
    paginacion: {
        pagina: 0,
        tamanio: 10,
        totalPaginas: 0,
        totalElementos: 0
    },
    vista: 'dashboard'
};

const VISTAS: Record<Vista, [string, string]> = {
    dashboard: ['Panel de control', 'Resumen de la facturación y estado de la integración.'],
    facturas: ['Comprobantes', 'Consultá, filtrá y gestioná las facturas del sistema.'],
    nueva: ['Nueva factura', 'Cargá los datos y emití el comprobante con CAE.'],
    afip: ['Estado AFIP', 'Estado de la conexión con ARCA / AFIP.']
};

const TIPOS_COMPROBANTE: Record<number, string> = {
    1: 'Factura A',
    3: 'Nota de Crédito A',
    6: 'Factura B',
    8: 'Nota de Crédito B',
    11: 'Factura C',
    13: 'Nota de Crédito C'
};

/** Atajo de querySelector: asume que el elemento existe en index.html (los `?.` siguientes cubren el caso opcional). */
const $ = <T extends HTMLElement = HTMLElement>(selector: string, root: ParentNode = document): T =>
    root.querySelector(selector) as T;
const $$ = <T extends HTMLElement = HTMLElement>(selector: string, root: ParentNode = document): T[] =>
    Array.from(root.querySelectorAll<T>(selector));

document.addEventListener('DOMContentLoaded', init);

async function init() {
    bindNavigation();
    bindFiltros();
    bindPaginacion();
    bindFormulario();
    bindAccionesGlobales();
    bindAfip();
    bindModales();
    bindExplorerProductos();
    bindBuscadorClientes();

    setFechaHoy();

    await Promise.all([cargarCatalogos(), cargarAfipEstado()]);
    poblarSelects();
    resetFormulario();

    await cargarFacturas();
    switchView('dashboard');
}

function bindNavigation() {
    const sidebar = $('#sidebar');
    const toggle = $('#nav-toggle');

    const menuAbierto = () => Boolean(sidebar?.classList.contains('is-open'));

    const cerrarMenu = () => {
        if (!menuAbierto()) {
            return;
        }
        sidebar.classList.remove('is-open');
        toggle?.setAttribute('aria-expanded', 'false');
        toggle?.setAttribute('aria-label', 'Abrir menú de navegación');
    };

    const abrirMenu = () => {
        sidebar?.classList.add('is-open');
        toggle?.setAttribute('aria-expanded', 'true');
        toggle?.setAttribute('aria-label', 'Cerrar menú de navegación');
    };

    toggle?.addEventListener('click', () => {
        if (menuAbierto()) {
            cerrarMenu();
        } else {
            abrirMenu();
        }
    });

    $$('.nav-item[data-view]').forEach((boton) => {
        boton.addEventListener('click', () => {
            if (boton.dataset.view === 'nueva' && state.editandoId) resetFormulario();
            switchView(boton.dataset.view);
            cerrarMenu();
        });
    });

    document.addEventListener('click', (evento) => {
        if (menuAbierto() && !sidebar.contains(evento.target as Node)) {
            cerrarMenu();
        }
    });

    document.addEventListener('keydown', (evento) => {
        if (evento.key === 'Escape') {
            cerrarMenu();
        }
    });

    document.addEventListener('click', (evento) => {
        const destino = (evento.target as HTMLElement).closest<HTMLElement>('[data-go]');
        if (destino) {
            switchView(destino.dataset.go);
            cerrarMenu();
        }
    });

    $('#btn-refrescar')?.addEventListener('click', async (evento) => {
        const boton = evento.currentTarget as HTMLButtonElement;
        setBotonCargando(boton, true, 'Actualizando…');
        try {
            await Promise.all([cargarAfipEstado(), cargarFacturas(state.filtros)]);
            toast('Datos actualizados', 'Se refrescó la información del sistema.', 'success');
        } finally {
            setBotonCargando(boton, false);
        }
    });
}

function switchView(solicitada: string | undefined): void {
    if (!solicitada || !(solicitada in VISTAS)) {
        return;
    }
    const vista = solicitada as Vista;
    state.vista = vista;

    $$('.view').forEach((seccion) => {
        seccion.hidden = seccion.id !== `view-${vista}`;
    });

    $$('.nav-item[data-view]').forEach((boton) => {
        boton.classList.toggle('is-active', boton.dataset.view === vista);
    });

    const [titulo, subtitulo] = vista === 'nueva' && state.editandoId
        ? [`Editar factura ${state.editandoNumero || ''}`.trim(), 'Modificá los datos o los ítems. Solo se editan comprobantes sin CAE.']
        : VISTAS[vista];
    $('#page-title').textContent = titulo;
    $('#page-subtitle').textContent = subtitulo;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function cargarCatalogos() {
    try {
        const datos = await api.obtenerCatalogos();
        state.catalogos = {
            puntosVenta: datos?.puntosVenta || [],
            clientes: datos?.clientes || [],
            condicionesIva: datos?.condicionesIva || [],
            tiposMoneda: datos?.tiposMoneda || [],
            articulos: datos?.articulos || [],
            listasPrecios: datos?.listasPrecios || [],
            listaPrecioArticulos: datos?.listaPrecioArticulos || []
        };
    } catch (error) {
        toast('No se pudieron cargar los catálogos', mensajeDe(error), 'error');
    }
}

async function cargarAfipEstado() {
    try {
        state.afip = await api.obtenerEstadoAfip();
    } catch (error) {
        state.afip = null;
        toast('No se pudo consultar el estado de AFIP', mensajeDe(error), 'warning');
    }
    renderAfipUI();
}

async function cargarFacturas(filtros = state.filtros, pagina = state.paginacion.pagina) {
    setCargando(true);
    try {
        const [paginaDatos, resumen] = await Promise.all([
            api.obtenerFacturasPaginadas(filtros, pagina, state.paginacion.tamanio, state.orden),
            api.obtenerResumen(5)
        ]);
        state.facturas = paginaDatos?.contenido || [];
        state.paginacion = {
            pagina: paginaDatos?.pagina ?? 0,
            tamanio: paginaDatos?.tamanio ?? state.paginacion.tamanio,
            totalPaginas: paginaDatos?.totalPaginas ?? 0,
            totalElementos: paginaDatos?.totalElementos ?? 0
        };
        state.resumen = resumen || null;
        renderDashboard();
        renderFacturas();
    } catch (error) {
        state.facturas = [];
        state.resumen = null;
        renderDashboard();
        renderFacturas(mensajeDe(error));
        toast('Error al cargar los comprobantes', mensajeDe(error), 'error');
    } finally {
        setCargando(false);
    }
}

function renderDashboard() {
    const r = state.resumen || { totalFacturado: 0, vigentes: 0, conCae: 0, pendientes: 0, anuladas: 0, ultimasFacturas: [] };
    const vigentes = Number(r.vigentes || 0);

    $('#stat-total').textContent = formatearMoneda(r.totalFacturado);
    $('#stat-total-foot').textContent = `${vigentes} comprobante${vigentes === 1 ? '' : 's'} vigente${vigentes === 1 ? '' : 's'}`;
    $('#stat-cae').textContent = String(r.conCae);
    $('#stat-pendientes').textContent = String(r.pendientes);
    $('#stat-anuladas').textContent = String(r.anuladas);

    const cuerpo = $('#dashboard-body');
    if (!cuerpo) return;

    const ultimas = r.ultimasFacturas || [];
    if (ultimas.length === 0) {
        cuerpo.innerHTML = filaVacia(6, 'Todavía no hay comprobantes', 'Creá la primera factura para empezar.');
        return;
    }

    cuerpo.innerHTML = ultimas.map((f) => `
        <tr data-id="${f.id}">
            <td>
                <span class="cell-strong">${escaparHtml(numeroComprobante(f))}</span>
                <div class="hint">${escaparHtml(etiquetaTipo(f.tipoComprobante))}</div>
            </td>
            <td class="cell-nowrap">${formatearFecha(f.fechaEmision)}</td>
            <td>${escaparHtml(f.clienteDenominacion || 'Consumidor Final')}</td>
            <td class="cell-money">${formatearMoneda(f.importeTotal)}</td>
            <td>${badgeEstado(f.estado)}</td>
            <td style="text-align:right">
                <button type="button" class="btn btn-ghost btn-sm" data-action="ver" data-id="${f.id}">Ver</button>
            </td>
        </tr>
    `).join('');
}

function renderFacturas(mensajeError?: string) {
    const cuerpo = $('#facturas-body');
    if (!cuerpo) return;

    const total = state.paginacion.totalElementos;
    const contador = $('#facturas-count');
    if (contador) {
        contador.textContent = mensajeError
            ? mensajeError
            : `${total} comprobante${total === 1 ? '' : 's'} encontrado${total === 1 ? '' : 's'}`;
    }

    if (state.facturas.length === 0) {
        cuerpo.innerHTML = filaVacia(9,
            mensajeError ? 'No se pudieron cargar los comprobantes' : 'No hay comprobantes para mostrar',
            mensajeError || 'Probá cambiando los filtros o creá una nueva factura.');
        renderPaginacion();
        return;
    }

    cuerpo.innerHTML = state.facturas.map((f) => {
        const puedeEmitir = !f.cae && f.estado !== 'ANULADA';
        const puedeAnular = f.estado !== 'ANULADA';
        const puedeEditar = !f.cae && f.estado !== 'ANULADA';
        const puedeEliminar = !f.cae;
        return `
            <tr data-id="${f.id}">
                <td>
                    <span class="cell-strong">${escaparHtml(numeroComprobante(f))}</span>
                    <div class="hint">${escaparHtml(etiquetaTipo(f.tipoComprobante))}</div>
                </td>
                <td class="cell-nowrap">${formatearFecha(f.fechaEmision)}</td>
                <td>${escaparHtml(f.clienteDenominacion || 'Consumidor Final')}</td>
                <td>${escaparHtml(f.condicionIva || '—')}</td>
                <td>${escaparHtml(f.puntoVentaDescripcion || '—')}</td>
                <td class="cell-money">${formatearMoneda(f.importeTotal)}</td>
                <td>${badgeEstado(f.estado)}</td>
                <td>${chipCae(f)}</td>
                <td>
                    <div class="row-actions">
                        <button type="button" class="icon-btn" data-action="ver" data-id="${f.id}" title="Ver detalle" aria-label="Ver detalle">
                            ${icono('ojo')}
                        </button>
                        <button type="button" class="icon-btn" data-action="imprimir" data-id="${f.id}" title="Imprimir factura (PDF)" aria-label="Imprimir factura">
                            ${icono('impresora')}
                        </button>
                        ${puedeEditar ? `
                            <button type="button" class="icon-btn" data-action="editar" data-id="${f.id}" title="Editar factura" aria-label="Editar factura">
                                ${icono('lapiz')}
                            </button>
                        ` : ''}
                        ${puedeEmitir ? `
                            <button type="button" class="icon-btn" data-action="emitir" data-id="${f.id}" title="Emitir CAE" aria-label="Emitir CAE">
                                ${icono('rayo')}
                            </button>
                        ` : ''}
                        ${puedeAnular ? `
                            <button type="button" class="icon-btn" data-action="anular" data-id="${f.id}" title="Anular factura" aria-label="Anular factura">
                                ${icono('anular')}
                            </button>
                        ` : ''}
                        ${puedeEliminar ? `
                            <button type="button" class="icon-btn" data-action="eliminar" data-id="${f.id}" title="Eliminar factura" aria-label="Eliminar factura">
                                ${icono('papelera')}
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    renderPaginacion();
}

function renderPaginacion() {
    const { pagina, tamanio, totalPaginas, totalElementos } = state.paginacion;

    const info = $('#facturas-rango');
    if (info) {
        const desde = totalElementos === 0 ? 0 : pagina * tamanio + 1;
        const hasta = Math.min((pagina + 1) * tamanio, totalElementos);
        info.textContent = totalElementos === 0
            ? 'Sin comprobantes'
            : `Mostrando ${desde}–${hasta} de ${totalElementos}`;
    }

    const etiqueta = $('#facturas-pagina');
    if (etiqueta) {
        etiqueta.textContent = totalPaginas === 0
            ? 'Página 0 de 0'
            : `Página ${pagina + 1} de ${totalPaginas}`;
    }

    const enPrimera = pagina <= 0;
    const enUltima = totalPaginas === 0 || pagina >= totalPaginas - 1;
    fijarDeshabilitado('#btn-pagina-primera', enPrimera);
    fijarDeshabilitado('#btn-pagina-anterior', enPrimera);
    fijarDeshabilitado('#btn-pagina-siguiente', enUltima);
    fijarDeshabilitado('#btn-pagina-ultima', enUltima);
}

function fijarDeshabilitado(selector: string, deshabilitado: boolean) {
    const boton = $<HTMLButtonElement>(selector);
    if (boton) boton.disabled = deshabilitado;
}

function bindPaginacion() {
    $('#btn-pagina-primera')?.addEventListener('click', () => irAPagina(0));
    $('#btn-pagina-anterior')?.addEventListener('click', () => irAPagina(state.paginacion.pagina - 1));
    $('#btn-pagina-siguiente')?.addEventListener('click', () => irAPagina(state.paginacion.pagina + 1));
    $('#btn-pagina-ultima')?.addEventListener('click', () => irAPagina(state.paginacion.totalPaginas - 1));

    $('#facturas-orden')?.addEventListener('change', (evento) => {
        state.orden = (evento.target as HTMLSelectElement).value as OrdenFacturas;
        cargarFacturas(state.filtros, 0);
    });

    $('#facturas-tamanio')?.addEventListener('change', (evento) => {
        const tamanio = Number((evento.target as HTMLSelectElement).value);
        state.paginacion.tamanio = Number.isFinite(tamanio) && tamanio > 0 ? tamanio : 10;
        cargarFacturas(state.filtros, 0);
    });
}

function irAPagina(pagina: number) {
    if (pagina < 0) return;
    if (state.paginacion.totalPaginas > 0 && pagina > state.paginacion.totalPaginas - 1) return;
    if (pagina === state.paginacion.pagina) return;
    cargarFacturas(state.filtros, pagina);
}

function bindFiltros() {
    $('#form-filtros')?.addEventListener('submit', async (evento) => {
        evento.preventDefault();
        const monto = $<HTMLInputElement>('#filtro-monto').value;
        const numero = $<HTMLInputElement>('#filtro-numero').value.replace(/\D/g, '');
        state.filtros = {
            clienteId: clienteFiltro?.id ?? undefined,
            cliente: clienteFiltro && clienteFiltro.id === null ? 'Consumidor Final' : undefined,
            numero: numero !== '' ? Number(numero) : undefined,
            fechaDesde: $<HTMLInputElement>('#filtro-fecha-desde').value || undefined,
            fechaHasta: $<HTMLInputElement>('#filtro-fecha-hasta').value || undefined,
            estado: $<HTMLInputElement>('#filtro-estado').value || undefined,
            montoMinimo: monto !== '' ? Number(monto) : undefined
        };
        await cargarFacturas(state.filtros, 0);
    });

    $('#btn-limpiar-filtros')?.addEventListener('click', async () => {
        $<HTMLFormElement>('#form-filtros').reset();
        clienteFiltro = null;
        mostrarClienteFiltro();
        state.filtros = {};
        await cargarFacturas(state.filtros, 0);
    });
}

function bindFormulario() {
    $('#form-nueva')?.addEventListener('submit', (evento) => {
        evento.preventDefault();
        guardarFactura(false);
    });

    $('#btn-guardar-emitir')?.addEventListener('click', () => guardarFactura(true));
    $('#btn-agregar-item')?.addEventListener('click', agregarItem);
    $('#nueva-cliente')?.addEventListener('change', alCambiarCliente);
    $('#btn-buscar-cliente-nueva')?.addEventListener('click', () => abrirBuscadorClientes('factura'));
    $('#nueva-cliente-texto')?.addEventListener('click', () => abrirBuscadorClientes('factura'));
    $('#btn-quitar-cliente-nueva')?.addEventListener('click', () => elegirClienteFactura(null));
    $('#nueva-tipo-comprobante')?.addEventListener('change', () => renderItems());
    $('#nueva-moneda')?.addEventListener('change', () => renderItems());
    $('#btn-explorar-productos')?.addEventListener('click', abrirExplorerProductos);
    $('#nueva-producto')?.addEventListener('click', abrirExplorerProductos);
    $('#btn-cancelar-edicion')?.addEventListener('click', () => {
        resetFormulario();
        switchView('facturas');
    });

    $('#nueva-cantidad')?.addEventListener('keydown', (evento) => {
        if (evento.key === 'Enter') {
            evento.preventDefault();
            agregarItem();
        }
    });
}

function poblarSelects() {
    const { puntosVenta, clientes, condicionesIva, tiposMoneda, articulos } = state.catalogos;

    $('#nueva-punto-venta').innerHTML = puntosVenta.length
        ? puntosVenta.map((pv) => `<option value="${pv.id}">${escaparHtml(`${pv.numero} · ${pv.descripcion}`)}</option>`).join('')
        : '<option value="">Sin puntos de venta</option>';

    $('#nueva-cliente').innerHTML = [
        '<option value="">Consumidor Final</option>',
        ...clientes.map((c) => `<option value="${c.id}">${escaparHtml(c.denominacion + (c.cuitCuil ? ` · ${c.cuitCuil}` : ''))}</option>`)
    ].join('');

    $('#nueva-condicion-iva').innerHTML = condicionesIva.length
        ? condicionesIva.map((ci) => `<option value="${ci.id}">${escaparHtml(ci.denominacion)}</option>`).join('')
        : '<option value="">Sin condiciones</option>';

    $('#nueva-moneda').innerHTML = tiposMoneda.length
        ? tiposMoneda.map((tm) => `<option value="${tm.id}">${escaparHtml(etiquetaMoneda(tm))}</option>`).join('')
        : '<option value="">Sin monedas</option>';

    const listas = state.catalogos.listasPrecios;
    $('#productos-lista').innerHTML = [
        `<option value="${TODAS_LAS_LISTAS}">Todas las listas</option>`,
        ...listas.map((l) => `<option value="${l.id}">${escaparHtml(l.denominacion)}</option>`)
    ].join('');
    if (listas[0]) $<HTMLSelectElement>('#productos-lista').value = String(listas[0].id);
    mostrarProductoElegido();
}

// ---------------------------------------------------------------------------
// Explorador de productos: modal con búsqueda por código, denominación, rubro y marca
// ---------------------------------------------------------------------------

/** Valor del filtro "Todas las listas" en el explorador (los ids reales son positivos). */
const TODAS_LAS_LISTAS = 0;

interface ProductoExplorable {
    lpa: ListaPrecioArticuloItem;
    articulo: ArticuloItem;
    lista: ListaPrecioItem | undefined;
}

/** Minúsculas y sin tildes, para que "periféricos" y "perifericos" se encuentren igual. */
function normalizarTexto(valor: unknown): string {
    return String(valor ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
}

function listaPorId(id: number): ListaPrecioItem | undefined {
    return state.catalogos.listasPrecios.find((l) => Number(l.id) === Number(id));
}

function productoPorLpaId(lpaId: number): ProductoExplorable | null {
    const lpa = state.catalogos.listaPrecioArticulos.find((p) => Number(p.id) === Number(lpaId));
    const articulo = lpa ? articuloPorId(lpa.articuloId) : null;
    return lpa && articulo ? { lpa, articulo, lista: listaPorId(lpa.listaPrecioId) } : null;
}

const TAMANIO_PAGINA_EXPLORADOR = 8;
let paginaProductos: PaginaDTO<ProductoCatalogoDTO> | null = null;
let consultaProductos = 0;
let temporizadorProductos: number | undefined;

/** Pide al backend la página de productos (COUNT + página) según el texto buscado y la lista elegida. */
async function cargarProductos(pagina = 0) {
    const listaId = Number($<HTMLSelectElement>('#productos-lista').value);
    const buscar = $<HTMLInputElement>('#productos-buscar').value;
    const esta = ++consultaProductos;
    try {
        const resultado = await api.buscarProductos(buscar, listaId === TODAS_LAS_LISTAS ? null : listaId,
            pagina, TAMANIO_PAGINA_EXPLORADOR);
        if (esta !== consultaProductos) return; // llegó tarde: ya hay una búsqueda más nueva
        paginaProductos = resultado;
        renderProductos();
    } catch (error) {
        if (esta !== consultaProductos) return;
        paginaProductos = null;
        $('#productos-body').innerHTML = filaVacia(7, 'No se pudieron buscar los productos', mensajeDe(error));
    }
}

function buscarProductosConDemora() {
    window.clearTimeout(temporizadorProductos);
    temporizadorProductos = window.setTimeout(() => cargarProductos(0), 250);
}

function renderPaginador(prefijo: string, pagina: PaginaDTO<unknown> | null, nombre: [string, string]) {
    const total = pagina?.totalElementos ?? 0;
    const desde = total === 0 ? 0 : pagina!.pagina * pagina!.tamanio + 1;
    const hasta = total === 0 ? 0 : desde + pagina!.contenido.length - 1;
    $(`#${prefijo}-rango`).textContent = total === 0 ? '' : `Mostrando ${desde}–${hasta} de ${total} ${total === 1 ? nombre[0] : nombre[1]}`;
    $(`#${prefijo}-pagina`).textContent = total === 0 ? '' : `Página ${pagina!.pagina + 1} de ${pagina!.totalPaginas}`;
    $<HTMLButtonElement>(`#${prefijo}-anterior`).disabled = !pagina || pagina.primera;
    $<HTMLButtonElement>(`#${prefijo}-siguiente`).disabled = !pagina || pagina.ultima;
}

function renderProductos() {
    const cuerpo = $('#productos-body');
    const todasLasListas = Number($<HTMLSelectElement>('#productos-lista').value) === TODAS_LAS_LISTAS;
    const encontrados = paginaProductos?.contenido ?? [];

    $('#productos-th-lista').hidden = !todasLasListas;
    $('#productos-contador').textContent = encontrados.length === 0 ? 'No hay productos que coincidan con la búsqueda.' : '';
    renderPaginador('productos', paginaProductos, ['producto', 'productos']);

    cuerpo.innerHTML = encontrados.length === 0
        ? filaVacia(7, 'Sin resultados', 'Probá con otra palabra, o cambiá la lista de precios.')
        : encontrados.map((p, indice) => `
            <tr class="pick-row${indice === 0 ? ' is-first' : ''}" data-lpa="${p.listaPrecioArticuloId}">
                <td class="code">${escaparHtml(p.codigo)}</td>
                <td><span class="cell-strong">${escaparHtml(p.denominacion)}</span></td>
                <td>${escaparHtml(p.rubro || '—')}</td>
                <td>${escaparHtml(p.marca || '—')}</td>
                <td${todasLasListas ? '' : ' hidden'}>${escaparHtml(p.listaPrecio || '—')}</td>
                <td class="num cell-money">${formatearMoneda(p.precioVenta)}</td>
                <td style="text-align:right">
                    <button type="button" class="btn btn-ghost btn-sm" data-action="elegir-producto" data-lpa="${p.listaPrecioArticuloId}">Elegir</button>
                </td>
            </tr>`).join('');
}

function abrirExplorerProductos() {
    const modal = $('#modal-productos');
    $<HTMLInputElement>('#productos-buscar').value = '';
    paginaProductos = null;
    $('#productos-body').innerHTML = filaVacia(7, 'Buscando…');
    cargarProductos(0);
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    $<HTMLInputElement>('#productos-buscar').focus();
}

function cerrarExplorerProductos() {
    const modal = $('#modal-productos');
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    document.body.style.overflow = '';
}

function elegirProducto(lpaId: number) {
    if (!productoPorLpaId(lpaId)) return;
    state.productoElegido = lpaId;
    mostrarProductoElegido();
    cerrarExplorerProductos();
    const cantidad = $<HTMLInputElement>('#nueva-cantidad');
    cantidad.focus();
    cantidad.select();
}

/** Texto del campo "Producto" del formulario según el producto elegido (vacío si no hay). */
function mostrarProductoElegido() {
    const campo = $<HTMLInputElement>('#nueva-producto');
    if (!campo) return;
    const producto = state.productoElegido !== null ? productoPorLpaId(state.productoElegido) : null;
    campo.value = producto
        ? `${producto.articulo.codigo} · ${producto.articulo.denominacion} — ${formatearMoneda(producto.lpa.precioVenta)} (${producto.lista?.denominacion ?? 'sin lista'})`
        : '';
}

function bindExplorerProductos() {
    const modal = $('#modal-productos');
    const buscador = $<HTMLInputElement>('#productos-buscar');

    modal?.addEventListener('click', (evento) => {
        const objetivo = evento.target as HTMLElement;
        if (objetivo.closest('[data-productos-close]')) {
            cerrarExplorerProductos();
            return;
        }
        const fila = objetivo.closest<HTMLElement>('tr[data-lpa]');
        if (fila) elegirProducto(Number(fila.dataset.lpa));
    });

    buscador?.addEventListener('input', buscarProductosConDemora);
    $('#productos-lista')?.addEventListener('change', () => cargarProductos(0));
    $('#productos-anterior')?.addEventListener('click', () => paginaProductos && cargarProductos(paginaProductos.pagina - 1));
    $('#productos-siguiente')?.addEventListener('click', () => paginaProductos && cargarProductos(paginaProductos.pagina + 1));

    // Enter elige el primer resultado: se puede buscar, apretar Enter y seguir con la cantidad.
    buscador?.addEventListener('keydown', async (evento) => {
        if (evento.key !== 'Enter') return;
        evento.preventDefault();
        window.clearTimeout(temporizadorProductos);
        await cargarProductos(0);
        const primero = paginaProductos?.contenido[0];
        if (primero) elegirProducto(Number(primero.listaPrecioArticuloId));
    });
}

function articuloPorId(id: number): ArticuloItem | null {
    return state.catalogos.articulos.find((a) => Number(a.id) === Number(id)) || null;
}

function resetFormulario() {
    const formulario = $<HTMLFormElement>('#form-nueva');
    formulario?.reset();
    setFechaHoy();

    const tipoDefault = state.afip?.tipoComprobanteDefault || 11;
    if ($('#nueva-tipo-comprobante')) {
        $<HTMLInputElement>('#nueva-tipo-comprobante').value = String(tipoDefault);
    }
    if (state.catalogos.puntosVenta[0]) {
        $<HTMLInputElement>('#nueva-punto-venta').value = String(state.catalogos.puntosVenta[0].id);
    }
    const condicionDefault = state.catalogos.condicionesIva.find((ci) => /consumidor final/i.test(ci.denominacion))
        || state.catalogos.condicionesIva[0];
    if (condicionDefault) {
        $<HTMLInputElement>('#nueva-condicion-iva').value = String(condicionDefault.id);
    }
    const monedaDefault = state.catalogos.tiposMoneda.find((tm) => tm.codigoAfip === 'PES')
        || state.catalogos.tiposMoneda[0];
    if (monedaDefault) {
        $<HTMLInputElement>('#nueva-moneda').value = String(monedaDefault.id);
    }
    state.productoElegido = null;
    mostrarProductoElegido();

    actualizarHintCliente();
    state.detalles = [];
    setModoEdicion(null);
    renderItems();
}

function setModoEdicion(factura: FacturaDetalleDTO | null) {
    state.editandoId = factura ? factura.id : null;
    state.editandoNumero = factura ? numeroComprobante(factura) : null;
    $('#btn-guardar').textContent = factura ? 'Guardar cambios' : 'Guardar factura';
    $('#btn-cancelar-edicion').hidden = !factura;
}

async function editarFactura(id: number) {
    try {
        const detalle = await api.obtenerFactura(id);
        if (detalle.cae || detalle.estado === 'ANULADA') {
            toast('No se puede editar', 'Solo se editan facturas sin CAE. Una factura con CAE se anula.', 'warning');
            return;
        }
        resetFormulario();
        $<HTMLInputElement>('#nueva-punto-venta').value = String(detalle.puntoVentaId);
        $<HTMLInputElement>('#nueva-tipo-comprobante').value = String(detalle.tipoComprobante || 11);
        $<HTMLInputElement>('#nueva-fecha').value = String(detalle.fechaEmision || '').substring(0, 10);
        $<HTMLInputElement>('#nueva-moneda').value = String(detalle.tipoMonedaId);
        $<HTMLInputElement>('#nueva-cliente').value = detalle.clienteId ? String(detalle.clienteId) : '';
        $<HTMLInputElement>('#nueva-condicion-iva').value = String(detalle.condicionIvaId);
        $<HTMLInputElement>('#nueva-observaciones').value = detalle.observaciones || '';
        actualizarHintCliente();

        state.detalles = detalle.items.map((item) => ({
            listaPrecioArticuloId: Number(item.listaPrecioArticuloId),
            listaNombre: item.listaPrecio,
            precio: item.precioUnitario,
            cantidad: item.cantidad,
            bonificacion: item.porcentajeBonificacion || 0,
            articulo: { codigo: item.codigo, denominacion: item.denominacion }
        }));

        cerrarDetalle();
        setModoEdicion(detalle);
        renderItems();
        switchView('nueva');
    } catch (error) {
        toast('No se pudo abrir la factura', mensajeDe(error), 'error');
    }
}

function alCambiarCliente() {
    const cliente = clienteSeleccionado();
    if (cliente && cliente.condicionIvaId) {
        $<HTMLInputElement>('#nueva-condicion-iva').value = String(cliente.condicionIvaId);
    }
    actualizarHintCliente();
    renderItems();
}

// ---------------------------------------------------------------------------
// Pop-up "Buscar cliente": por CUIT/CUIL o razón social, desde 3 caracteres
// ---------------------------------------------------------------------------

type DestinoCliente = 'filtro' | 'factura';
let destinoBuscadorClientes: DestinoCliente = 'filtro';
/** Cliente elegido para filtrar el listado: un cliente, "Consumidor Final" o ninguno (todos). */
let clienteFiltro: { id: number | null; etiqueta: string } | null = null;

const MIN_CARACTERES_CLIENTE = 3;

function etiquetaCliente(c: ClienteItem): string {
    return c.cuitCuil ? `${c.denominacion} · ${c.cuitCuil}` : c.denominacion;
}

let paginaClientes: PaginaDTO<ClienteItem> | null = null;
let consultaClientes = 0;
let temporizadorClientes: number | undefined;

/** Hay búsqueda si CUIT/CUIL o razón social tienen al menos 3 caracteres. */
function criteriosClientes(): { cuit: string; razon: string } | null {
    const cuit = $<HTMLInputElement>('#clientes-cuit').value.replace(/\D/g, '');
    const razon = $<HTMLInputElement>('#clientes-razon').value.trim();
    if (cuit.length < MIN_CARACTERES_CLIENTE && razon.length < MIN_CARACTERES_CLIENTE) return null;
    return {
        cuit: cuit.length >= MIN_CARACTERES_CLIENTE ? cuit : '',
        razon: razon.length >= MIN_CARACTERES_CLIENTE ? razon : ''
    };
}

async function cargarClientes(pagina = 0) {
    const criterios = criteriosClientes();
    const esta = ++consultaClientes;
    if (!criterios) {
        paginaClientes = null;
        renderClientes();
        return;
    }
    try {
        const resultado = await api.buscarClientes(criterios.cuit, criterios.razon, pagina, TAMANIO_PAGINA_EXPLORADOR);
        if (esta !== consultaClientes) return;
        paginaClientes = resultado;
        renderClientes();
    } catch (error) {
        if (esta !== consultaClientes) return;
        $('#clientes-body').innerHTML = filaVacia(5, 'No se pudieron buscar los clientes', mensajeDe(error));
    }
}

function buscarClientesConDemora() {
    window.clearTimeout(temporizadorClientes);
    temporizadorClientes = window.setTimeout(() => cargarClientes(0), 250);
}

function renderClientes() {
    const contador = $('#clientes-contador');
    const cuerpo = $('#clientes-body');
    if (!criteriosClientes()) {
        contador.textContent = '';
        renderPaginador('clientes', null, ['cliente', 'clientes']);
        cuerpo.innerHTML = filaVacia(5, 'Ingresá al menos 3 caracteres en CUIT/CUIL o Razón social para buscar clientes.');
        return;
    }
    const encontrados = paginaClientes?.contenido ?? [];
    contador.textContent = '';
    renderPaginador('clientes', paginaClientes, ['cliente', 'clientes']);
    cuerpo.innerHTML = encontrados.length === 0
        ? filaVacia(5, 'Sin resultados', 'No hay clientes con ese CUIT/CUIL o razón social.')
        : encontrados.map((c, indice) => `
            <tr class="pick-row${indice === 0 ? ' is-first' : ''}" data-cliente="${c.id}">
                <td class="code">${escaparHtml(c.cuitCuil || '—')}</td>
                <td><span class="cell-strong">${escaparHtml(c.denominacion)}</span></td>
                <td>${escaparHtml(c.condicionIva || '—')}</td>
                <td>${escaparHtml(c.email || '—')}</td>
                <td style="text-align:right">
                    <button type="button" class="btn btn-ghost btn-sm" data-cliente="${c.id}">Elegir</button>
                </td>
            </tr>`).join('');
}

function abrirBuscadorClientes(destino: DestinoCliente) {
    destinoBuscadorClientes = destino;
    $<HTMLInputElement>('#clientes-cuit').value = '';
    $<HTMLInputElement>('#clientes-razon').value = '';
    paginaClientes = null;
    renderClientes();
    $('#modal-clientes').hidden = false;
    document.body.style.overflow = 'hidden';
    $<HTMLInputElement>('#clientes-cuit').focus();
}

function cerrarBuscadorClientes() {
    const modal = $('#modal-clientes');
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    document.body.style.overflow = '';
}

/** null = Consumidor Final (factura sin cliente). */
function elegirClienteFactura(cliente: ClienteItem | null) {
    $<HTMLSelectElement>('#nueva-cliente').value = cliente ? String(cliente.id) : '';
    alCambiarCliente();
}

function mostrarClienteFactura() {
    const cliente = clienteSeleccionado();
    const campo = $<HTMLInputElement>('#nueva-cliente-texto');
    if (campo) campo.value = cliente ? etiquetaCliente(cliente) : 'Consumidor Final';
    const quitar = $('#btn-quitar-cliente-nueva');
    if (quitar) quitar.hidden = !cliente;
}

function mostrarClienteFiltro() {
    $<HTMLInputElement>('#filtro-cliente').value = clienteFiltro ? clienteFiltro.etiqueta : '';
    $('#btn-quitar-cliente-filtro').hidden = !clienteFiltro;
}

function elegirCliente(cliente: ClienteItem | null) {
    if (destinoBuscadorClientes === 'factura') {
        elegirClienteFactura(cliente);
    } else {
        clienteFiltro = cliente
            ? { id: Number(cliente.id), etiqueta: etiquetaCliente(cliente) }
            : { id: null, etiqueta: 'Consumidor Final' };
        mostrarClienteFiltro();
    }
    cerrarBuscadorClientes();
}

function bindBuscadorClientes() {
    $('#modal-clientes')?.addEventListener('click', (evento) => {
        const objetivo = evento.target as HTMLElement;
        if (objetivo.closest('[data-clientes-close]')) {
            cerrarBuscadorClientes();
            return;
        }
        const fila = objetivo.closest<HTMLElement>('[data-cliente]');
        if (fila) {
            const id = Number(fila.dataset.cliente);
            const cliente = paginaClientes?.contenido.find((c) => Number(c.id) === id)
                || state.catalogos.clientes.find((c) => Number(c.id) === id);
            if (cliente) elegirCliente(cliente);
        }
    });
    $('#clientes-consumidor-final')?.addEventListener('click', () => elegirCliente(null));
    for (const selector of ['#clientes-cuit', '#clientes-razon']) {
        $(selector)?.addEventListener('input', buscarClientesConDemora);
        $(selector)?.addEventListener('keydown', async (evento) => {
            if ((evento as KeyboardEvent).key !== 'Enter') return;
            evento.preventDefault();
            window.clearTimeout(temporizadorClientes);
            await cargarClientes(0);
            const primero = paginaClientes?.contenido[0];
            if (primero) elegirCliente(primero);
        });
    }
    $('#clientes-anterior')?.addEventListener('click', () => paginaClientes && cargarClientes(paginaClientes.pagina - 1));
    $('#clientes-siguiente')?.addEventListener('click', () => paginaClientes && cargarClientes(paginaClientes.pagina + 1));
    $('#btn-buscar-cliente-filtro')?.addEventListener('click', () => abrirBuscadorClientes('filtro'));
    $('#filtro-cliente')?.addEventListener('click', () => abrirBuscadorClientes('filtro'));
    $('#btn-quitar-cliente-filtro')?.addEventListener('click', () => {
        clienteFiltro = null;
        mostrarClienteFiltro();
    });
}

function actualizarHintCliente() {
    mostrarClienteFactura();
    const cliente = clienteSeleccionado();
    const hint = $('#nueva-cliente-hint');
    if (!hint) return;

    if (!cliente) {
        hint.textContent = 'Sin cliente: se emite a Consumidor Final (DocTipo 99).';
    } else if (cliente.cuitCuil) {
        hint.textContent = `CUIT ${cliente.cuitCuil} · DocTipo 80.`;
    } else {
        hint.textContent = 'El cliente no tiene CUIT: se usará DocTipo 99.';
    }
}

function agregarItem() {
    const cantidad = Number($<HTMLInputElement>('#nueva-cantidad').value);
    const bonificacion = Number($<HTMLInputElement>('#nueva-bonificacion').value || 0);
    const producto = state.productoElegido !== null ? productoPorLpaId(state.productoElegido) : null;

    if (!producto) {
        toast('Elegí un producto', 'Usá el botón Explorar para buscarlo por código, nombre, rubro o marca.', 'warning');
        $('#btn-explorar-productos').focus();
        return;
    }
    const { lpa, articulo, lista } = producto;
    const lpaId = Number(lpa.id);
    if (!Number.isInteger(cantidad) || cantidad <= 0) {
        toast('Cantidad inválida', 'Ingresá una cantidad entera mayor a cero (1, 2, 3…).', 'warning');
        $('#nueva-cantidad').focus();
        return;
    }
    if (!Number.isFinite(bonificacion) || bonificacion < 0 || bonificacion > 100) {
        toast('Bonificación inválida', 'La bonificación va de 0 a 100 %.', 'warning');
        $('#nueva-bonificacion').focus();
        return;
    }

    const existente = state.detalles.find((d) =>
        d.listaPrecioArticuloId === lpaId && d.bonificacion === bonificacion);
    if (existente) {
        existente.cantidad += cantidad;
    } else {
        state.detalles.push({
            listaPrecioArticuloId: lpaId,
            listaNombre: lista ? lista.denominacion : '',
            precio: lpa.precioVenta,
            cantidad,
            bonificacion,
            articulo
        });
    }

    $<HTMLInputElement>('#nueva-cantidad').value = '1';
    $<HTMLInputElement>('#nueva-bonificacion').value = '0';
    state.productoElegido = null;
    mostrarProductoElegido();
    renderItems();
}

function subtotalItem(d: ItemFactura) {
    return Math.round(d.cantidad * d.precio * (1 - (d.bonificacion || 0) / 100) * 100) / 100;
}

/** Alícuota de IVA vigente (la informa el backend en /api/afip/estado; por defecto 21 %). */
function alicuotaIva(): number {
    return Number(state.afip?.alicuotaIva ?? 21);
}

/** Factura A (1) y B (6) discriminan el IVA; la C (11) no. */
function discriminaIva(): boolean {
    const tipo = Number($<HTMLInputElement>('#nueva-tipo-comprobante')?.value || 11);
    return tipo === 1 || tipo === 6;
}

/** IVA contenido en el subtotal del renglón, con el mismo cálculo que FacturaVenta.calcularTotal(). */
function ivaItem(d: ItemFactura): number {
    if (!discriminaIva()) return 0;
    const subtotal = subtotalItem(d);
    const neto = Math.round(subtotal / (1 + alicuotaIva() / 100) * 100) / 100;
    return Math.round((subtotal - neto) * 100) / 100;
}

function renderItems() {
    const cuerpo = $('#items-body');
    if (!cuerpo) return;

    const vacio = state.detalles.length === 0;
    const contenedorTabla = cuerpo.closest<HTMLElement>('.table-wrap');
    if (contenedorTabla) contenedorTabla.hidden = vacio;
    $('#items-empty').hidden = !vacio;

    const moneda = monedaSeleccionada();
    const discrimina = discriminaIva();
    $('#items-th-iva').textContent = `IVA ${formatearCantidad(alicuotaIva())}%`;
    cuerpo.innerHTML = state.detalles.map((detalle, indice) => `
        <tr>
            <td>
                <span class="cell-strong">${escaparHtml(detalle.articulo.denominacion)}</span>
                <div class="hint">${escaparHtml(`${detalle.articulo.codigo} · Lista ${detalle.listaNombre}`)}</div>
            </td>
            <td class="num">${formatearMoneda(detalle.precio, moneda)}</td>
            <td class="num">${formatearCantidad(detalle.cantidad)}</td>
            <td class="num">${detalle.bonificacion ? `${formatearCantidad(detalle.bonificacion)} %` : '—'}</td>
            <td class="num">${discrimina
                ? formatearMoneda(ivaItem(detalle), moneda)
                : '<span class="hint" title="La Factura C no discrimina IVA">No discrimina</span>'}</td>
            <td class="cell-money">${formatearMoneda(subtotalItem(detalle), moneda)}</td>
            <td style="text-align:right">
                <button type="button" class="icon-btn" data-action="quitar-item" data-index="${indice}" title="Quitar ítem" aria-label="Quitar ítem">
                    ${icono('papelera')}
                </button>
            </td>
        </tr>
    `).join('');

    actualizarResumen();
}

function actualizarResumen() {
    const tipo = Number($<HTMLInputElement>('#nueva-tipo-comprobante')?.value || 11);
    const moneda = monedaSeleccionada();
    const total = state.detalles.reduce((acumulado, d) => acumulado + subtotalItem(d), 0);
    const discrimina = tipo === 1 || tipo === 6;
    const alicuota = Number(state.afip?.alicuotaIva ?? 21);
    const neto = discrimina ? total / (1 + alicuota / 100) : total;
    const iva = discrimina ? total - neto : 0;

    $('#resumen-subtotal').textContent = formatearMoneda(neto, moneda);
    $('#resumen-iva-label').textContent = discrimina ? `IVA ${alicuota}%` : 'IVA (no discriminado)';
    $('#resumen-iva').textContent = formatearMoneda(iva, moneda);
    $('#resumen-total').textContent = formatearMoneda(total, moneda);

    const nota = $('#resumen-nota');
    if (nota) {
        if (tipo === 11) {
            nota.textContent = 'Factura C: el importe total no discrimina IVA.';
        } else if (tipo === 1) {
            nota.textContent = 'Factura A: requiere CUIT del receptor y discrimina IVA.';
        } else {
            nota.textContent = 'Factura B: IVA incluido en el precio y discriminado en el comprobante.';
        }

        const cliente = clienteSeleccionado();
        if (tipo === 1 && (!cliente || !cliente.cuitCuil)) {
            nota.textContent = 'Atención: una Factura A requiere un cliente con CUIT.';
            nota.style.color = 'var(--warning)';
        } else {
            nota.style.color = '';
        }
    }
}

async function guardarFactura(emitirCae: boolean) {
    const formulario = $<HTMLFormElement>('#form-nueva');
    if (!formulario.reportValidity()) {
        return;
    }
    if (state.detalles.length === 0) {
        toast('Faltan ítems', 'Agregá al menos un artículo antes de guardar la factura.', 'warning');
        $('#btn-explorar-productos')?.focus();
        return;
    }

    const tipo = Number($<HTMLInputElement>('#nueva-tipo-comprobante').value || 11);
    if (tipo === 1) {
        const cliente = clienteSeleccionado();
        if (!cliente || !cliente.cuitCuil) {
            toast('Factura A inválida', 'Para emitir una Factura A el cliente debe tener CUIT.', 'warning');
            return;
        }
    }

    const clienteId = $<HTMLInputElement>('#nueva-cliente').value;
    const dto: FacturaRequestDTO = {
        puntoVentaId: Number($<HTMLInputElement>('#nueva-punto-venta').value),
        clienteId: clienteId ? Number(clienteId) : null,
        condicionIvaId: Number($<HTMLInputElement>('#nueva-condicion-iva').value),
        tipoMonedaId: Number($<HTMLInputElement>('#nueva-moneda').value),
        tipoComprobante: tipo,
        fechaEmision: $<HTMLInputElement>('#nueva-fecha').value,
        importeCobrado: 0,
        estado: 'ACTIVA',
        observaciones: $<HTMLInputElement>('#nueva-observaciones').value || null,
        detalles: state.detalles.map((d) => ({
            listaPrecioArticuloId: d.listaPrecioArticuloId,
            cantidad: d.cantidad,
            porcentajeBonificacion: d.bonificacion
        }))
    };
    const editandoId = state.editandoId;
    if (editandoId) {
        dto.sinCliente = !clienteId;
        delete dto.estado;
        delete dto.importeCobrado;
    }

    const boton = emitirCae ? $<HTMLButtonElement>('#btn-guardar-emitir') : $<HTMLButtonElement>('#btn-guardar');
    setBotonCargando(boton, true, emitirCae ? 'Emitiendo…' : 'Guardando…');

    try {
        const creada = editandoId
            ? await api.actualizarFactura(editandoId, dto)
            : await api.crearFactura(dto);

        if (emitirCae) {
            try {
                const detalle = await api.emitirCae(creada.id, tipo);
                if (detalle.cae) {
                    toast(
                        `Factura ${numeroComprobante(detalle)} emitida con CAE`,
                        `CAE ${detalle.cae} · vence ${formatearFecha(detalle.caeFechaVencimiento)}`,
                        'success'
                    );
                } else {
                    toast(
                        `Factura ${numeroComprobante(detalle)} guardada`,
                        detalle.motivoRechazo || 'AFIP no autorizó el comprobante.',
                        'warning'
                    );
                }
            } catch (error) {
                toast(
                    'Factura guardada, pero no se pudo emitir',
                    `${mensajeDe(error)} Podés reintentar desde el listado.`,
                    'warning'
                );
            }
        } else {
            toast(
                `Factura ${numeroComprobante(creada)} ${editandoId ? 'actualizada' : 'guardada'}`,
                'El comprobante quedó pendiente de CAE.',
                'success'
            );
        }

        resetFormulario();
        await cargarFacturas(state.filtros);
        switchView('facturas');
    } catch (error) {
        toast('No se pudo guardar la factura', mensajeDe(error), 'error');
    } finally {
        setBotonCargando(boton, false);
        $('#btn-guardar').textContent = state.editandoId ? 'Guardar cambios' : 'Guardar factura';
    }
}

function bindAccionesGlobales() {
    document.addEventListener('click', (evento) => {
        const boton = (evento.target as HTMLElement).closest<HTMLButtonElement>('button[data-action]');
        if (boton) {
            const accion = boton.dataset.action;

            if (accion === 'quitar-item') {
                const indice = Number(boton.dataset.index);
                if (Number.isInteger(indice)) {
                    state.detalles.splice(indice, 1);
                    renderItems();
                }
                return;
            }

            const id = Number(boton.dataset.id);
            if (!id) return;

            if (accion === 'ver') openDetalle(id);
            if (accion === 'imprimir') imprimirFactura(id);
            if (accion === 'emitir') emitirFactura(id, boton);
            if (accion === 'anular') anularFactura(id);
            if (accion === 'editar') editarFactura(id);
            if (accion === 'eliminar') eliminarFactura(id);
            return;
        }

        const fila = (evento.target as HTMLElement).closest<HTMLElement>('tr[data-id]');
        if (fila && !(evento.target as HTMLElement).closest('button, a')) {
            openDetalle(Number(fila.dataset.id));
        }
    });
}

async function emitirFactura(id: number, boton: HTMLButtonElement | null) {
    const factura = state.facturas.find((f) => Number(f.id) === id);
    if (factura?.cae) {
        toast('La factura ya tiene CAE', `CAE ${factura.cae}`, 'info');
        return;
    }

    setBotonCargando(boton, true, 'Emitiendo…');
    try {
        const detalle = await api.emitirCae(id, factura?.tipoComprobante || undefined);
        if (detalle.cae) {
            toast(
                `Factura ${numeroComprobante(detalle)} autorizada`,
                `CAE ${detalle.cae} · vence ${formatearFecha(detalle.caeFechaVencimiento)}`,
                'success'
            );
        } else {
            toast(
                'AFIP no autorizó el comprobante',
                detalle.motivoRechazo || 'Revisá los datos fiscales e intentá nuevamente.',
                'warning'
            );
        }
        await cargarFacturas(state.filtros);
        if (!$('#modal-detalle').hidden) {
            await openDetalle(id);
        }
    } catch (error) {
        toast('No se pudo emitir el CAE', mensajeDe(error), 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

async function anularFactura(id: number) {
    const factura = state.facturas.find((f) => Number(f.id) === id);
    const conCae = Boolean(factura?.cae);

    const confirmado = await confirmar({
        titulo: 'Anular comprobante',
        mensaje: conCae
            ? `La factura ${numeroComprobante(factura)} ya tiene CAE. Se realizará una anulación lógica; recordá que ante AFIP corresponde emitir una Nota de Crédito. ¿Continuar?`
            : `¿Querés anular la factura ${numeroComprobante(factura)}? El comprobante quedará marcado como ANULADA.`,
        textoConfirmar: 'Anular',
        peligro: true
    });
    if (!confirmado) return;

    try {
        await api.actualizarEstado(id, 'ANULADA', 'Anulada desde la interfaz web');
        toast('Comprobante anulado', 'La factura quedó marcada como ANULADA.', 'success');
        cerrarDetalle();
        await cargarFacturas(state.filtros);
    } catch (error) {
        toast('No se pudo anular', mensajeDe(error), 'error');
    }
}

async function eliminarFactura(id: number) {
    const factura = state.facturas.find((f) => Number(f.id) === id);
    const confirmado = await confirmar({
        titulo: 'Eliminar comprobante',
        mensaje: `Se va a eliminar definitivamente la factura ${numeroComprobante(factura)}. Esta acción no se puede deshacer. ¿Continuar?`,
        textoConfirmar: 'Eliminar',
        peligro: true
    });
    if (!confirmado) return;

    try {
        await api.eliminarFactura(id);
        toast('Comprobante eliminado', 'El registro se eliminó del sistema.', 'success');
        cerrarDetalle();
        await cargarFacturas(state.filtros);
    } catch (error) {
        toast('No se pudo eliminar', mensajeDe(error), 'error');
    }
}

function bindModales() {
    const modalDetalle = $('#modal-detalle');
    const modalConfirm = $('#modal-confirm');

    modalDetalle?.addEventListener('click', (evento) => {
        if ((evento.target as HTMLElement).closest('[data-close]')) cerrarDetalle();
    });

    $('#detalle-btn-editar')?.addEventListener('click', () => {
        const id = state.detalleActual?.id;
        if (id) editarFactura(Number(id));
    });

    $('#detalle-btn-imprimir')?.addEventListener('click', () => {
        const id = state.detalleActual?.id;
        if (id) imprimirFactura(Number(id));
    });

    $('#detalle-btn-emitir')?.addEventListener('click', (evento) => {
        const id = state.detalleActual?.id;
        if (id) emitirFactura(Number(id), evento.currentTarget as HTMLButtonElement);
    });

    modalConfirm?.addEventListener('click', (evento) => {
        if ((evento.target as HTMLElement).closest('[data-confirm-close]')) resolverConfirmacion(false);
    });

    $('#confirm-ok')?.addEventListener('click', () => resolverConfirmacion(true));

    document.addEventListener('keydown', (evento) => {
        if (evento.key !== 'Escape') return;
        if (!$('#modal-clientes').hidden) cerrarBuscadorClientes();
        else if (!$('#modal-productos').hidden) cerrarExplorerProductos();
        else if (!modalConfirm.hidden) resolverConfirmacion(false);
        else if (!modalDetalle.hidden) cerrarDetalle();
    });
}

async function openDetalle(id: number) {
    const modal = $('#modal-detalle');
    const cuerpo = $('#detalle-body');
    const botonEmitir = $('#detalle-btn-emitir');
    if (!modal || !cuerpo) return;

    modal.hidden = false;
    cuerpo.innerHTML = '<div class="empty-state">Cargando comprobante…</div>';
    botonEmitir.hidden = true;
    $('#detalle-btn-editar').hidden = true;
    document.body.style.overflow = 'hidden';

    try {
        const detalle = await api.obtenerFactura(id);
        state.detalleActual = detalle;
        renderDetalle(detalle);
    } catch (error) {
        cuerpo.innerHTML = `<div class="empty-state"><strong>No se pudo cargar el comprobante</strong>${escaparHtml(mensajeDe(error))}</div>`;
        toast('Error al abrir el comprobante', mensajeDe(error), 'error');
    }
}

function renderDetalle(detalle: FacturaDetalleDTO) {
    const moneda = detalle.tipoMonedaCodigo || 'ARS';
    const puedeEmitir = !detalle.cae && detalle.estado !== 'ANULADA';

    $('#detalle-titulo').textContent = `Factura ${numeroComprobante(detalle)}`;
    $('#detalle-subtitulo').textContent = `${etiquetaTipo(detalle.tipoComprobante)} · ${formatearFecha(detalle.fechaEmision)}`;

    const discriminaDetalle = detalle.tipoComprobante === 1 || detalle.tipoComprobante === 6;
    const filas = detalle.items.map((item) => `
        <tr>
            <td>
                <span class="cell-strong">${escaparHtml(item.denominacion)}</span>
                <div class="hint">${escaparHtml([item.codigo, item.listaPrecio ? `Lista ${item.listaPrecio}` : '', item.marca, item.porcentajeBonificacion ? `Bonif. ${formatearCantidad(item.porcentajeBonificacion)} %` : ''].filter(Boolean).join(' · '))}</div>
            </td>
            <td class="num">${formatearCantidad(item.cantidad)}</td>
            <td class="num">${formatearMoneda(item.precioUnitario, moneda)}</td>
            <td class="num">${discriminaDetalle
                ? formatearMoneda(item.importeIva, moneda)
                : '<span class="hint" title="La Factura C no discrimina IVA">No discrimina</span>'}</td>
            <td class="cell-money">${formatearMoneda(item.importeSubtotal, moneda)}</td>
        </tr>
    `).join('');

    const fiscal = detalle.cae
        ? `
            <div class="fiscal-box">
                <h4>Autorización AFIP</h4>
                <div class="detail-grid" style="margin-bottom:0">
                    <div class="detail-item">
                        <span class="label">CAE</span>
                        <span class="value cae">${escaparHtml(detalle.cae)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Vencimiento CAE</span>
                        <span class="value">${formatearFecha(detalle.caeFechaVencimiento)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Resultado</span>
                        <span class="value">${escaparHtml(detalle.resultadoAfip || 'A')}</span>
                    </div>
                </div>
                ${detalle.motivoRechazo ? `<p class="motivo">${escaparHtml(detalle.motivoRechazo)}</p>` : ''}
                ${detalle.observaciones ? `<p class="obs">Observaciones: ${escaparHtml(detalle.observaciones)}</p>` : ''}
            </div>
        `
        : `
            <div class="fiscal-box">
                <h4>Sin CAE</h4>
                <p class="obs" style="margin:0">Este comprobante todavía no fue autorizado por AFIP.</p>
                ${detalle.motivoRechazo ? `<p class="motivo">${escaparHtml(detalle.motivoRechazo)}</p>` : ''}
            </div>
        `;

    $('#detalle-body').innerHTML = `
        <div class="detail-hero">
            <div>
                <h3>${escaparHtml(detalle.clienteDenominacion || 'Consumidor Final')}</h3>
                <p>${escaparHtml(detalle.condicionIva || '—')}${detalle.clienteCuit ? ` · CUIT ${escaparHtml(detalle.clienteCuit)}` : ''}</p>
            </div>
            <div class="detail-badges">
                ${badgeEstado(detalle.estado)}
                <span class="badge badge-activa">${escaparHtml(etiquetaTipo(detalle.tipoComprobante))}</span>
                ${detalle.cae ? '<span class="badge badge-emitida">Con CAE</span>' : '<span class="badge badge-simulado">Pendiente</span>'}
            </div>
        </div>

        <div class="detail-grid">
            <div class="detail-item"><span class="label">Fecha de emisión</span><span class="value">${formatearFecha(detalle.fechaEmision)}</span></div>
            <div class="detail-item"><span class="label">Punto de venta</span><span class="value">${escaparHtml(detalle.puntoVentaDescripcion || '—')}</span></div>
            <div class="detail-item"><span class="label">Moneda</span><span class="value">${escaparHtml(`${detalle.tipoMonedaCodigo || 'ARS'} · ${detalle.tipoMonedaDenominacion || ''}`)}</span></div>
            <div class="detail-item"><span class="label">Total</span><span class="value">${formatearMoneda(detalle.importeTotal, moneda)}</span></div>
            <div class="detail-item"><span class="label">Cobrado</span><span class="value">${formatearMoneda(detalle.importeCobrado, moneda)}</span></div>
            <div class="detail-item"><span class="label">Saldo</span><span class="value">${formatearMoneda(detalle.importeSaldo, moneda)}</span></div>
        </div>

        <div class="table-wrap">
            <table class="table" style="min-width:560px">
                <thead>
                <tr><th>Artículo</th><th class="num">Cantidad</th><th class="num">Precio unit.</th><th class="num">IVA ${formatearCantidad(alicuotaIva())}%</th><th class="num">Subtotal</th></tr>
                </thead>
                <tbody>${filas || filaVacia(5, 'Sin ítems', 'El comprobante no tiene renglones cargados.')}</tbody>
            </table>
        </div>

        ${fiscal}
    `;

    const botonEmitir = $('#detalle-btn-emitir');
    botonEmitir.hidden = !puedeEmitir;
    botonEmitir.textContent = 'Emitir CAE';
    $('#detalle-btn-editar').hidden = !puedeEmitir;
}

/** Abre el comprobante en PDF en una pestaña nueva, desde donde se imprime. */
function imprimirFactura(id: number) {
    const ventana = window.open(api.urlPdfFactura(id), '_blank');
    if (!ventana) {
        toast('No se pudo abrir el PDF', 'El navegador bloqueó la ventana emergente: permitila para este sitio.', 'warning');
    }
}

function cerrarDetalle() {
    const modal = $('#modal-detalle');
    if (!modal) return;
    modal.hidden = true;
    state.detalleActual = null;
    document.body.style.overflow = '';
}

let resolverConfirmacionActual: ((valor: boolean) => void) | null = null;

function confirmar({ titulo, mensaje, textoConfirmar = 'Confirmar', peligro = true }: {
    titulo: string;
    mensaje: string;
    textoConfirmar?: string;
    peligro?: boolean;
}): Promise<boolean> {
    const modal = $('#modal-confirm');
    if (!modal) return Promise.resolve(false);

    $('#confirm-title').textContent = titulo;
    $('#confirm-message').textContent = mensaje;

    const boton = $('#confirm-ok');
    boton.textContent = textoConfirmar;
    boton.className = 'btn ' + (peligro ? 'btn-danger' : 'btn-primary');

    modal.hidden = false;
    document.body.style.overflow = 'hidden';

    return new Promise<boolean>((resolver) => {
        resolverConfirmacionActual = resolver;
    });
}

function resolverConfirmacion(valor: boolean) {
    const modal = $('#modal-confirm');
    if (modal) modal.hidden = true;
    document.body.style.overflow = '';
    if (resolverConfirmacionActual) {
        resolverConfirmacionActual(valor);
        resolverConfirmacionActual = null;
    }
}

function bindAfip() {
    $('#btn-probar-afip')?.addEventListener('click', probarConexionAfip);
    $('#btn-sync-monedas')?.addEventListener('click', sincronizarMonedasAfip);
}

function renderAfipUI() {
    const estado = state.afip;
    const pill = $('#afip-pill');
    const sidebar = $('#sidebar-afip');
    const sidebarTexto = $('#sidebar-afip-text');

    if (!estado) {
        if (pill) {
            pill.className = 'pill pill-muted';
            pill.innerHTML = '<span class="dot"></span> AFIP sin datos';
        }
        if (sidebarTexto) sidebarTexto.textContent = 'AFIP sin datos';
        return;
    }

    const info = etiquetaModo(estado);
    if (pill) {
        pill.className = `pill ${info.clase}`;
        pill.innerHTML = `<span class="dot"></span> ${escaparHtml(info.texto)}`;
    }
    if (sidebar) {
        sidebar.className = `sidebar-status ${info.clase === 'pill-ok' ? 'is-ok' : ''}`;
    }
    if (sidebarTexto) sidebarTexto.textContent = info.texto;

    const modoBadge = $('#afip-mode-badge');
    if (modoBadge) {
        modoBadge.className = `pill ${info.clase}`;
        modoBadge.innerHTML = `<span class="dot"></span> ${escaparHtml(estado.modo || '—')}`;
    }

    setTexto('#afip-mensaje', estado.mensaje || '—');
    setTexto('#afip-cuit', estado.cuit || 'No configurado');
    setTexto('#afip-credenciales', estado.credencialesConfiguradas ? 'Configuradas' : 'Pendientes');
    setTexto('#afip-tipo', etiquetaTipo(estado.tipoComprobanteDefault));
    setTexto('#afip-alicuota', `${estado.alicuotaIva ?? 21}%`);
    setTexto('#afip-cliente', estado.cliente || '—');

    const hint = $('#nueva-afip-hint');
    if (hint) {
        if (estado.simulado) {
            hint.textContent = 'Modo simulado: el CAE será ficticio y no se contactará a AFIP.';
        } else if (!estado.habilitado) {
            hint.textContent = 'AFIP deshabilitada: la factura se guardará sin CAE.';
        } else if (estado.credencialesConfiguradas) {
            hint.textContent = 'AFIP configurada: se solicitará el CAE al guardar y emitir.';
        } else {
            hint.textContent = 'Faltan credenciales AFIP: configuralas para emitir.';
        }
    }
}

async function probarConexionAfip(evento: MouseEvent) {
    const boton = evento.currentTarget as HTMLButtonElement;
    setBotonCargando(boton, true, 'Probando…');
    const resultado = $('#afip-dummy-result');
    try {
        const respuesta = await api.probarConexionAfip();
        if (resultado) {
            resultado.hidden = false;
            resultado.className = `dummy-result ${respuesta.ok ? 'is-ok' : 'is-error'}`;
            const servidores = respuesta.servidores
                ? ` · AppServer: ${escaparHtml(respuesta.servidores.appServer || '—')} · DbServer: ${escaparHtml(respuesta.servidores.dbServer || '—')} · AuthServer: ${escaparHtml(respuesta.servidores.authServer || '—')}`
                : '';
            resultado.innerHTML = `<strong>${respuesta.ok ? 'Conexión OK' : 'Sin conexión'}</strong> — ${escaparHtml(respuesta.mensaje || '')}${servidores}`;
        }
        toast(
            respuesta.ok ? 'Diagnóstico AFIP OK' : 'Diagnóstico AFIP con observaciones',
            respuesta.mensaje,
            respuesta.ok ? 'success' : 'warning'
        );
    } catch (error) {
        if (resultado) {
            resultado.hidden = false;
            resultado.className = 'dummy-result is-error';
            resultado.innerHTML = `<strong>Error de conexión</strong> — ${escaparHtml(mensajeDe(error))}`;
        }
        toast('Error al probar la conexión', mensajeDe(error), 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

async function sincronizarMonedasAfip(evento: MouseEvent) {
    const boton = evento.currentTarget as HTMLButtonElement;
    setBotonCargando(boton, true, 'Sincronizando…');
    const resultado = $('#monedas-sync-result');
    try {
        const respuesta = await api.sincronizarMonedasAfip();
        if (resultado) {
            resultado.hidden = false;
            resultado.className = `dummy-result ${respuesta.ok ? 'is-ok' : 'is-error'}`;
            resultado.innerHTML = `<strong>${respuesta.ok ? 'Sincronización OK' : 'Sin cambios'}</strong> — ${escaparHtml(respuesta.mensaje || '')}`;
        }
        if (respuesta.ok) {
            await cargarCatalogos();
            poblarSelects();
            renderItems();
        }
        toast(
            respuesta.ok ? 'Monedas sincronizadas' : 'Sincronización no disponible',
            respuesta.mensaje,
            respuesta.ok ? 'success' : 'warning'
        );
    } catch (error) {
        if (resultado) {
            resultado.hidden = false;
            resultado.className = 'dummy-result is-error';
            resultado.innerHTML = `<strong>Error al sincronizar</strong> — ${escaparHtml(mensajeDe(error))}`;
        }
        toast('Error al sincronizar monedas', mensajeDe(error), 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

function clienteSeleccionado() {
    const valor = $<HTMLInputElement>('#nueva-cliente')?.value;
    if (!valor) return null;
    return state.catalogos.clientes.find((c) => Number(c.id) === Number(valor)) || null;
}

function monedaSeleccionada() {
    const valor = $<HTMLInputElement>('#nueva-moneda')?.value;
    const moneda = state.catalogos.tiposMoneda.find((m) => Number(m.id) === Number(valor));
    return moneda?.codigo || 'ARS';
}

function etiquetaTipo(codigo: number | null | undefined): string {
    if (!codigo) return 'Comprobante';
    return TIPOS_COMPROBANTE[Number(codigo)] || `Comprobante ${codigo}`;
}

function etiquetaMoneda(moneda: MonedaItem): string {
    const iso = moneda.codigo || moneda.codigoAfip || '';
    const afip = moneda.codigoAfip && moneda.codigoAfip !== iso ? ` (${moneda.codigoAfip})` : '';
    return `${iso}${afip} · ${moneda.denominacion}`;
}

function numeroComprobante(
    factura: { numeroFactura?: number | null; numeroAfip?: number | null } | null | undefined
): string {
    if (!factura) return '—';
    const numero = factura.numeroFactura ?? factura.numeroAfip;
    return numero !== null && numero !== undefined ? `N° ${numero}` : 'N° —';
}

function etiquetaModo(estado: AfipEstadoDTO) {
    if (estado.modo === 'SIMULADO') return { texto: 'AFIP simulada', clase: 'pill-warn' };
    if (estado.modo === 'HOMOLOGACION') return { texto: 'AFIP homologación', clase: 'pill-ok' };
    if (estado.modo === 'PRODUCCION') return { texto: 'AFIP producción', clase: 'pill-info' };
    if (estado.modo === 'DESHABILITADO') return { texto: 'AFIP deshabilitada', clase: 'pill-danger' };
    return { texto: 'AFIP', clase: 'pill-muted' };
}

function badgeEstado(estado: string | null | undefined): string {
    const valor = String(estado || 'ACTIVA').toUpperCase();
    const clase = valor === 'ANULADA' ? 'badge-anulada' : (valor === 'EMITIDA' ? 'badge-emitida' : 'badge-activa');
    const texto = valor.charAt(0) + valor.slice(1).toLowerCase();
    return `<span class="badge ${clase}">${escaparHtml(texto)}</span>`;
}

function chipCae(factura: FacturaReporteDTO): string {
    if (factura.cae) {
        return `<span class="cae-chip" title="CAE ${escaparHtml(factura.cae)}">${escaparHtml(factura.cae)}</span>`;
    }
    return '<span class="cae-chip is-pending">Pendiente</span>';
}

function filaVacia(columnas: number, titulo: string, detalle?: string): string {
    return `<tr><td colspan="${columnas}"><div class="empty-state"><strong>${escaparHtml(titulo)}</strong>${escaparHtml(detalle || '')}</div></td></tr>`;
}

function icono(nombre: string): string {
    const trazos: Record<string, string> = {
        ojo: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',
        rayo: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
        anular: '<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',
        lapiz: '<path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
        impresora: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="1"/><path d="M6 14h12v7H6z"/>',
        papelera: '<path d="M4 7h16"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M6 7l1 13h10l1-13"/><path d="M9 7V4h6v3"/>'
    };
    return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${trazos[nombre] || ''}</svg>`;
}

function formatearMoneda(valor: number | null | undefined, codigo: string = 'ARS'): string {
    const numero = Number(valor || 0);
    try {
        return new Intl.NumberFormat('es-AR', {
            style: 'currency',
            currency: codigo || 'ARS',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(numero);
    } catch (error) {
        return `$ ${numero.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
}

function formatearCantidad(valor: number | null | undefined): string {
    const numero = Number(valor || 0);
    return Number.isInteger(numero) ? String(numero) : numero.toLocaleString('es-AR', { maximumFractionDigits: 2 });
}

function formatearFecha(valor: string | null | undefined): string {
    if (!valor) return '—';
    if (typeof valor === 'string') {
        const soloFecha = valor.substring(0, 10);
        const partes = soloFecha.split('-');
        if (partes.length === 3 && partes[0].length === 4) {
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }
    }
    const fecha = new Date(valor);
    if (Number.isNaN(fecha.getTime())) return '—';
    return fecha.toLocaleDateString('es-AR');
}

function setFechaHoy() {
    const fecha = new Date();
    const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
    const input = $<HTMLInputElement>('#nueva-fecha');
    if (input) input.value = local.toISOString().slice(0, 10);
}

function setTexto(selector: string, valor?: string | null) {
    const elemento = $(selector);
    if (elemento) elemento.textContent = valor ?? '—';
}

function escaparHtml(valor: unknown): string {
    return String(valor ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function setCargando(activo: boolean) {
    $('#progress-bar')?.classList.toggle('is-active', activo);
}

function setBotonCargando(boton: HTMLButtonElement | null, cargando: boolean, texto: string = 'Procesando…') {
    if (!boton) return;
    if (cargando) {
        boton.dataset.htmlOriginal = boton.innerHTML;
        boton.disabled = true;
        boton.innerHTML = `<span class="spinner"></span>${escaparHtml(texto)}`;
    } else {
        boton.disabled = false;
        if (boton.dataset.htmlOriginal) {
            boton.innerHTML = boton.dataset.htmlOriginal;
            delete boton.dataset.htmlOriginal;
        }
    }
}

function toast(titulo: string, mensaje?: string | null, tipo: TipoToast = 'info') {
    const contenedor = $('#toast-container');
    if (!contenedor) return;

    const iconos: Record<string, string> = { success: '✓', error: '!', warning: '!', info: 'i' };
    const elemento = document.createElement('div');
    elemento.className = `toast is-${tipo}`;
    elemento.innerHTML = `
        <div class="toast-icon">${iconos[tipo] || 'i'}</div>
        <div class="toast-content">
            <span class="toast-title">${escaparHtml(titulo)}</span>
            ${mensaje ? `<span class="toast-message">${escaparHtml(mensaje)}</span>` : ''}
        </div>
        <button type="button" class="toast-close" aria-label="Cerrar">×</button>
    `;

    const quitar = () => {
        elemento.style.opacity = '0';
        elemento.style.transform = 'translateX(12px)';
        elemento.style.transition = 'opacity .18s ease, transform .18s ease';
        setTimeout(() => elemento.remove(), 190);
    };

    elemento.querySelector('.toast-close')?.addEventListener('click', quitar);
    contenedor.appendChild(elemento);
    setTimeout(quitar, 6500);
}

/** Texto legible de cualquier valor capturado en un catch. */
function mensajeDe(error: unknown): string {
    return error instanceof Error ? error.message : String(error);
}
