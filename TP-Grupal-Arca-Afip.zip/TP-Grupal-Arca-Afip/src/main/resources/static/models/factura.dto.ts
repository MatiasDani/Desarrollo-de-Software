/**
 * Interfaces que espejan, campo por campo, los DTOs de Spring Boot.
 *
 * Correspondencia de tipos:
 *   Long / Integer / int / double  ->  number
 *   String                         ->  string
 *   boolean                        ->  boolean
 *   java.util.Date                 ->  string "yyyy-MM-dd" (spring.jackson.date-format)
 *   List<T>                        ->  T[]
 *
 * Los DTOs de entrada (Request) aceptan campos opcionales porque el PUT permite
 * enviar solo lo que cambia (por ejemplo, estado y observaciones para anular).
 */

// ---------------------------------------------------------------------------
// Entrada: com.ejemplo.dto.FacturaRequestDTO / FacturaDetalleRequestDTO
// ---------------------------------------------------------------------------

export interface FacturaDetalleRequestDTO {
    /** Id de la combinación lista de precios / artículo (no el id del artículo solo). */
    listaPrecioArticuloId: number;
    cantidad: number;
    /** De 0 a 100. Si no se envía, el backend usa 0. */
    porcentajeBonificacion?: number | null;
    /** Máximo 255 caracteres. Si no se envía, se usa la denominación del artículo. */
    descripcion?: string | null;
}

export interface FacturaRequestDTO {
    puntoVentaId?: number;
    clienteId?: number | null;
    /** En una edición, true quita el cliente (pasa a Consumidor Final). */
    sinCliente?: boolean;
    condicionIvaId?: number;
    tipoMonedaId?: number;
    fechaEmision?: string;
    importeCobrado?: number;
    observaciones?: string | null;
    estado?: string;
    /** 1 = Factura A, 6 = Factura B, 11 = Factura C. */
    tipoComprobante?: number | null;
    detalles?: FacturaDetalleRequestDTO[];
}

// ---------------------------------------------------------------------------
// Salida: com.ejemplo.dto.FacturaReporteDTO
// ---------------------------------------------------------------------------

export interface FacturaReporteDTO {
    id: number;
    numeroFactura: number | null;
    fechaEmision: string;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    importeTotal: number;
    cantidadItems: number;
    estado: string;
    cae: string | null;
    caeFechaVencimiento: string | null;
    resultadoAfip: string | null;
    tipoComprobante: number | null;
}

// ---------------------------------------------------------------------------
// Salida: com.ejemplo.dto.FacturaDetalleDTO (+ Item)
// ---------------------------------------------------------------------------

export interface FacturaDetalleItemDTO {
    listaPrecioArticuloId: number;
    articuloId: number;
    codigo: string;
    denominacion: string;
    descripcion: string;
    listaPrecioId: number;
    listaPrecio: string;
    marca: string | null;
    cantidad: number;
    precioUnitario: number;
    porcentajeBonificacion: number;
    importeNeto: number;
    importeIva: number;
    importeSubtotal: number;
}

export interface FacturaDetalleDTO {
    id: number;
    numeroFactura: number | null;
    numeroAfip: number | null;
    fechaEmision: string;
    clienteId: number | null;
    clienteDenominacion: string | null;
    clienteCuit: string | null;
    condicionIvaId: number;
    condicionIva: string;
    puntoVentaId: number;
    puntoVentaDescripcion: string;
    puntoVentaNumero: number;
    tipoMonedaId: number;
    tipoMonedaCodigo: string;
    tipoMonedaDenominacion: string;
    importeCobrado: number;
    importeSaldo: number;
    importeTotal: number;
    estado: string;
    observaciones: string | null;
    cae: string | null;
    caeFechaVencimiento: string | null;
    resultadoAfip: string | null;
    motivoRechazo: string | null;
    tipoComprobante: number | null;
    fechaAnulacion: string | null;
    items: FacturaDetalleItemDTO[];
}

// ---------------------------------------------------------------------------
// Salida: com.ejemplo.dto.PaginaDTO<T> y ResumenFacturacionDTO
// ---------------------------------------------------------------------------

export interface PaginaDTO<T> {
    contenido: T[];
    /** Base 0. */
    pagina: number;
    tamanio: number;
    totalElementos: number;
    totalPaginas: number;
    primera: boolean;
    ultima: boolean;
}

export interface ResumenFacturacionDTO {
    totalFacturado: number;
    vigentes: number;
    conCae: number;
    pendientes: number;
    anuladas: number;
    ultimasFacturas: FacturaReporteDTO[];
}

// ---------------------------------------------------------------------------
// Salida: com.ejemplo.dto.CatalogoDTO y sus ítems
// ---------------------------------------------------------------------------

export interface PuntoVentaItem {
    id: number;
    numero: number;
    descripcion: string;
    domicilioComercial: string | null;
    tipoEmision: string | null;
}

export interface ClienteItem {
    id: number;
    denominacion: string;
    cuitCuil: string | null;
    email: string | null;
    telefono: string | null;
    domicilio: string | null;
    condicionIvaId: number | null;
    condicionIva: string | null;
}

export interface CondicionIvaItem {
    id: number;
    codigoAfip: number;
    denominacion: string;
}

export interface MonedaItem {
    id: number;
    /** ISO 4217 (ARS, USD...). */
    codigo: string;
    /** MonId de AFIP (PES, DOL...). */
    codigoAfip: string;
    denominacion: string;
    simbolo: string;
    cotizacion: number;
}

export interface ArticuloItem {
    id: number;
    codigo: string;
    denominacion: string;
    marca: string | null;
    rubro: string | null;
}

export interface ListaPrecioItem {
    id: number;
    codigo: string;
    denominacion: string;
}

export interface ListaPrecioArticuloItem {
    id: number;
    listaPrecioId: number;
    articuloId: number;
    precioVenta: number;
}

/** Salida: com.ejemplo.dto.ProductoCatalogoDTO (explorador de productos, GET /api/catalogos/productos). */
export interface ProductoCatalogoDTO {
    listaPrecioArticuloId: number;
    articuloId: number;
    codigo: string;
    denominacion: string;
    rubro: string | null;
    marca: string | null;
    listaPrecioId: number;
    listaPrecio: string;
    precioVenta: number;
}

export interface CatalogoDTO {
    puntosVenta: PuntoVentaItem[];
    clientes: ClienteItem[];
    condicionesIva: CondicionIvaItem[];
    tiposMoneda: MonedaItem[];
    articulos: ArticuloItem[];
    listasPrecios: ListaPrecioItem[];
    listaPrecioArticulos: ListaPrecioArticuloItem[];
}

// ---------------------------------------------------------------------------
// Integración AFIP: com.ejemplo.afip.dto.*
// ---------------------------------------------------------------------------

export interface AfipEstadoDTO {
    habilitado: boolean;
    /** DESHABILITADO | SIMULADO | HOMOLOGACION | PRODUCCION. */
    modo: string;
    simulado: boolean;
    cuit: string | null;
    credencialesConfiguradas: boolean;
    tipoComprobanteDefault: number;
    alicuotaIva: number;
    wsaaUrl: string;
    wsfeUrl: string;
    cliente: string;
    mensaje: string;
}

export interface EstadoServidores {
    appServer: string | null;
    dbServer: string | null;
    authServer: string | null;
}

export interface AfipConexionDTO {
    ok: boolean;
    modo: string;
    servidores: EstadoServidores | null;
    mensaje: string;
}

export interface MonedasSyncDTO {
    ok: boolean;
    modo: string;
    mensaje: string;
    nuevas: number;
    actualizadas: number;
    total: number;
    monedas: MonedaItem[];
}

export interface EmisionCaeRequestDTO {
    tipoComprobante?: number;
}

// ---------------------------------------------------------------------------
// Solo del cliente: parámetros de consulta de GET /api/facturas
// ---------------------------------------------------------------------------

export interface FacturaFiltrosDTO {
    /** Cliente elegido en el pop-up "Buscar cliente". */
    clienteId?: number;
    /** Parte del nombre o del CUIT del cliente ("consumidor" encuentra las facturas sin cliente). */
    cliente?: string;
    /** Número de comprobante tal como se ve en el listado. */
    numero?: number;
    fechaDesde?: string;
    fechaHasta?: string;
    estado?: string;
    montoMinimo?: number;
}

/** Valores que acepta el parámetro `orden` de GET /api/facturas y /api/facturas/paginado. */
export type OrdenFacturas =
    | 'fecha_desc' | 'fecha_asc'
    | 'numero_desc' | 'numero_asc'
    | 'importe_desc' | 'importe_asc'
    | 'cliente_asc' | 'cliente_desc';
