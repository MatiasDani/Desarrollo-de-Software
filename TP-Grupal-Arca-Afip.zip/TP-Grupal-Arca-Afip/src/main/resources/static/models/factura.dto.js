/**
 * Interfaces que espejan, campo por campo, los DTOs de Spring Boot.
 *
 * Correspondencia de tipos:
 *   Long / Integer / int / double  ->  number
 *   String                         ->  string
 *   boolean                        ->  boolean
 *   java.util.Date                 ->  string "yyyy-MM-dd" (spring.jackson.date-format)
 *   List<T>                        ->  T[]
 *
 * Los DTOs de entrada (Request) aceptan campos opcionales porque el PUT permite
 * enviar solo lo que cambia (por ejemplo, estado y observaciones para anular).
 */
export {};
