package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.MonedasAfip;
import com.ejemplo.afip.model.ComprobanteAfip;
import com.ejemplo.afip.wsfe.FECAERequest;
import com.ejemplo.afip.wsfe.FECAEDetRequest;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class AfipWsfeJaxwsClientTest {
    private final AfipWsfeJaxwsClient client = new AfipWsfeJaxwsClient(new AfipProperties());

    @Test
    void armaElRequestDeFacturaAConIvaDiscriminadoYCondicionIvaReceptor() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                1, 1, 42, LocalDate.of(2026, 1, 15), 121.0,
                80, 20111111112L, "ARS", 1.0, 21.0, true, 1);

        FECAERequest request = client.construirRequest(comprobante);

        assertNotNull(request.getFeCabReq());
        assertEquals(1, request.getFeCabReq().getCantReg());
        assertEquals(1, request.getFeCabReq().getPtoVta());
        assertEquals(1, request.getFeCabReq().getCbteTipo());

        FECAEDetRequest detalle = request.getFeDetReq().getFECAEDetRequest().get(0);
        assertEquals(1, detalle.getConcepto());
        assertEquals(80, detalle.getDocTipo());
        assertEquals(20111111112L, detalle.getDocNro());
        assertEquals(42, detalle.getCbteDesde());
        assertEquals(42, detalle.getCbteHasta());
        assertEquals("20260115", detalle.getCbteFch());
        assertEquals(121.0, detalle.getImpTotal(), 0.001);
        assertEquals(100.0, detalle.getImpNeto(), 0.001);
        assertEquals(21.0, detalle.getImpIVA(), 0.001);
        assertEquals("PES", detalle.getMonId());
        assertEquals(1.0, detalle.getMonCotiz(), 0.001);
        assertEquals(1, detalle.getCondicionIVAReceptorId());

        assertNotNull(detalle.getIva());
        assertEquals(5, detalle.getIva().getAlicIva().get(0).getId());
        assertEquals(100.0, detalle.getIva().getAlicIva().get(0).getBaseImp(), 0.001);
        assertEquals(21.0, detalle.getIva().getAlicIva().get(0).getImporte(), 0.001);
    }

    @Test
    void noDiscriminaIvaEnFacturaC() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                2, 11, 7, LocalDate.of(2026, 2, 1), 100.0,
                99, 0L, "ARS", 1.0, 21.0, false, 5);

        FECAEDetRequest detalle = client.construirRequest(comprobante)
                .getFeDetReq().getFECAEDetRequest().get(0);

        assertEquals(100.0, detalle.getImpNeto(), 0.001);
        assertEquals(0.0, detalle.getImpIVA(), 0.001);
        assertNull(detalle.getIva());
        assertEquals(5, detalle.getCondicionIVAReceptorId());
    }

    @Test
    void informaElCodigoAfipDeLaMonedaExtranjera() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                1, 1, 7, LocalDate.of(2026, 1, 15), 1450.0,
                99, 0L, "USD", 1450.0, 21.0, true, 5);

        FECAEDetRequest detalle = client.construirRequest(comprobante)
                .getFeDetReq().getFECAEDetRequest().get(0);

        assertEquals("DOL", detalle.getMonId());
        assertEquals(1450.0, detalle.getMonCotiz(), 0.001);
    }

    @Test
    void mapeaCodigosIsoYCodigosAfipDeMonedas() {
        assertEquals("PES", MonedasAfip.codigoAfip("ARS"));
        assertEquals("DOL", MonedasAfip.codigoAfip("usd"));
        assertEquals("060", MonedasAfip.codigoAfip("EUR"));
        assertEquals("060", MonedasAfip.codigoAfip("060"));
        assertEquals("021", MonedasAfip.codigoAfip("GBP"));
        assertEquals("PES", MonedasAfip.codigoAfip(null));

        assertEquals("ARS", MonedasAfip.codigoIso("PES"));
        assertEquals("EUR", MonedasAfip.codigoIso("060"));
        assertEquals("GBP", MonedasAfip.codigoIso("021"));
        assertEquals("XAU", MonedasAfip.codigoIso("049"));
        assertEquals(49, MonedasAfip.catalogo().size(), "El catálogo replica las 49 monedas de AFIP");
    }
}
