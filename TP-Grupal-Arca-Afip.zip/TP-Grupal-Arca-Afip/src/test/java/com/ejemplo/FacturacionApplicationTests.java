package com.ejemplo;

import com.ejemplo.controller.CatalogoController;
import com.ejemplo.dto.CatalogoDTO;
import com.ejemplo.dto.FacturaDetalleDTO;
import com.ejemplo.dto.FacturaDetalleRequestDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ResumenFacturacionDTO;
import com.ejemplo.exception.RecursoNoEncontradoException;
import com.ejemplo.service.FacturaService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(properties = "afip.modo=SIMULADO")
class FacturacionApplicationTests {
	@Autowired
	private FacturaService facturaService;

	@Autowired
	private CatalogoController catalogoController;

	@jakarta.persistence.PersistenceContext
	private jakarta.persistence.EntityManager em;

	@Test
	void elReporteTraeTodasLasFacturas() {
		List<FacturaReporteDTO> reporte = facturaService.obtenerReporte();
		assertTrue(reporte.size() >= 8);
	}

	@Test
	void filtraPorEstado() {
		List<FacturaReporteDTO> anuladas = facturaService.buscarFacturasFiltradas(null, null, "ANULADA", null);
		assertTrue(anuladas.size() >= 2);
	}

	@Test
	void filtraPorMontoMinimo() {
		List<FacturaReporteDTO> resultado = facturaService.buscarFacturasFiltradas(null, null, null, 1000000.0);
		for (FacturaReporteDTO f : resultado) {
			assertTrue(f.getImporteTotal() >= 1000000.0);
		}
	}

	@Test
	void paginaElListadoDeFacturasSinSolapamiento() {
		PaginaDTO<FacturaReporteDTO> primera = facturaService.buscarFacturasPaginadas(null, null, null, null, 0, 5);

		assertEquals(5, primera.contenido().size());
		assertEquals(0, primera.pagina());
		assertEquals(5, primera.tamanio());
		assertTrue(primera.totalElementos() >= 8);
		assertTrue(primera.totalPaginas() >= 2);
		assertTrue(primera.primera());
		assertFalse(primera.ultima());

		PaginaDTO<FacturaReporteDTO> segunda = facturaService.buscarFacturasPaginadas(null, null, null, null, 1, 5);
		assertEquals(1, segunda.pagina());
		assertFalse(segunda.primera());

		Set<Long> idsPrimera = primera.contenido().stream().map(FacturaReporteDTO::getId).collect(Collectors.toSet());
		Set<Long> idsSegunda = segunda.contenido().stream().map(FacturaReporteDTO::getId).collect(Collectors.toSet());
		assertTrue(Collections.disjoint(idsPrimera, idsSegunda), "Las páginas no deben repetir comprobantes");
	}

	@Test
	void acotaLaPaginaPedidaYElTamanio() {
		PaginaDTO<FacturaReporteDTO> grande = facturaService.buscarFacturasPaginadas(null, null, null, null, 0, 500);
		assertEquals(100, grande.tamanio());

		PaginaDTO<FacturaReporteDTO> fueraDeRango = facturaService.buscarFacturasPaginadas(null, null, null, null, 9999, 5);
		assertTrue(fueraDeRango.ultima());
		assertEquals(fueraDeRango.totalPaginas() - 1, fueraDeRango.pagina());
		assertFalse(fueraDeRango.contenido().isEmpty());
	}

	@Test
	void laPaginacionRespetaLosFiltros() {
		PaginaDTO<FacturaReporteDTO> anuladas = facturaService.buscarFacturasPaginadas(null, null, "ANULADA", null, 0, 100);
		assertTrue(anuladas.totalElementos() >= 2);
		for (FacturaReporteDTO f : anuladas.contenido()) {
			assertEquals("ANULADA", f.getEstado());
		}
	}

	@Test
	void elResumenDelPanelCoincideConElListadoCompleto() {
		List<FacturaReporteDTO> todas = facturaService.obtenerReporte();
		ResumenFacturacionDTO resumen = facturaService.obtenerResumen(5);

		List<FacturaReporteDTO> vigentes = todas.stream().filter(f -> !"ANULADA".equals(f.getEstado())).toList();
		long conCae = vigentes.stream().filter(f -> f.getCae() != null && !f.getCae().isBlank()).count();
		double total = vigentes.stream().mapToDouble(FacturaReporteDTO::getImporteTotal).sum();

		assertEquals(vigentes.size(), resumen.vigentes());
		assertEquals(conCae, resumen.conCae());
		assertEquals(vigentes.size() - conCae, resumen.pendientes());
		assertEquals(todas.size() - vigentes.size(), resumen.anuladas());
		assertEquals(total, resumen.totalFacturado(), 0.01);

		assertEquals(5, resumen.ultimasFacturas().size());
		assertTrue(resumen.ultimasFacturas().get(0).getId() > resumen.ultimasFacturas().get(4).getId());
	}

	@Test
	void elMismoArticuloDeDistintaListaVaEnRenglonesSeparados() {
		CatalogoDTO catalogo = catalogoController.obtenerCatalogos();
		int cantidadListas = catalogo.listasPrecios().size();
		assertTrue(cantidadListas >= 2);

		Map<Long, List<CatalogoDTO.ListaPrecioArticuloItem>> porArticulo = catalogo.listaPrecioArticulos().stream()
				.collect(Collectors.groupingBy(CatalogoDTO.ListaPrecioArticuloItem::articuloId));
		List<Long> enTodas = porArticulo.entrySet().stream()
				.filter(e -> e.getValue().size() == cantidadListas).map(Map.Entry::getKey).toList();
		assertTrue(enTodas.size() >= 2, "Debe haber al menos dos artículos presentes en todas las listas");

		CatalogoDTO.ListaPrecioArticuloItem precioA = porArticulo.get(enTodas.get(0)).get(0);
		CatalogoDTO.ListaPrecioArticuloItem precioB = porArticulo.get(enTodas.get(0)).get(1);
		assertTrue(precioA.precioVenta() != precioB.precioVenta());

		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L).condicionIvaId(3L).tipoMonedaId(1L).fechaEmision(new Date()).tipoComprobante(11)
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(precioA.id()).cantidad(1.0).build(),
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(precioB.id()).cantidad(2.0).build()))
				.build());

		FacturaDetalleDTO detalle = facturaService.obtenerDetalle(creada.getId());
		assertEquals(2, detalle.items().size());
		assertEquals(precioA.precioVenta(), detalle.items().get(0).precioUnitario(), 0.01);
		assertEquals(precioB.precioVenta(), detalle.items().get(1).precioUnitario(), 0.01);
		assertTrue(!detalle.items().get(0).listaPrecio().equals(detalle.items().get(1).listaPrecio()));
		assertEquals(precioA.precioVenta() + 2 * precioB.precioVenta(), detalle.importeTotal(), 0.01);

		facturaService.eliminar(creada.getId());
	}

	@Test
	void validaLosRenglones() {
		FacturaRequestDTO.FacturaRequestDTOBuilder base = FacturaRequestDTO.builder()
				.puntoVentaId(1L).condicionIvaId(3L).tipoMonedaId(1L).fechaEmision(new Date());

		assertThrows(IllegalArgumentException.class, () -> facturaService.crear(base
				.detalles(List.of(FacturaDetalleRequestDTO.builder().cantidad(1.0).build())).build()));
		assertThrows(RecursoNoEncontradoException.class, () -> facturaService.crear(base
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(999999L).cantidad(1.0).build())).build()));
		assertThrows(IllegalArgumentException.class, () -> facturaService.crear(base
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(0).build())).build()));
		assertThrows(IllegalArgumentException.class, () -> facturaService.crear(base
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(0.5).build())).build()));
		assertThrows(IllegalArgumentException.class, () -> facturaService.crear(base
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(1.0)
						.porcentajeBonificacion(150.0).build())).build()));
	}

	@Test
	void losPopUpsDeProductosYClientesBuscanPaginadoEnLaBase() {
		var todos = catalogoController.buscarProductos(null, null, 0, 100);
		assertEquals(catalogoController.listaPrecioArticulos().size(), todos.totalElementos());

		var pagina1 = catalogoController.buscarProductos(null, null, 0, 5);
		var ultima = catalogoController.buscarProductos(null, null, pagina1.totalPaginas() - 1, 5);
		assertEquals(5, pagina1.contenido().size());
		assertEquals((int) Math.ceil(todos.totalElementos() / 5.0), pagina1.totalPaginas());
		assertEquals(todos.totalElementos() - 5L * (pagina1.totalPaginas() - 1), ultima.contenido().size());

		// Sin importar tildes ni mayúsculas, por rubro, y combinando palabras
		var computacion = catalogoController.buscarProductos("COMPUTACION", null, 0, 100);
		assertTrue(computacion.totalElementos() > 0);
		assertTrue(computacion.contenido().stream().allMatch(pr -> "Computación".equals(pr.rubro())));
		Long lista = catalogoController.listasPrecio().get(0).id();
		var deUnaLista = catalogoController.buscarProductos("", lista, 0, 100);
		assertTrue(deUnaLista.contenido().stream().allMatch(pr -> pr.listaPrecioId().equals(lista)));

		var cliente = catalogoController.clientes().stream().filter(c -> c.cuitCuil() != null).findFirst().orElseThrow();
		var porCuit = catalogoController.buscarClientes(cliente.cuitCuil().replace("-", "").substring(0, 6), null, 0, 8);
		assertTrue(porCuit.contenido().stream().anyMatch(c -> c.id().equals(cliente.id())));
		var porRazon = catalogoController.buscarClientes(null, cliente.denominacion().substring(0, 4).toLowerCase(), 0, 8);
		assertTrue(porRazon.contenido().stream().anyMatch(c -> c.id().equals(cliente.id())));
	}

	@Test
	void buscaPorClienteYPorNumeroDeComprobante() {
		List<FacturaReporteDTO> todas = facturaService.buscarFacturasFiltradas(null, null, null, null, null);
		FacturaReporteDTO conCliente = todas.stream().filter(f -> !"Consumidor Final".equals(f.getClienteDenominacion()))
				.findFirst().orElseThrow();
		String parteDelNombre = conCliente.getClienteDenominacion().substring(0, 4).toUpperCase();

		PaginaDTO<FacturaReporteDTO> porCliente = facturaService.buscarFacturasPaginadas(
				null, null, null, null, parteDelNombre, null, 0, 100, null);
		long esperadas = todas.stream().filter(f -> f.getClienteDenominacion().toUpperCase().contains(parteDelNombre)).count();
		assertEquals(esperadas, porCliente.totalElementos(), "El COUNT respeta el filtro por cliente");
		assertTrue(porCliente.contenido().stream().allMatch(f -> f.getClienteDenominacion().toUpperCase().contains(parteDelNombre)));

		List<FacturaReporteDTO> consumidorFinal = facturaService.buscarFacturasFiltradas(
				null, null, null, null, "consumidor", null, null);
		assertTrue(!consumidorFinal.isEmpty());
		assertTrue(consumidorFinal.stream().allMatch(f -> "Consumidor Final".equals(f.getClienteDenominacion())));

		PaginaDTO<FacturaReporteDTO> porNumero = facturaService.buscarFacturasPaginadas(
				null, null, null, null, null, conCliente.getNumeroFactura(), 0, 10, null);
		assertTrue(porNumero.totalElementos() >= 1);
		assertTrue(porNumero.contenido().stream().allMatch(f -> f.getNumeroFactura().equals(conCliente.getNumeroFactura())));
		assertEquals(0, facturaService.buscarFacturasPaginadas(null, null, null, null, null, 999999L, 0, 10, null).totalElementos());

		// Elegido en el pop-up: por id de cliente, y por CUIT con o sin guiones
		CatalogoDTO.ClienteItem elegido = catalogoController.clientes().stream()
				.filter(c -> c.cuitCuil() != null && c.cuitCuil().contains("-")).findFirst().orElseThrow();
		long porId = facturaService.buscarFacturasPaginadas(null, null, null, null, elegido.id(), null, null, 0, 100, null).totalElementos();
		long porCuitConGuiones = facturaService.buscarFacturasPaginadas(null, null, null, null, elegido.cuitCuil(), null, 0, 100, null).totalElementos();
		long porCuitSinGuiones = facturaService.buscarFacturasPaginadas(null, null, null, null, elegido.cuitCuil().replace("-", ""), null, 0, 100, null).totalElementos();
		assertTrue(porId > 0);
		assertEquals(porId, porCuitConGuiones);
		assertEquals(porId, porCuitSinGuiones);
	}

	@Autowired
	private com.ejemplo.service.ComprobantePdfService comprobantePdfService;

	@Test
	void generaElPdfDeUnaFacturaParaImprimir() {
		Long id = facturaService.buscarFacturasFiltradas(null, null, null, null, null).get(0).getId();
		byte[] pdf = comprobantePdfService.generar(id);
		assertTrue(pdf.length > 1000);
		assertEquals("%PDF", new String(pdf, 0, 4));
		assertThrows(RecursoNoEncontradoException.class, () -> comprobantePdfService.generar(999999L));
	}

	@Test
	void ordenaElListadoSegunLoElegido() {
		// Por defecto: de la más reciente a la más antigua
		List<FacturaReporteDTO> porDefecto = facturaService.buscarFacturasPaginadas(null, null, null, null, 0, 100).contenido();
		for (int i = 1; i < porDefecto.size(); i++) {
			assertTrue(!porDefecto.get(i - 1).getFechaEmision().before(porDefecto.get(i).getFechaEmision()),
					"El listado por defecto debe ir de la fecha más reciente a la más antigua");
		}

		List<FacturaReporteDTO> fechaAsc = facturaService.buscarFacturasFiltradas(null, null, null, null, "fecha_asc");
		for (int i = 1; i < fechaAsc.size(); i++) {
			assertTrue(!fechaAsc.get(i - 1).getFechaEmision().after(fechaAsc.get(i).getFechaEmision()));
		}

		List<FacturaReporteDTO> importeDesc = facturaService.buscarFacturasPaginadas(null, null, null, null, 0, 100, "importe_desc").contenido();
		for (int i = 1; i < importeDesc.size(); i++) {
			assertTrue(importeDesc.get(i - 1).getImporteTotal() >= importeDesc.get(i).getImporteTotal());
		}

		List<FacturaReporteDTO> clienteAsc = facturaService.buscarFacturasFiltradas(null, null, null, null, "CLIENTE_ASC");
		for (int i = 1; i < clienteAsc.size(); i++) {
			assertTrue(clienteAsc.get(i - 1).getClienteDenominacion()
					.compareToIgnoreCase(clienteAsc.get(i).getClienteDenominacion()) <= 0);
		}

		// Una clave que no está en la lista blanca no llega al JPQL: se rechaza (400)
		assertThrows(IllegalArgumentException.class,
				() -> facturaService.buscarFacturasFiltradas(null, null, null, null, "f.id; DROP TABLE factura_venta"));
	}

	@Test
	void exigeAlMenosUnRenglonAlCrearYAlEditar() {
		FacturaRequestDTO.FacturaRequestDTOBuilder base = FacturaRequestDTO.builder()
				.puntoVentaId(1L).condicionIvaId(3L).tipoMonedaId(1L).fechaEmision(new Date());

		// Alta: sin detalles (null) o con lista vacía -> IllegalArgumentException (el handler responde 400)
		assertThrows(IllegalArgumentException.class, () -> facturaService.crear(base.detalles(null).build()));
		assertThrows(IllegalArgumentException.class, () -> facturaService.crear(base.detalles(List.of()).build()));

		// Edición: dejar la factura sin renglones tampoco se permite...
		FacturaReporteDTO creada = facturaService.crear(base
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(1.0).build()))
				.build());
		assertThrows(IllegalArgumentException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().detalles(List.of()).build()));
		assertEquals(1, facturaService.obtenerDetalle(creada.getId()).items().size());

		// ...pero un PUT parcial que no toca los renglones (detalles null) sigue siendo válido.
		facturaService.actualizar(creada.getId(), FacturaRequestDTO.builder().observaciones("sin tocar renglones").build());
		assertEquals(1, facturaService.obtenerDetalle(creada.getId()).items().size());

		facturaService.eliminar(creada.getId());
	}

	@Test
	void calculaBonificacionNetoEIvaEnFacturaB() {
		CatalogoDTO.ListaPrecioArticuloItem precio = catalogoController.listaPrecioArticulos().get(1);
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L).condicionIvaId(3L).tipoMonedaId(1L).fechaEmision(new Date()).tipoComprobante(6)
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(precio.id())
						.cantidad(2.0).porcentajeBonificacion(10.0).descripcion("Con descuento").build()))
				.build());

		FacturaDetalleDTO.Item item = facturaService.obtenerDetalle(creada.getId()).items().get(0);
		double subtotal = Math.round(precio.precioVenta() * 2 * 0.9 * 100) / 100.0;
		assertEquals(subtotal, item.importeSubtotal(), 0.01);
		assertEquals(subtotal / 1.21, item.importeNeto(), 0.01);
		assertEquals(subtotal - item.importeNeto(), item.importeIva(), 0.01);
		assertEquals("Con descuento", item.descripcion());
		facturaService.eliminar(creada.getId());
	}

	@Test
	void registraLaAuditoriaConUsuarios() {
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L).condicionIvaId(3L).tipoMonedaId(1L).fechaEmision(new Date())
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(2L).cantidad(1.0).build()))
				.build());
		facturaService.actualizar(creada.getId(), FacturaRequestDTO.builder().estado("ANULADA").build());

		Object[] auditoria = em.createQuery("SELECT f.usuarioCarga.usuario, f.usuarioModificacion.usuario, "
						+ "f.usuarioBaja.usuario, f.fechaAlta, f.fechaBaja FROM FacturaVenta f WHERE f.id = :id", Object[].class)
				.setParameter("id", creada.getId()).getSingleResult();
		assertEquals("admin", auditoria[0]);
		assertEquals("admin", auditoria[1]);
		assertEquals("admin", auditoria[2]);
		assertNotNull(auditoria[3]);
		assertNotNull(auditoria[4]);
		facturaService.eliminar(creada.getId());
	}

	@Test
	void editarUnaFacturaSinCaePermiteCambiarClienteEItems() {
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L).clienteId(1L).condicionIvaId(1L).tipoMonedaId(1L).fechaEmision(new Date())
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(1.0).build()))
				.build());

		facturaService.actualizar(creada.getId(), FacturaRequestDTO.builder()
				.sinCliente(true).condicionIvaId(3L)
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(2L).cantidad(3.0).build(),
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(7L).cantidad(1.0).build()))
				.build());

		FacturaDetalleDTO editada = facturaService.obtenerDetalle(creada.getId());
		assertEquals(null, editada.clienteId());
		assertEquals(2, editada.items().size());
		facturaService.eliminar(creada.getId());
	}

	@Test
	void crearActualizarYEliminarFactura() {
		FacturaRequestDTO createDto = FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.clienteId(1L)
				.condicionIvaId(1L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.observaciones("Factura de prueba")
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(2.0).build(),
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(2L).cantidad(1.0).build()
				))
				.build();

		FacturaReporteDTO creada = facturaService.crear(createDto);
		assertNotNull(creada.getId());
		assertEquals("ACTIVA", creada.getEstado());
		assertEquals(2, creada.getCantidadItems());
		assertTrue(creada.getImporteTotal() > 0);

		FacturaRequestDTO updateDto = FacturaRequestDTO.builder()
				.observaciones("Factura modificada con nuevos ítems")
				.estado("ACTIVA")
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(3L).cantidad(5.0).build()
				))
				.build();

		FacturaReporteDTO actualizada = facturaService.actualizar(creada.getId(), updateDto);
		assertEquals(creada.getId(), actualizada.getId());
		assertEquals(1, actualizada.getCantidadItems());

		FacturaRequestDTO anularDto = FacturaRequestDTO.builder()
				.estado("ANULADA")
				.observaciones("Anulada por test")
				.build();
		FacturaReporteDTO anulada = facturaService.actualizar(creada.getId(), anularDto);
		assertEquals("ANULADA", anulada.getEstado());

		facturaService.eliminar(creada.getId());

		assertThrows(RecursoNoEncontradoException.class, () -> {
			facturaService.actualizar(creada.getId(), updateDto);
		});
	}

	@Test
	void emiteCaeEnModoSimulado() {
		FacturaRequestDTO createDto = FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.clienteId(1L)
				.condicionIvaId(1L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.tipoComprobante(11)
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(1.0).build()
				))
				.build();

		FacturaReporteDTO creada = facturaService.crear(createDto);
		FacturaDetalleDTO emitida = facturaService.emitirCae(creada.getId(), 11);

		assertNotNull(emitida.cae());
		assertEquals("EMITIDA", emitida.estado());
		assertEquals("A", emitida.resultadoAfip());
		assertNotNull(emitida.caeFechaVencimiento());
		assertEquals(11, emitida.tipoComprobante());

		assertThrows(IllegalStateException.class, () -> facturaService.eliminar(creada.getId()));
	}

	@Test
	void unaFacturaConCaeNoPermiteCambiarDatosFiscalesPeroSiAnularse() {
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.condicionIvaId(3L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.tipoComprobante(11)
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(2L).cantidad(1.0).build()))
				.build());
		facturaService.emitirCae(creada.getId(), 11);

		Date haceUnAnio = new Date(System.currentTimeMillis() - 365L * 24 * 60 * 60 * 1000);
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().fechaEmision(haceUnAnio).build()));
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().puntoVentaId(2L).build()));
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().detalles(List.of(
						FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(1L).cantidad(1.0).build())).build()));

		// Con CAE tampoco se editan las observaciones ni se cambia el estado a algo que no sea anular...
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().observaciones("cambio posterior al CAE").build()));
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().estado("ACTIVA").build()));
		// ...y no se puede eliminar: solo queda la baja lógica.
		assertThrows(IllegalStateException.class, () -> facturaService.eliminar(creada.getId()));

		FacturaReporteDTO anulada = facturaService.actualizar(creada.getId(), FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.fechaEmision(new Date())
				.estado("ANULADA")
				.observaciones("Anulada por test")
				.build());
		assertEquals("ANULADA", anulada.getEstado());

		// Anulada, sigue sin poder eliminarse ni editarse.
		assertThrows(IllegalStateException.class, () -> facturaService.eliminar(creada.getId()));
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().observaciones("editada después de anular").build()));
	}

	@Test
	void rechazaEmitirCaeConFechaFueraDelRangoDeAfip() {
		Date haceDiezDias = new Date(System.currentTimeMillis() - 10L * 24 * 60 * 60 * 1000);
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.condicionIvaId(3L)
				.tipoMonedaId(1L)
				.fechaEmision(haceDiezDias)
				.tipoComprobante(11)
				.detalles(List.of(FacturaDetalleRequestDTO.builder().listaPrecioArticuloId(2L).cantidad(1.0).build()))
				.build());

		IllegalStateException error = assertThrows(IllegalStateException.class,
				() -> facturaService.emitirCae(creada.getId(), 11));
		assertTrue(error.getMessage().contains("fuera del rango"));

		facturaService.eliminar(creada.getId());
	}

	@Test
	void lasFacturasPendientesDeLaCargaInicialSePuedenEmitir() {
		List<FacturaReporteDTO> pendientes = facturaService.buscarFacturasFiltradas(null, null, "ACTIVA", null);
		assertFalse(pendientes.isEmpty());

		FacturaDetalleDTO emitida = facturaService.emitirCae(pendientes.get(0).getId(), null);
		assertNotNull(emitida.cae());
	}
}
