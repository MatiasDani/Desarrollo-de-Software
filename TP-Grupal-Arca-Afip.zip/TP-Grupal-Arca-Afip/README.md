# Facturación electrónica ARCA / AFIP

Trabajo práctico de **Desarrollo de Software** (U10). Sistema de facturación
electrónica en **Spring Boot 3.5 + Java 17** con integración real a los
web services de **ARCA (ex AFIP)** mediante **WSAA + WSFEv1**, y un frontend
web liviano incluido en el propio backend.

El circuito completo (autenticación, numeración y solicitud de CAE) está
implementado. El proyecto se entrega en **modo HOMOLOGACION** con un certificado
de prueba de AFIP incluido, de modo que se puede emitir un CAE real contra el
entorno de testing. El modo `SIMULADO` sigue disponible para desarrollar sin
conectividad.

---

## 1. Requisitos

- JDK 17 o superior.
- Maven no hace falta instalarlo: el proyecto incluye **Maven Wrapper** (`mvnw.cmd`).
- No requiere base de datos externa: usa **H2 en memoria** (consola en
  <http://localhost:8080/h2-console>, JDBC `jdbc:h2:mem:facturacion`, usuario `sa`).
- Opcional: **MySQL** con el perfil `mysql` (ver sección 2.1).

Verificar la versión de Java:

```bash
java -version
```

> En Windows, si el `java` del sistema es Java 8, no hace falta tocar nada: los
> scripts `run.cmd` / `run.ps1` buscan automáticamente un JDK 17+ instalado
> (por ejemplo en `%USERPROFILE%\.jdks`) y lo usan para Maven.
>
> Si preferís hacerlo a mano:
>
> ```powershell
> $env:JAVA_HOME='C:\ruta\a\jdk-17'
> ```

## 2. Ejecutar la aplicación

Desde la carpeta del proyecto (`TP-Grupal-Arca-Afip`), la forma más simple en Windows:

```bat
run.cmd
```

El script detecta un JDK 17+ y arranca Spring Boot. Abrir
<http://localhost:8080>.

Equivalentes:

```powershell
.\run.ps1                  # mismo arranque, desde PowerShell
.\mvnw.cmd spring-boot:run # solo si JAVA_HOME ya apunta a un JDK 17+
```

En **macOS / Linux** (con un JDK 17+ instalado):

```bash
chmod +x mvnw            # solo la primera vez, si el zip perdió el permiso
./mvnw spring-boot:run   # abre en http://localhost:8080
./mvnw spring-boot:run -Dspring-boot.run.arguments=--server.port=8081   # si el 8080 está ocupado
```

Para correr los tests:

```bat
run.cmd test
```

(en macOS / Linux: `./mvnw test`)

Para generar el JAR ejecutable:

```bat
run.cmd clean package
java -jar target/facturacion-0.0.1-SNAPSHOT.jar
```

### 2.1. Usar MySQL en lugar de H2

```powershell
docker compose up -d                                        # MySQL 8 en localhost:3306 (root/root)
.\mvnw.cmd spring-boot:run -Dspring-boot.run.profiles=mysql
```

La configuración está en `application-mysql.properties` (crea la base
`facturacion` si no existe). Sin Docker, alcanza con un MySQL local con
usuario `root` / clave `root`.

### 2.2. Datos de prueba y usuarios

`config/CargaDatos.java` carga al arrancar:

| Usuario | Clave | Nombre |
| --- | --- | --- |
| `admin` | `admin123` | Administrador Sistema |
| `mlopez` | `cajero123` | María López |
| `rgarcia` | `cajero123` | Ramiro García |

No hay pantalla de login: las altas hechas desde la web quedan auditadas a
nombre de `admin`. También se cargan 3 puntos de venta, clientes con contacto y
domicilio, 3 rubros, 4 marcas, 9 artículos y 3 listas de precios
(Minorista LP-01, Mayorista LP-02, Revendedores LP-03).

### 2.3. Colección Postman

`postman_collection.json` trae todas las rutas (facturas, reportes, catálogos,
y AFIP). Importarla en Postman; la variable `baseUrl`
apunta a `http://localhost:8080`.

---

## Modelo de dominio (TPs JPA → JPQL → Spring → ARCA)

El proyecto es incremental: conserva todo lo de los TPs anteriores y le suma la
integración con ARCA.

- **Superclases mapeadas**: `EntityId` (id) y `AuditoriaApp` (`fechaAlta`,
  `fechaBaja`, `fechaModificacion` y los `Usuario` de carga, baja y
  modificación, completados con `@PrePersist` / `@PreUpdate`).
- **Entidades**: `Usuario`, `FacturaVenta`, `FacturaVentaDetalle`,
  `PuntoVenta`, `TipoMoneda`, `Cliente` (con `Contacto` y `Domicilio`
  uno a uno), `CondicionIva`, `Articulo` (con `Rubro` y `Marca`),
  `ListaPrecio`, `ListaPrecioArticulo`, `Marca`, `Rubro`.
- **Listas de precios**: el artículo no tiene precio propio. Cada
  `ListaPrecioArticulo` es "este artículo, en esta lista, a este precio". Un
  renglón de factura apunta a un `ListaPrecioArticulo`, así que el mismo
  artículo de dos listas son dos renglones con precios distintos.
- **Renglón**: `cantidad`, `precioUnitario` (copiado de la lista al facturar),
  `porcentajeBonificacion` (0–100), `importeNeto`, `importeIva` e
  `importeSubtotal`. En Factura A/B el neto es subtotal / 1,21; en C no se
  discrimina IVA. `FacturaVenta.calcularTotal()` recalcula todo.
- **Consultas JPQL**: el listado con filtros, la paginación, los totales del
  panel (`COUNT`/`SUM`) y los reportes se resuelven con JPQL en
  `service/FacturaService.java`.
- **TP Spring**: Lombok, DTOs (records y `FacturaReporteDTO` armado con
  *constructor expression* JPQL), API REST filtrada y reportes PDF, Excel y TXT.

El `persistence.xml` y el `Main` del TP de JPA quedan reemplazados por la
configuración de Spring Boot (`application.properties`) y `CargaDatos`.

---

## 3. Modos de integración

La integración se controla con la propiedad `afip.modo` en
`src/main/resources/application.properties`:

| Modo | Descripción |
| --- | --- |
| `DESHABILITADO` | No se puede emitir CAE. La factura se guarda sin autorización. |
| `SIMULADO` | Genera un CAE ficticio, sin llamadas a AFIP. Ideal para desarrollar sin conectividad. |
| `HOMOLOGACION` | **Valor por defecto.** Emite contra el entorno de pruebas de AFIP (`wswhomo`) usando el certificado de prueba incluido. |
| `PRODUCCION` | Emite contra el entorno real. Requiere certificado de producción y CUIT habilitado. |

### 3.1. Configuración por defecto (homologación)

El repositorio incluye las credenciales de prueba y ya viene configurado:

```properties
afip.modo=HOMOLOGACION
afip.cuit=20459662732
afip.tipo-comprobante=11
afip.alicuota-iva=21

afip.certificado-path=classpath:certificados/certificado_test.crt
afip.clave-path=classpath:certificados/privada_test.key
afip.ta-path=ta_wsfe.xml
```

El certificado (`CN=aliasTest`, `CUIT 20459662732`) está emitido por
`CN=Computadores Test` de AFIP y el servicio **wsfe** ya está delegado al alias.
Con esta configuración el botón **Probar conexión** llama a `FEDummy` y la
emisión obtiene un CAE real de homologación.

> **Ticket de Acceso (TA):** WSAA rechaza pedir un TA nuevo mientras el anterior
> siga vigente. Por eso el ticket se guarda en `afip.ta-path` (por defecto
> `ta_wsfe.xml`, en la raíz del proyecto) y se reutiliza hasta 2 minutos antes de
> su vencimiento. Si el archivo existe pero venció, la aplicación pide uno nuevo
> automáticamente. No hace falta tocar el archivo: si venció, se renueva solo.

**Ticket de acceso (TA).** WSAA entrega un TA por certificado que dura hasta
12 horas, y mientras siga vigente responde `coe.alreadyAuthenticated` ("El CEE ya
posee un TA válido") si se pide otro. La app lo guarda en
`~/.facturacion-afip/ta_wsfe.xml` (en Windows, `C:\Users\<usuario>\.facturacion-afip\`),
fuera de la carpeta del proyecto, así todas las copias del TP en la misma
computadora reutilizan el mismo ticket. Si encuentra un `ta_wsfe.xml` de una
versión anterior en la carpeta desde donde se ejecuta, lo copia ahí. Si ARCA
igual rechaza el pedido (el ticket lo tiene otra computadora o alguien más con el
mismo certificado de prueba), la app lo explica: hay que copiar ese
`ta_wsfe.xml` a la ruta indicada, esperar a que venza o pasar a modo simulado.

### 3.2. Volver al modo simulado

```properties
afip.modo=SIMULADO
afip.cuit=20111111112
afip.tipo-comprobante=11
afip.alicuota-iva=21
```

En este modo el botón **Guardar y emitir CAE** y la acción **Emitir CAE** del
listado generan un CAE de 14 dígitos con vencimiento a 10 días. El detalle del
comprobante muestra el resultado `SIMULADO`.

### 3.3. Usar credenciales propias (PEM o PFX)

```properties
afip.modo=HOMOLOGACION
afip.cuit=<CUIT del emisor>

# Opción A: certificado + clave en PEM
afip.certificado-path=C:/certs/certificado_test.crt
afip.clave-path=C:/certs/privada_test.key

# Opción B: archivo PKCS#12 / PFX
# afip.pfx-path=C:/certs/facturacion.pfx
# afip.pfx-password=********

afip.wsaa-url=https://wsaahomo.afip.gov.ar/ws/services/LoginCms
afip.wsfe-url=https://wswhomo.afip.gov.ar/wsfev1/service.asmx

# Opcional: emitir el CAE automáticamente al crear la factura
afip.auto-emitir=false

# Timeout de las llamadas SOAP (ms)
afip.timeout-ms=30000

# Cliente de WSFEv1: true usa los stubs JAX-WS generados (com.ejemplo.afip.wsfe),
# false fuerza el cliente SOAP manual. Si JAX-WS no puede inicializarse, se
# degrada solo al cliente manual.
afip.usar-jaxws=true
```

> **Importante:** en un repositorio real no se deben versionar certificados,
> claves privadas ni contraseñas. Las credenciales incluidas son de
> homologación y solo sirven para probar. Usar variables de entorno o un archivo
> de configuración local fuera del control de versiones.

### 3.4. Obtener el certificado de homologación

1. Generar la clave privada y la solicitud de certificado (CSR):

   ```bash
   openssl genrsa -out privada_test.key 2048

   openssl req -new -key privada_test.key \
     -subj "/C=AR/O=TEST/CN=TEST/serialNumber=CUIT 20111111112" \
     -out solicitud_test.csr
   ```

2. Ingresar a **WSASS** (homologación) con Clave Fiscal, crear un alias,
   subir el CSR y descargar el certificado.
3. En el **Administrador de Relaciones**, delegar el servicio **wsfe** al
   alias creado.
4. Configurar las rutas del certificado y la clave en `application.properties`
   y cambiar `afip.modo` a `HOMOLOGACION`.

Los pasos completos están también explicados dentro de la vista
**Integración AFIP** de la aplicación.

---

## 4. Cómo funciona la integración

```
Frontend (app.js)
      │  POST /api/facturas/{id}/emitir
      ▼
FacturaService ──► AfipService
                        │
                        ├─ WSAA  (LoginCms) ──► Token + Sign
                        │      firma CMS PKCS#7 con BouncyCastle
                        │
                        └─ WSFEv1
                               ├─ FECompUltimoAutorizado
                               └─ FECAESolicitar ──► CAE + vencimiento
```

- **WSAA**: se firma el *Ticket de Requerimiento de Acceso* (TRA) en XML con la
  clave privada, se envía por SOAP a `LoginCms` y se obtiene un `Token`/`Sign`
  que se cachea hasta su vencimiento.
- **WSFEv1**:
  - `FECompUltimoAutorizado` obtiene el último número autorizado para el punto
    de venta y tipo de comprobante.
  - `FECAESolicitar` envía el comprobante con su número siguiente y devuelve el
    CAE o los errores/observaciones. Incluye `CondicionIVAReceptorId` a partir
    de la condición IVA de la factura (obligatorio desde la RG 5616) y el
    `MonId`/`MonCotiz` de la moneda de la factura.
  - `FEParamGetTiposMonedas` sincroniza el catálogo de monedas de AFIP y
    `FEParamGetCotizacion` resuelve la cotización de una divisa al emitir.
- El cliente de WSFEv1 usa por defecto los **stubs JAX-WS generados con XML-WS
  Tools** (paquete `com.ejemplo.afip.wsfe`, namespace `jakarta.*`). El cliente
  SOAP armado a mano queda como respaldo: si JAX-WS no puede inicializarse, el
  sistema se degrada automáticamente sin cortar el circuito de facturación.
  Se puede forzar con `afip.usar-jaxws`.
- Los rechazos de negocio de AFIP **no** se devuelven como error HTTP: la
  factura queda guardada con `resultadoAfip` y `motivoRechazo`, y el detalle lo
  muestra en la interfaz.
- Los errores de configuración o de red sí se informan como `502 Bad Gateway`.
- Antes de llamar a AFIP se valida que la fecha de emisión esté dentro de
  **N-5 / N+5 días** (regla de WSFEv1 para Concepto 1 = Productos, error
  `10016`). Si no, se responde `409 Conflict` con un mensaje claro.
- Un comprobante **con CAE** no se puede eliminar ni cambiar sus datos fiscales
  (fecha, punto de venta, cliente, condición IVA, moneda, tipo ni ítems):
  responde `409 Conflict`. Solo se permite la anulación lógica y editar
  observaciones; ante AFIP la anulación real es una Nota de Crédito. En la
  interfaz el botón de eliminar se oculta para esos comprobantes.
- Las facturas **pendientes** (`ACTIVA`) de la carga inicial se generan con la
  fecha del día, como Factura C a Consumidor Final, para poder pedirles un CAE
  real en homologación. Los CUIT de los clientes de ejemplo son ficticios: AFIP
  los rechaza (`10015`, no registrado en el padrón), así que para emitir a un
  cliente con CUIT hay que usar uno real.

### Monedas

Cada moneda maneja dos identificadores:

- **ISO 4217** (`ARS`, `USD`, `EUR`…): se usa en la vista para formatear
  importes con `Intl.NumberFormat`.
- **`MonId` de AFIP** (`PES`, `DOL`, `060`…): es el valor que exige WSFEv1.

El catálogo base (`afip/MonedasAfip.java`) replica las **49 monedas** que
devuelve `FEParamGetTiposMonedas` en homologación y se usa para sembrar la base
al arrancar. En modo `HOMOLOGACION`/`PRODUCCION` se puede refrescar contra AFIP
con `POST /api/afip/monedas/sincronizar` (botón **Sincronizar con AFIP** en la
vista Integración AFIP).

### Archivos principales del backend

| Archivo | Responsabilidad |
| --- | --- |
| `afip/AfipProperties.java` | Configuración `afip.*`. |
| `afip/AfipService.java` | Orquesta simulación, WSAA, WSFEv1 y sincronización de monedas. |
| `afip/MonedasAfip.java` | Catálogo ISO ↔ `MonId` de AFIP. |
| `afip/client/AfipWsaaClient.java` | Firma CMS y obtención/caché de Token/Sign. |
| `afip/client/AfipWsfeClient.java` | Fachada del cliente WSFEv1 (JAX-WS con respaldo SOAP). |
| `afip/client/AfipWsfeJaxwsClient.java` | Operaciones WSFEv1 usando los stubs JAX-WS generados. |
| `afip/client/AfipWsfeSoapClient.java` | Cliente SOAP manual de respaldo. |
| `afip/wsfe/**` | Stubs JAX-WS generados con XML-WS Tools desde el WSDL de WSFEv1. |
| `afip/client/AfipCredentialsLoader.java` | Carga credenciales PEM (PKCS#8/PKCS#1) y PFX/PKCS#12. |
| `service/FacturaService.java` | Alta, edición, anulación, emisión de CAE y DTOs. |
| `controller/FacturaRestController.java` | API REST de facturas. |
| `controller/CatalogoController.java` | Catálogos para los selects del frontend. |
| `controller/AfipController.java` | Estado, diagnóstico y limpieza de caché. |

---

## 5. API REST

| Método | Ruta | Descripción |
| --- | --- | --- |
| `GET` | `/api/facturas` | Lista todos los comprobantes. Filtros: `cliente` (parte del nombre o del CUIT; `consumidor` trae las facturas sin cliente), `numero` (número de comprobante que se ve en el listado), `fechaDesde`, `fechaHasta`, `estado`, `montoMinimo`. Orden opcional `orden` (ver abajo). |
| `GET` | `/api/facturas/paginado` | Listado paginado. Mismos filtros que `/api/facturas` más `pagina` (base 0, por defecto 0) y `tamanio` (por defecto 10, máximo 100) y `orden`. Primero hace un `COUNT` con los filtros y después trae solo la página pedida (`setFirstResult`/`setMaxResults`). Devuelve `contenido`, `pagina`, `tamanio`, `totalElementos`, `totalPaginas`, `primera` y `ultima`. |
| `GET` | `/api/facturas/resumen` | Totales del panel de control calculados en la base (`COUNT`/`SUM`): `totalFacturado`, `vigentes`, `conCae`, `pendientes`, `anuladas` y `ultimasFacturas` (parámetro `ultimas`, por defecto 5, máximo 20). |
| `GET` | `/api/facturas/{id}` | Detalle completo con ítems y datos fiscales. |
| `POST` | `/api/facturas` | Crea una factura. Sin renglones (`detalles` vacío o ausente) responde `400`. Sin `clienteId` se emite a Consumidor Final. |
| `PUT` | `/api/facturas/{id}` | Actualiza cabecera, ítems, estado u observaciones. Si la factura ya tiene CAE (informada a ARCA) solo admite anularla (baja lógica); cualquier otro cambio responde `409`. Dejarla sin renglones responde `400`. |
| `POST` | `/api/facturas/{id}/emitir` | Solicita el CAE (real o simulado). |
| `DELETE` | `/api/facturas/{id}` | Elimina físicamente el registro (solo si no tiene CAE; si lo tiene, `409`). |
| `GET` | `/api/facturas/{id}/pdf` | Comprobante de una factura en PDF para ver o imprimir (botón de impresora en cada fila y "Imprimir" en el detalle). |
| `GET` | `/api/facturas/reporte/pdf` | Descarga el reporte PDF. |
| `GET` | `/api/facturas/reporte/excel` | Descarga el reporte Excel. |
| `GET` | `/api/facturas/reporte/txt` | Descarga el reporte en texto separado por tabulaciones. |
| `GET` | `/api/catalogos` | Puntos de venta, clientes, condiciones IVA, monedas, artículos, listas de precios y precios por lista. |
| `GET` | `/api/catalogos/productos` | Explorador de productos paginado en la base (`COUNT` + página). Parámetros: `buscar` (palabras que deben aparecer en código, denominación, rubro, marca o lista; sin importar tildes), `listaPrecioId`, `pagina`, `tamanio` (por defecto 8). |
| `GET` | `/api/catalogos/clientes/buscar` | Pop-up "Buscar cliente" paginado en la base. Parámetros: `cuit` (con o sin guiones), `razonSocial`, `pagina`, `tamanio`. |
| `GET` | `/api/catalogos/{puntos-venta, clientes, condiciones-iva, monedas, articulos, listas-precio, lista-precio-articulos}` | Cada catálogo por separado. |
| `GET` | `/api/afip/estado` | Estado de configuración de AFIP. |
| `POST` | `/api/afip/dummy` | Diagnóstico de conexión (o simulado). |
| `GET` | `/api/afip/monedas` | Catálogo local de monedas (ISO + `MonId` de AFIP). |
| `POST` | `/api/afip/monedas/sincronizar` | Refresca el catálogo con `FEParamGetTiposMonedas`. |
| `DELETE` | `/api/afip/cache` | Invalida el Token/Sign en memoria; el TA en disco se reutiliza hasta vencer. |

Valores de `orden` (lista cerrada; otro valor responde `400`): `fecha_desc`
(por defecto: de la más reciente a la más antigua), `fecha_asc`, `numero_desc`,
`numero_asc`, `importe_desc`, `importe_asc`, `cliente_asc`, `cliente_desc`.

Ejemplo de emisión:

```bash
curl -X POST http://localhost:8080/api/facturas/1/emitir \
  -H "Content-Type: application/json" \
  -d '{"tipoComprobante":11}'
```

Ejemplo de alta (cada renglón referencia un `ListaPrecioArticulo`; el precio lo
pone el backend):

```json
{
  "puntoVentaId": 1, "clienteId": 1, "condicionIvaId": 1, "tipoMonedaId": 1,
  "tipoComprobante": 1, "fechaEmision": "2026-11-18",
  "detalles": [
    { "listaPrecioArticuloId": 2, "cantidad": 2, "porcentajeBonificacion": 10 },
    { "listaPrecioArticuloId": 11, "cantidad": 1, "descripcion": "Otra lista" }
  ]
}
```

---

## 6. Frontend

El frontend se sirve como contenido estático desde
`src/main/resources/static`. El código fuente está en **TypeScript** y se
compila a los `.js` que carga el navegador (los `.js` compilados ya vienen
incluidos, así que para correr la app no hace falta compilar nada):

- `index.html`: estructura de las vistas (panel, comprobantes, nueva factura,
  integración AFIP) y modales.
- `styles.css`: diseño **mobile-first** (teléfono primero, con puntos de quiebre
  en 640, 980, 1024, 1100 y 1200 px), tarjetas, tablas, badges y notificaciones.
- `app.ts` → `app.js`: lógica de la interfaz (módulo ES).
- `FacturaService.ts` → `FacturaService.js`: cliente HTTP tipado contra `/api`.
- `models/factura.dto.ts`: interfaces que espejan los DTOs de Java
  (`FacturaRequestDTO`, `FacturaReporteDTO`, `FacturaDetalleDTO`, `PaginaDTO`,
  `CatalogoDTO`, DTOs de AFIP).

Vistas principales:

- **Panel de control**: total facturado, comprobantes con CAE, pendientes y
  anuladas, más los últimos movimientos.
  Los totales y los últimos movimientos se piden ya calculados a
  `GET /api/facturas/resumen`: el frontend nunca descarga el listado completo.
- **Comprobantes**: búsqueda por **cliente** (pop-up "Buscar cliente" por CUIT/CUIL o razón social, desde 3 caracteres, paginado) y por **número de comprobante**, y filtros por fecha, estado y monto; listado paginado por el
  backend (selector de filas por página, "Mostrando X–Y de N" y navegación
  primera/anterior/siguiente/última); selector **Ordenar por** (fecha, número,
  importe o cliente; por defecto la más reciente primero) que se mantiene al
  filtrar y paginar; acciones de ver, editar (solo sin CAE), emitir, anular
  (también con CAE: baja lógica) y eliminar (solo sin CAE). Una factura ya
  informada a ARCA solo muestra Ver y Anular.
- **Nueva / Editar factura**: selects de catálogos; el cliente puede quedar en
  **Consumidor Final** (sin cliente) salvo en Factura A, que exige un cliente
  con CUIT. El cliente se elige con el mismo pop-up "Buscar cliente" (o se deja en
  Consumidor Final). Los productos se eligen con el **explorador de productos**:
  un pop-up con barra de búsqueda y **paginado en el backend** que filtra por
  código, denominación, rubro o marca (sin importar
  tildes; Enter elige el primer resultado) y por **lista de precios**
  (Minorista, Mayorista, Revendedores o todas; Mouse, Teclado, Cable HDMI y
  Pendrive están en las tres). Guardar sin productos, o agregar un renglón sin
  elegir producto, muestra un aviso y no guarda. Incluye resumen con IVA estimado según el tipo de
  comprobante, con **bonificación %** opcional por renglón y una columna **IVA 21%** por renglón (en Factura A y B muestra el IVA contenido en el subtotal, igual que lo calcula el backend; en Factura C dice "No discrimina"). El mismo artículo
  elegido de otra lista va en un **renglón aparte**, porque tiene otro precio;
  de la misma lista y con la misma bonificación, se suma la cantidad.
  El precio lo resuelve el backend a partir del `listaPrecioArticuloId` de cada
  renglón.
- **Integración AFIP**: estado de la configuración (incluido el cliente WSFEv1
  activo), prueba de conexión, catálogo de monedas con sincronización contra
  AFIP, limpieza del token y guía de configuración.

Diseño responsivo (mobile-first):

- En teléfonos la barra lateral se convierte en una cabecera fija con la marca y
  un **botón hamburguesa** que despliega las opciones de operaciones como menú
  emergente (se cierra al elegir una opción, al tocar fuera o con `Escape`); el
  panel muestra 2 columnas y los formularios, filtros, ítems y grillas pasan a 1
  columna. Las tablas se desplazan en horizontal sin romper el layout.
- Los modales entran como hoja inferior en el teléfono y se centran en pantallas
  grandes. Los controles tienen un alto mínimo cómodo para tocar (44 px) y los
  campos usan 16 px en móvil para evitar el zoom automático de iOS.
- A partir de 980 px aparece la barra lateral fija de escritorio (el menú pasa a
  ser una columna siempre visible y desaparece el botón hamburguesa), a 1100 px
  el formulario de factura se parte en dos columnas y a 1200 px el panel usa 4
  tarjetas.

Para modificar el frontend se edita el `.ts` y se recompila (requiere Node.js;
`tsconfig.json` usa `strict`):

```bash
cd src/main/resources/static
npx -p typescript@5 tsc -p tsconfig.json   # genera app.js, FacturaService.js y models/*.js
```

Después de recompilar conviene subir el número de `app.js?v=` en `index.html`
para que el navegador no use la versión en caché.

---

## 7. Pruebas

`src/test/java/com/ejemplo/FacturacionApplicationTests.java` cubre:

- Reporte completo y filtros por estado/monto.
- Resumen del panel (`COUNT`/`SUM` en la base) igual a los totales del listado completo.
- Paginación del listado (tamaño, metadatos, sin solapamiento entre páginas,
  acotado del tamaño y de la página pedida, filtros combinados con paginación).
- Alta, edición, anulación lógica y eliminación física.
- Emisión de CAE en modo simulado.
- Bloqueo de eliminación y de cambios fiscales en facturas con CAE (la
  anulación lógica sigue permitida).
- Rechazo de la emisión con fecha fuera del rango N±5 de AFIP.
- Emisión de una factura pendiente de la carga inicial.
- Listas de precios: al menos dos artículos en todas las listas y el mismo
  artículo de dos listas en renglones separados con su propio precio.
- Validación de renglones (sin `listaPrecioArticuloId`, id inexistente,
  cantidad ≤ 0, bonificación fuera de 0–100).
- Bonificación, neto e IVA en Factura B.
- Auditoría con usuarios (carga, modificación y baja).
- Edición de una factura sin CAE cambiando cliente e ítems.

`src/test/java/com/ejemplo/FacturaPaginacionApiTest.java` verifica el endpoint
`GET /api/facturas/paginado` con `MockMvc`: estructura de la respuesta,
metadatos, acotado del tamaño máximo y filtros aplicados junto con la paginación.

`src/test/java/com/ejemplo/afip/client/AfipWsfeSoapClientTest.java` verifica el XML
de `FECAESolicitar` del cliente SOAP: `MonId=PES`/`MonCotiz` (error 10037 de
AFIP) y `CondicionIVAReceptorId` (RG 5616) en la posición esperada por WSFEv1.
`AfipWsfeJaxwsClientTest.java` verifica el armado del `FECAERequest` de los
stubs JAX-WS y el mapeo ISO ↔ `MonId` de las 49 monedas.

Los tests de contexto fuerzan `afip.modo=SIMULADO` para no depender de AFIP ni
consumir el TA de homologación.

```bash
run.cmd test
```

---

## 8. Solución de problemas

| Síntoma | Causa probable | Solución |
| --- | --- | --- |
| `UnsupportedClassVersionError` | Maven usa Java 8. | Usar `run.cmd` / `run.ps1` (detectan JDK 17+) o configurar `JAVA_HOME` a JDK 17+. |
| `Faltan credenciales AFIP` | `afip.modo` real sin certificado. | Configurar PEM o PFX, o volver a `SIMULADO`. |
| `AFIP no autorizó el comprobante` | Datos fiscales inválidos (CUIT, tipo de comprobante, punto de venta). | Revisar el motivo en el detalle y la delegación del servicio `wsfe`. |
| Error `10037` / falta `MonId` | AFIP exige moneda y cotización en el detalle. | El cliente envía `MonId` (p. ej. `PES`) y `MonCotiz` de la moneda de la factura; no quitar esos campos. |
| Error `10242` / `10246` | Falta la condición IVA del receptor (RG 5616). | Enviar `CondicionIVAReceptorId`; para Consumidor Final es `5`. |
| `El CEE ya posee un TA valido` | Se pidió un TA nuevo antes del vencimiento. | Reutilizar `ta_wsfe.xml` (`afip.ta-path`) o esperar el vencimiento. |
| Error de conexión / timeout | Sin salida a Internet o endpoint incorrecto. | Verificar `afip.wsaa-url`, `afip.wsfe-url` y `afip.timeout-ms`. |
| El CAE tarda o falla tras reiniciar | Token cacheado vencido. | Usar **Limpiar token WSAA** en la vista Integración AFIP. |

---

## 9. Notas de seguridad

- Los datos de AFIP se configuran por propiedades; para producción se
  recomienda externalizarlos con variables de entorno.
- No versionar certificados, claves privadas ni contraseñas.
- La anulación desde la interfaz es **lógica** (estado `ANULADA`). Ante AFIP,
  un comprobante autorizado se anula fiscalmente emitiendo una **Nota de
  Crédito**.
