package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "TiposMoneda")
public class TipoMoneda extends AuditoriaApp {
    @Column(nullable = false)
    private String codigoAfip;

    @Column(nullable = false)
    private String denominacion;

    @Column(nullable = false)
    private String simbolo;

    public TipoMoneda(){}


    public TipoMoneda(String codigoAfip, String denominacion, String simbolo, Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        super(fechaAlta, fechaModificacion, usuarioCarga, usuarioModificacion);
        this.codigoAfip = codigoAfip;
        this.denominacion = denominacion;
        this.simbolo = simbolo;
    }

    public String getCodigoAfip() {
        return codigoAfip;
    }

    public String getDenominacion() {
        return denominacion;
    }

    public String getSimbolo() {
        return simbolo;
    }

    public void setCodigoAfip(String codigoAfip) {
        this.codigoAfip = codigoAfip;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }

    public void setSimbolo(String simbolo) {
        this.simbolo = simbolo;
    }
}
