package org.example.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Articulos")
public class Articulo extends AuditoriaApp {
    @ManyToOne
    @JoinColumn(name = "rubroID")
    private Rubro rubro;

    @Column(nullable = false)
    private String codigo;

    @Column(nullable = false)
    private String denominacion;

    @ManyToOne
    @JoinColumn(name = "marcaID")
    private Marca marca;

    public Articulo() {}

    public Articulo(String codigo, String denominacion, Rubro rubro, Marca marca, Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        super(fechaAlta, fechaModificacion, usuarioCarga, usuarioModificacion);
        this.codigo = codigo;
        this.denominacion = denominacion;
        this.rubro = rubro;
        this.marca = marca;
    }

    public Rubro getRubro() { return rubro; }
    public void setRubro(Rubro rubro) { this.rubro = rubro; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getDenominacion() { return denominacion; }
    public void setDenominacion(String denominacion) { this.denominacion = denominacion; }

    public Marca getMarca() { return marca; }
    public void setMarca(Marca marca) { this.marca = marca; }
}
