package org.example.entities;

import jakarta.persistence.*;

import java.util.Date;

@MappedSuperclass
public abstract class AuditoriaApp extends EntityId {
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaAlta;

    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaBaja;

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaModificacion;

    @ManyToOne
    @JoinColumn(name = "usuarioCargaID", nullable = false)
    protected Usuario usuarioCarga;

    @ManyToOne
    @JoinColumn(name = "usuarioBajaID")
    protected Usuario usuarioBaja;

    @ManyToOne
    @JoinColumn(name = "usuarioModificacionID", nullable = false)
    protected Usuario usuarioModificacion;

    public AuditoriaApp() {}

    public AuditoriaApp(Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        this.fechaAlta = fechaAlta;
        this.fechaModificacion = fechaModificacion;
        this.usuarioCarga = usuarioCarga;
        this.usuarioModificacion = usuarioModificacion;
    }

    public Date getFechaAlta() { return fechaAlta; }
    public void setFechaAlta(Date fechaAlta) { this.fechaAlta = fechaAlta; }

    public Date getFechaBaja() { return fechaBaja; }
    public void setFechaBaja(Date fechaBaja) { this.fechaBaja = fechaBaja; }

    public Date getFechaModificacion() { return fechaModificacion; }
    public void setFechaModificacion(Date fechaModificacion) { this.fechaModificacion = fechaModificacion; }

    public Usuario getUsuarioCarga() { return usuarioCarga; }
    public void setUsuarioCarga(Usuario usuarioCarga) { this.usuarioCarga = usuarioCarga; }

    public Usuario getUsuarioBaja() { return usuarioBaja; }
    public void setUsuarioBaja(Usuario usuarioBaja) { this.usuarioBaja = usuarioBaja; }

    public Usuario getUsuarioModificacion() { return usuarioModificacion; }
    public void setUsuarioModificacion(Usuario usuarioModificacion) { this.usuarioModificacion = usuarioModificacion; }
}
