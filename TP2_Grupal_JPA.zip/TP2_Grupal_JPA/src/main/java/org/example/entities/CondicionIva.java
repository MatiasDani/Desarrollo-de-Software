package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "CondicionesIVA")
public class CondicionIva extends AuditoriaApp {

    @Column(nullable = false)
    private int codigoAfip;
    @Column(nullable = false)
    private String denominacion;

    public CondicionIva() {}

    public CondicionIva(String denominacion, int codigoAfip,Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        super(fechaAlta, fechaModificacion, usuarioCarga, usuarioModificacion);
        this.codigoAfip = codigoAfip;
        this.denominacion = denominacion;
    }


    public int getCodigoAfip() {
        return codigoAfip;
    }

    public String getDenominacion() {
        return denominacion;
    }

    public void setCodigoAfip(int codigoAfip) {
        this.codigoAfip = codigoAfip;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }
}