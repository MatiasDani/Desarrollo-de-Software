package org.example.entities;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "FacturasVenta")
public class FacturaVenta extends AuditoriaApp {
    private Long numero;

    @Column(nullable = false)
    private Date fechaEmision;

    @ManyToOne
    @JoinColumn(name = "clienteID", nullable = true)
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "condicionIvaID", nullable = false)
    private CondicionIva condicionIva;

    @ManyToOne
    @JoinColumn(name = "tipoMonedaID", nullable = false)
    private TipoMoneda tipoMoneda;

    @ManyToOne
    @JoinColumn(name = "puntoVentaID",nullable = false)
    private PuntoVenta puntoVenta;
    private double importeCobrado;
    private double importeSaldo;

    @Column(nullable = false)
    private double importeTotal;
    private String cae;

    @Temporal(TemporalType.DATE)
    private Date caeFechaVencimiento;
    private String resultadoAfip;
    private String motivoRechazo;

    @Column(nullable = false)
    private String estado;

    @Temporal(TemporalType.DATE)
    private Date fechaAnulacion;
    private String observaciones;

    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FacturaVentaDetalle> detalles = new ArrayList<>();;

    public FacturaVenta() {}

    public FacturaVenta(Long numero, Date fechaEmision, CondicionIva condicionIva, TipoMoneda tipoMoneda, PuntoVenta puntoVenta, double importeCobrado, double importeSaldo, double importeTotal, String estado, Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        super(fechaAlta, fechaModificacion, usuarioCarga, usuarioModificacion);
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.condicionIva = condicionIva;
        this.tipoMoneda = tipoMoneda;
        this.puntoVenta = puntoVenta;
        this.importeCobrado = importeCobrado;
        this.importeSaldo = importeSaldo;
        this.importeTotal = importeTotal;
        this.estado = estado;
    }

    public void addCliente(Cliente cliente){
        this.cliente = cliente;
    }

    public void addDetalle(FacturaVentaDetalle detalle) {
        if (this.detalles == null) {
            this.detalles = new ArrayList<>();
        }
        this.detalles.add(detalle);
        detalle.setFactura(this); // Mantener la relación bidireccional
    }

    public Long getNumero() { return numero; }
    public void setNumero(Long numero) { this.numero = numero; }

    public Date getFechaEmision() { return fechaEmision; }
    public void setFechaEmision(Date fechaEmision) { this.fechaEmision = fechaEmision; }

    public PuntoVenta getPuntoVenta() { return puntoVenta; }
    public void setPuntoVenta(PuntoVenta puntoVenta) { this.puntoVenta = puntoVenta; }

    public double getImporteCobrado() { return importeCobrado; }
    public void setImporteCobrado(double importeCobrado) { this.importeCobrado = importeCobrado; }

    public double getImporteSaldo() { return importeSaldo; }
    public void setImporteSaldo(double importeSaldo) { this.importeSaldo = importeSaldo; }

    public double getImporteTotal() { return importeTotal; }
    public void setImporteTotal(double importeTotal) { this.importeTotal = importeTotal; }

    public String getCae() { return cae; }
    public void setCae(String cae) { this.cae = cae; }

    public Date getCaeFechaVencimiento() { return caeFechaVencimiento; }
    public void setCaeFechaVencimiento(Date caeFechaVencimiento) { this.caeFechaVencimiento = caeFechaVencimiento; }

    public String getResultadoAfip() { return resultadoAfip; }
    public void setResultadoAfip(String resultadoAfip) { this.resultadoAfip = resultadoAfip; }

    public String getMotivoRechazo() { return motivoRechazo; }
    public void setMotivoRechazo(String motivoRechazo) { this.motivoRechazo = motivoRechazo; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Date getFechaAnulacion() { return fechaAnulacion; }
    public void setFechaAnulacion(Date fechaAnulacion) { this.fechaAnulacion = fechaAnulacion; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public List<FacturaVentaDetalle> getDetalles() { return detalles; }
    public void setDetalles(List<FacturaVentaDetalle> detalles) { this.detalles = detalles; }
}
