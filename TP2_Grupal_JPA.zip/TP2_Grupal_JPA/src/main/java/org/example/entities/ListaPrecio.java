package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "ListasPrecio")
public class ListaPrecio extends AuditoriaApp {

    @Column(nullable = false)
    private String codigo;

    @Column(nullable = false)
    private String denominacion;

    public ListaPrecio() {}

    public ListaPrecio(String codigo, String denominacion, Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        super(fechaAlta, fechaModificacion, usuarioCarga, usuarioModificacion);
        this.codigo = codigo;
        this.denominacion = denominacion;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getDenominacion() { return denominacion; }
    public void setDenominacion(String denominacion) { this.denominacion = denominacion; }
}
