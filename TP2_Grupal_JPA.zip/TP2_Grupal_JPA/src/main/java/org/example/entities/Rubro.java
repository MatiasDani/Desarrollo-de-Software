package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "Rubros")
public class Rubro extends AuditoriaApp {
    @Column(nullable = false)
    private String denominacion;

    @Column(nullable = false)
    private Integer codigo;

    public Rubro() {}

    public Rubro(String denominacion, Integer codigo, Date fechaAlta, Date fechaModificacion, Usuario usuarioCarga, Usuario usuarioModificacion) {
        super(fechaAlta, fechaModificacion, usuarioCarga, usuarioModificacion);
        this.denominacion = denominacion;
        this.codigo = codigo;
    }

    public String getDenominacion() { return denominacion; }
    public void setDenominacion(String denominacion) { this.denominacion = denominacion; }

    public Integer getCodigo() { return codigo; }
    public void setCodigo(Integer codigo) { this.codigo = codigo; }
}

