package org.example;


import org.example.entities.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.Date;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            Date fechaActual = new Date();

            // =========================================================================
            // A. Instanciación y Persistencia de Usuario
            // =========================================================================
            Usuario admin = new Usuario("admin", "123456", "Luka", "Garro");
            em.persist(admin);

            // =========================================================================
            // B. Instanciación de Entidades Básicas usando Constructores
            // =========================================================================
            Rubro rubroElectrónica = new Rubro("Electrónica", 101, fechaActual, fechaActual, admin, admin);
            em.persist(rubroElectrónica);

            Marca marcaSony = new Marca("Sony", 501, fechaActual, fechaActual, admin, admin);
            em.persist(marcaSony);

            Articulo tv = new Articulo("ART-001", "Smart TV 55 Pulgadas", rubroElectrónica, marcaSony, fechaActual, fechaActual, admin, admin);
            em.persist(tv);

            ListaPrecio listaPrincipal = new ListaPrecio("LP-01", "Lista General de Contado", fechaActual, fechaActual, admin, admin);
            em.persist(listaPrincipal);

            ListaPrecioArticulo precioTv = new ListaPrecioArticulo(listaPrincipal, 750000.0, tv, fechaActual, fechaActual, admin, admin);
            em.persist(precioTv);

            PuntoVenta pvCentral = new PuntoVenta(1, "Sucursal Central", "Facturación Electrónica", "Av. San Martín 1050", fechaActual, fechaActual, admin, admin);
            em.persist(pvCentral);

            TipoMoneda monedaPeso = new TipoMoneda("ARS", "Peso Argentino", "$", fechaActual, fechaActual, admin, admin);
            em.persist(monedaPeso);

            TipoMoneda monedaDolar = new TipoMoneda("USD", "Dólar Estadounidense", "US$", fechaActual, fechaActual, admin, admin);
            em.persist(monedaDolar);

            CondicionIva ivaRI = new CondicionIva("Responsable Inscripto", 21, fechaActual, fechaActual, admin, admin);
            em.persist(ivaRI);


            CondicionIva ivaMonotributo = new CondicionIva("Monotributo", 0, fechaActual, fechaActual, admin, admin);
            em.persist(ivaMonotributo);


            CondicionIva ivaExento = new CondicionIva("Exento", 0, fechaActual, fechaActual, admin, admin);
            em.persist(ivaExento);

            CondicionIva ivaConsumidorFinal = new CondicionIva("Consumidor Final", 21, fechaActual, fechaActual, admin, admin);
            em.persist(ivaConsumidorFinal);

            // =========================================================================
            // C. Instanciación de Contacto, Domicilio y Cliente
            // =========================================================================
            Contacto contactoCliente = new Contacto("cliente@correo.com", "2614000000", "2615555555");
            em.persist(contactoCliente);

            Domicilio domicilioCliente = new Domicilio("Las Heras", "450");
            em.persist(domicilioCliente);

            Cliente cliente1 = new Cliente("20-38123456-9", "Juan Pérez", contactoCliente, domicilioCliente, fechaActual, fechaActual, admin, admin);
            em.persist(cliente1);

            // =========================================================================
            // D. Instanciación de Factura de Venta y sus Detalles
            // =========================================================================
            FacturaVenta factura = new FacturaVenta(1L, fechaActual, ivaRI, monedaPeso, pvCentral, 0.0, 1500000.0, 1500000.0, "EMITIDA", fechaActual, fechaActual, admin, admin);

            //Vincular Cliente
            factura.addCliente(cliente1);

            // Detalles de la factura
            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle(precioTv, "Smart TV 55 Pulgadas (Unidad 1)", 1.0, 750000.0, 750000.0);
            FacturaVentaDetalle detalle2 = new FacturaVentaDetalle(precioTv, "Smart TV 55 Pulgadas (Unidad 2)", 1.0, 750000.0, 750000.0);

            // Vinculación
            factura.addDetalle(detalle1);
            factura.addDetalle(detalle2);

            em.persist(factura);

            // Guardar cambios en base de datos
            em.getTransaction().commit();
            System.out.println("\n>>> Datos iniciales guardados con éxito mediante JPA/Hibernate.");

            // =========================================================================
            // E. Consulta y Lectura (Verificación)
            // =========================================================================
            em.clear(); // Limpiamos la memoria caché del EntityManager para forzar consulta SQL

            List<FacturaVenta> facturasBD = em.createQuery("SELECT f FROM FacturaVenta f", FacturaVenta.class)
                    .getResultList();

            System.out.println("\n--- LISTADO DE FACTURAS INGRESADAS ---");
            for (FacturaVenta f : facturasBD) {
                System.out.println("Factura N°: " + f.getNumero() + " | Estado: " + f.getEstado() + " | Total: $" + f.getImporteTotal());
                System.out.println("Cargada por: " + f.getUsuarioCarga().getNombre() + " " + f.getUsuarioCarga().getApellido());
                System.out.println("Detalles:");
                for (FacturaVentaDetalle d : f.getDetalles()) {
                    System.out.println("  - " + d.getDescripcion() + " x" + d.getCantidad() + " @ $" + d.getPrecioUnitario() + " (Subtotal: $" + d.getImporteSubtotal() + ")");
                }
            }

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}