@echo off
rem Arranca el proyecto con JDK 17+ y el Maven Wrapper.
rem Uso: run.cmd [goal...]   (sin argumentos ejecuta spring-boot:run)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1" %*
