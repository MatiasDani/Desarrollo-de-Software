﻿<#
    Ejecuta el proyecto con un JDK 17 o superior, sin necesidad de configurar
    JAVA_HOME ni Maven a mano.

    Uso:
        .\run.ps1                  # arranca la aplicación en http://localhost:8080
        .\run.ps1 test             # ejecuta los tests
        .\run.ps1 clean package    # genera el JAR

    En Windows también se puede usar run.cmd, que evita problemas de
    ExecutionPolicy.
#>
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$MavenArgs
)

$ErrorActionPreference = 'Stop'

function Get-JavaMajor {
    param([string]$JavaExe)
    $anterior = $ErrorActionPreference
    # java -version escribe en stderr; con ErrorActionPreference=Stop eso
    # cortaría la detección, así que lo aislamos.
    $ErrorActionPreference = 'Continue'
    try {
        $first = (& $JavaExe -version 2>&1 | Select-Object -First 1) -as [string]
    } catch {
        return 0
    } finally {
        $ErrorActionPreference = $anterior
    }
    if ($first -match 'version "(\d+)(?:\.(\d+))?') {
        if ($matches[1] -eq '1') { return [int]$matches[2] }
        return [int]$matches[1]
    }
    return 0
}

function Find-Jdk {
    $candidates = New-Object System.Collections.Generic.List[string]

    if ($env:JAVA_HOME) { $candidates.Add($env:JAVA_HOME) }

    $java = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($java) {
        # javapath suele ser un acceso directo: agregamos la raíz del runtime.
        $candidates.Add((Split-Path (Split-Path $java.Source -Parent) -Parent))
    }

    $roots = @(
        (Join-Path $env:USERPROFILE '.jdks'),
        'C:\Program Files\Java',
        'C:\Program Files\Eclipse Adoptium',
        'C:\Program Files\Microsoft',
        'C:\Program Files\Amazon Corretto',
        'C:\Program Files\Zulu'
    )

    foreach ($root in $roots) {
        if (Test-Path $root) {
            Get-ChildItem $root -Directory -ErrorAction SilentlyContinue |
                ForEach-Object { $candidates.Add($_.FullName) }
        }
    }

    $best = $null
    $bestMajor = [int]::MaxValue

    # Se elige el menor JDK que cumpla con Java 17+, así se evitan saltos
    # innecesarios a versiones muy nuevas.
    foreach ($jdkHome in ($candidates | Select-Object -Unique)) {
        $exe = Join-Path $jdkHome 'bin\java.exe'
        if (-not (Test-Path $exe)) { continue }
        $major = Get-JavaMajor $exe
        if ($major -ge 17 -and $major -lt $bestMajor) {
            $best = $jdkHome
            $bestMajor = $major
        }
    }

    return $best
}

$jdk = Find-Jdk
if (-not $jdk) {
    Write-Host 'No se encontró un JDK 17 o superior.' -ForegroundColor Red
    Write-Host 'Instalá un JDK moderno o definí JAVA_HOME antes de ejecutar.' -ForegroundColor Red
    exit 1
}

$env:JAVA_HOME = $jdk
$env:Path = (Join-Path $jdk 'bin') + ';' + $env:Path
Write-Host "Usando JDK: $jdk" -ForegroundColor DarkGray

if ($MavenArgs.Count -eq 0) {
    $MavenArgs = @('spring-boot:run')
}

& (Join-Path $PSScriptRoot 'mvnw.cmd') @MavenArgs
exit $LASTEXITCODE
