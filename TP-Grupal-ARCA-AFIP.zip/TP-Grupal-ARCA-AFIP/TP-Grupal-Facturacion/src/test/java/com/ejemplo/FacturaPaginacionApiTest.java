package com.ejemplo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Verifica el endpoint paginado del listado de comprobantes
 * ({@code GET /api/facturas/paginado}).
 */
@SpringBootTest(properties = "afip.modo=SIMULADO")
@AutoConfigureMockMvc
class FacturaPaginacionApiTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void devuelveLaPrimeraPaginaConMetadatos() throws Exception {
        mockMvc.perform(get("/api/facturas/paginado")
                        .param("pagina", "0")
                        .param("tamanio", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido.length()").value(5))
                .andExpect(jsonPath("$.pagina").value(0))
                .andExpect(jsonPath("$.tamanio").value(5))
                .andExpect(jsonPath("$.primera").value(true))
                .andExpect(jsonPath("$.ultima").value(false))
                .andExpect(jsonPath("$.totalElementos").isNumber())
                .andExpect(jsonPath("$.totalPaginas").isNumber());
    }

    @Test
    void acotaElTamanioMaximoDePagina() throws Exception {
        mockMvc.perform(get("/api/facturas/paginado").param("tamanio", "500"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tamanio").value(100));
    }

    @Test
    void aplicaLosFiltrosJuntoConLaPaginacion() throws Exception {
        mockMvc.perform(get("/api/facturas/paginado")
                        .param("estado", "ANULADA")
                        .param("tamanio", "100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contenido[?(@.estado != 'ANULADA')]").isEmpty());
    }
}
