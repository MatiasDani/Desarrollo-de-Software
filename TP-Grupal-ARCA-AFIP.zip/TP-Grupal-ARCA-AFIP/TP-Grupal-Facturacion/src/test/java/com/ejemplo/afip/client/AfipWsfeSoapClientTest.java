package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.model.AfipAuth;
import com.ejemplo.afip.model.ComprobanteAfip;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests del cliente SOAP manual (implementación de respaldo).
 */
class AfipWsfeSoapClientTest {

    private final AfipWsfeSoapClient client = new AfipWsfeSoapClient(new AfipProperties());

    @Test
    void incluyeCondicionIvaReceptorEnElXmlDeCae() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                1, 1, 42, LocalDate.of(2026, 1, 15), 121.0,
                80, 20111111112L, "ARS", 1.0, 21.0, true, 1);

        String xml = client.construirEnvelopeCae(
                new AfipAuth("token", "sign", 20111111112L, LocalDateTime.now()),
                comprobante);

        assertTrue(xml.contains("<ar:CondicionIVAReceptorId>1</ar:CondicionIVAReceptorId>"),
                "El XML debe incluir la condición IVA del receptor (RG 5616)");
        assertTrue(xml.indexOf("<ar:CondicionIVAReceptorId>") < xml.indexOf("<ar:Iva>"),
                "CondicionIVAReceptorId debe ir antes del bloque Iva");
    }

    @Test
    void enviaMonIdPesYMonCotizCuandoLaMonedaEsArs() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                1, 11, 7, LocalDate.of(2026, 1, 15), 100.0,
                99, 0L, "ARS", 1.0, 21.0, false, 5);

        String xml = client.construirEnvelopeCae(
                new AfipAuth("token", "sign", 20459662732L, LocalDateTime.now()),
                comprobante);

        assertTrue(xml.contains("<ar:MonId>PES</ar:MonId>"),
                "ARS debe mapearse al código AFIP PES (error 10037 si falta MonId)");
        assertTrue(xml.contains("<ar:MonCotiz>1.00</ar:MonCotiz>"),
                "Debe informarse la cotización de la moneda");
        assertTrue(xml.indexOf("<ar:MonId>") < xml.indexOf("<ar:CondicionIVAReceptorId>"),
                "MonId/MonCotiz deben ir antes de CondicionIVAReceptorId");
    }

    @Test
    void traduceMonedasExtranjerasAlCodigoAfip() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                1, 1, 7, LocalDate.of(2026, 1, 15), 100.0,
                99, 0L, "USD", 1450.0, 21.0, true, 5);

        String xml = client.construirEnvelopeCae(
                new AfipAuth("token", "sign", 20459662732L, LocalDateTime.now()),
                comprobante);

        assertTrue(xml.contains("<ar:MonId>DOL</ar:MonId>"),
                "USD debe mapearse al código AFIP DOL");
        assertTrue(xml.contains("<ar:MonCotiz>1450.00</ar:MonCotiz>"));
    }

    @Test
    void omiteCondicionIvaReceptorCuandoNoEstaInformada() {
        ComprobanteAfip comprobante = new ComprobanteAfip(
                1, 11, 7, LocalDate.of(2026, 1, 15), 100.0,
                99, 0L, "ARS", 1.0, 21.0, false, 0);

        String xml = client.construirEnvelopeCae(
                new AfipAuth("token", "sign", 20111111112L, LocalDateTime.now()),
                comprobante);

        assertFalse(xml.contains("CondicionIVAReceptorId"));
    }
}
