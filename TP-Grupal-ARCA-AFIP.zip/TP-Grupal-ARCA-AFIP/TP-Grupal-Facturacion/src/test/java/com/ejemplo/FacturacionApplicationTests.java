package com.ejemplo;

import com.ejemplo.dto.FacturaDetalleDTO;
import com.ejemplo.dto.FacturaDetalleRequestDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.exception.RecursoNoEncontradoException;
import com.ejemplo.service.FacturaService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(properties = "afip.modo=SIMULADO")
class FacturacionApplicationTests {

	@Autowired
	private FacturaService facturaService;

	@Test
	void elReporteTraeTodasLasFacturas() {
		List<FacturaReporteDTO> reporte = facturaService.obtenerReporte();
		assertTrue(reporte.size() >= 8);
	}

	@Test
	void filtraPorEstado() {
		List<FacturaReporteDTO> anuladas = facturaService.buscarFacturasFiltradas(null, null, "ANULADA", null);
		assertTrue(anuladas.size() >= 2);
	}

	@Test
	void filtraPorMontoMinimo() {
		List<FacturaReporteDTO> resultado = facturaService.buscarFacturasFiltradas(null, null, null, 1000000.0);
		for (FacturaReporteDTO f : resultado) {
			assertTrue(f.getImporteTotal() >= 1000000.0);
		}
	}

	@Test
	void paginaElListadoDeFacturasSinSolapamiento() {
		PaginaDTO<FacturaReporteDTO> primera = facturaService.buscarFacturasPaginadas(null, null, null, null, 0, 5);

		assertEquals(5, primera.contenido().size());
		assertEquals(0, primera.pagina());
		assertEquals(5, primera.tamanio());
		assertTrue(primera.totalElementos() >= 8);
		assertTrue(primera.totalPaginas() >= 2);
		assertTrue(primera.primera());
		assertFalse(primera.ultima());

		PaginaDTO<FacturaReporteDTO> segunda = facturaService.buscarFacturasPaginadas(null, null, null, null, 1, 5);
		assertEquals(1, segunda.pagina());
		assertFalse(segunda.primera());

		Set<Long> idsPrimera = primera.contenido().stream().map(FacturaReporteDTO::getId).collect(Collectors.toSet());
		Set<Long> idsSegunda = segunda.contenido().stream().map(FacturaReporteDTO::getId).collect(Collectors.toSet());
		assertTrue(Collections.disjoint(idsPrimera, idsSegunda), "Las páginas no deben repetir comprobantes");
	}

	@Test
	void acotaLaPaginaPedidaYElTamanio() {
		// Un tamaño mayor al máximo permitido se acota a 100.
		PaginaDTO<FacturaReporteDTO> grande = facturaService.buscarFacturasPaginadas(null, null, null, null, 0, 500);
		assertEquals(100, grande.tamanio());

		// Una página fuera de rango devuelve la última disponible, no una vacía.
		PaginaDTO<FacturaReporteDTO> fueraDeRango = facturaService.buscarFacturasPaginadas(null, null, null, null, 9999, 5);
		assertTrue(fueraDeRango.ultima());
		assertEquals(fueraDeRango.totalPaginas() - 1, fueraDeRango.pagina());
		assertFalse(fueraDeRango.contenido().isEmpty());
	}

	@Test
	void laPaginacionRespetaLosFiltros() {
		PaginaDTO<FacturaReporteDTO> anuladas = facturaService.buscarFacturasPaginadas(null, null, "ANULADA", null, 0, 100);
		assertTrue(anuladas.totalElementos() >= 2);
		for (FacturaReporteDTO f : anuladas.contenido()) {
			assertEquals("ANULADA", f.getEstado());
		}
	}

	@Test
	void crearActualizarYEliminarFactura() {
		// 1. Crear factura (POST)
		FacturaRequestDTO createDto = FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.clienteId(1L)
				.condicionIvaId(1L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.observaciones("Factura de prueba")
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().articuloId(1L).cantidad(2.0).build(),
						FacturaDetalleRequestDTO.builder().articuloId(2L).cantidad(1.0).build()
				))
				.build();

		FacturaReporteDTO creada = facturaService.crear(createDto);
		assertNotNull(creada.getId());
		assertEquals("ACTIVA", creada.getEstado());
		assertEquals(2, creada.getCantidadItems());
		assertTrue(creada.getImporteTotal() > 0);

		// 2. Actualizar cabecera e ítems (PUT)
		FacturaRequestDTO updateDto = FacturaRequestDTO.builder()
				.observaciones("Factura modificada con nuevos ítems")
				.estado("ACTIVA")
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().articuloId(3L).cantidad(5.0).build()
				))
				.build();

		FacturaReporteDTO actualizada = facturaService.actualizar(creada.getId(), updateDto);
		assertEquals(creada.getId(), actualizada.getId());
		assertEquals(1, actualizada.getCantidadItems());

		// 3. Anular factura (Anulación lógica)
		FacturaRequestDTO anularDto = FacturaRequestDTO.builder()
				.estado("ANULADA")
				.observaciones("Anulada por test")
				.build();
		FacturaReporteDTO anulada = facturaService.actualizar(creada.getId(), anularDto);
		assertEquals("ANULADA", anulada.getEstado());

		// 4. Eliminar factura (Eliminación física)
		facturaService.eliminar(creada.getId());

		// 5. Verificar que ya no existe (404)
		assertThrows(RecursoNoEncontradoException.class, () -> {
			facturaService.actualizar(creada.getId(), updateDto);
		});
	}

	@Test
	void emiteCaeEnModoSimulado() {
		FacturaRequestDTO createDto = FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.clienteId(1L)
				.condicionIvaId(1L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.tipoComprobante(11)
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().articuloId(1L).cantidad(1.0).build()
				))
				.build();

		FacturaReporteDTO creada = facturaService.crear(createDto);
		FacturaDetalleDTO emitida = facturaService.emitirCae(creada.getId(), 11);

		assertNotNull(emitida.cae());
		assertEquals("EMITIDA", emitida.estado());
		assertEquals("A", emitida.resultadoAfip());
		assertNotNull(emitida.caeFechaVencimiento());
		assertEquals(11, emitida.tipoComprobante());

		// Un comprobante con CAE no se puede eliminar físicamente.
		assertThrows(IllegalStateException.class, () -> facturaService.eliminar(creada.getId()));
	}

	@Test
	void unaFacturaConCaeNoPermiteCambiarDatosFiscalesPeroSiAnularse() {
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.condicionIvaId(3L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.tipoComprobante(11)
				.detalles(List.of(FacturaDetalleRequestDTO.builder().articuloId(2L).cantidad(1.0).build()))
				.build());
		facturaService.emitirCae(creada.getId(), 11);

		Date haceUnAnio = new Date(System.currentTimeMillis() - 365L * 24 * 60 * 60 * 1000);
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().fechaEmision(haceUnAnio).build()));
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().puntoVentaId(2L).build()));
		assertThrows(IllegalStateException.class, () -> facturaService.actualizar(creada.getId(),
				FacturaRequestDTO.builder().detalles(List.of(
						FacturaDetalleRequestDTO.builder().articuloId(1L).cantidad(1.0).build())).build()));

		// Reenviar los mismos valores no es un cambio, y la anulación lógica sigue permitida.
		FacturaReporteDTO anulada = facturaService.actualizar(creada.getId(), FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.fechaEmision(new Date())
				.estado("ANULADA")
				.observaciones("Anulada por test")
				.build());
		assertEquals("ANULADA", anulada.getEstado());
	}

	@Test
	void rechazaEmitirCaeConFechaFueraDelRangoDeAfip() {
		Date haceDiezDias = new Date(System.currentTimeMillis() - 10L * 24 * 60 * 60 * 1000);
		FacturaReporteDTO creada = facturaService.crear(FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.condicionIvaId(3L)
				.tipoMonedaId(1L)
				.fechaEmision(haceDiezDias)
				.tipoComprobante(11)
				.detalles(List.of(FacturaDetalleRequestDTO.builder().articuloId(2L).cantidad(1.0).build()))
				.build());

		IllegalStateException error = assertThrows(IllegalStateException.class,
				() -> facturaService.emitirCae(creada.getId(), 11));
		assertTrue(error.getMessage().contains("fuera del rango"));

		facturaService.eliminar(creada.getId());
	}

	@Test
	void lasFacturasPendientesDeLaCargaInicialSePuedenEmitir() {
		List<FacturaReporteDTO> pendientes = facturaService.buscarFacturasFiltradas(null, null, "ACTIVA", null);
		assertFalse(pendientes.isEmpty());

		FacturaDetalleDTO emitida = facturaService.emitirCae(pendientes.get(0).getId(), null);
		assertNotNull(emitida.cae());
	}
}
