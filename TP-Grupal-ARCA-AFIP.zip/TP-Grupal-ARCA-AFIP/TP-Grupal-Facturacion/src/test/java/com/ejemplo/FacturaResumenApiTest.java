package com.ejemplo;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Verifica el resumen del panel de control ({@code GET /api/facturas/resumen}).
 *
 * <p>Los totales se calculan en la base de datos para no tener que traer todo el
 * listado al navegador. El test los contrasta contra el listado completo, de
 * modo que no depende de la cantidad exacta de datos de ejemplo.</p>
 */
@SpringBootTest(properties = "afip.modo=SIMULADO")
@AutoConfigureMockMvc
class FacturaResumenApiTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private JsonNode getJson(String url) throws Exception {
        String body = mockMvc.perform(get(url))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return objectMapper.readTree(body);
    }

    @Test
    void losTotalesCoincidenConElListadoCompleto() throws Exception {
        JsonNode todas = getJson("/api/facturas");
        assertThat(todas.size()).as("los datos de ejemplo deben tener facturas").isGreaterThan(5);

        long vigentes = 0, anuladas = 0, conCae = 0, pendientes = 0;
        double importe = 0;
        for (JsonNode f : todas) {
            boolean anulada = "ANULADA".equals(f.path("estado").asText());
            boolean tieneCae = !f.path("cae").isNull() && !f.path("cae").asText("").isEmpty();
            if (anulada) {
                anuladas++;
            } else {
                vigentes++;
                importe += f.path("importeTotal").asDouble();
                if (tieneCae) conCae++; else pendientes++;
            }
        }

        JsonNode resumen = getJson("/api/facturas/resumen");

        assertThat(resumen.path("vigentes").asLong()).isEqualTo(vigentes);
        assertThat(resumen.path("anuladas").asLong()).isEqualTo(anuladas);
        assertThat(resumen.path("conCae").asLong()).isEqualTo(conCae);
        assertThat(resumen.path("pendientes").asLong()).isEqualTo(pendientes);
        assertThat(resumen.path("importeVigente").asDouble()).isCloseTo(importe, within(0.01));
    }

    @Test
    void devuelveSoloLasUltimasCincoFacturasOrdenadasDeMasNuevaAMasVieja() throws Exception {
        JsonNode todas = getJson("/api/facturas");
        List<Long> ids = new ArrayList<>();
        todas.forEach(f -> ids.add(f.path("id").asLong()));
        ids.sort((a, b) -> Long.compare(b, a));

        JsonNode ultimas = getJson("/api/facturas/resumen").path("ultimas");

        assertThat(ultimas.size()).isEqualTo(5);
        List<Long> idsUltimas = new ArrayList<>();
        ultimas.forEach(f -> idsUltimas.add(f.path("id").asLong()));
        assertThat(idsUltimas).containsExactlyElementsOf(ids.subList(0, 5));
    }
}
