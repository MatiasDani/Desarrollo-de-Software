/**
 * Cliente HTTP del frontend.
 * Usa rutas relativas: al servirse desde Spring Boot funciona en cualquier host/puerto.
 */
export class FacturaService {
    constructor(baseUrl = '/api') {
        this.baseUrl = baseUrl;
    }

    async request(path, options = {}) {
        const { headers, ...rest } = options;
        const response = await fetch(`${this.baseUrl}${path}`, {
            ...rest,
            headers: { 'Accept': 'application/json', ...(headers || {}) }
        });

        const contentType = response.headers.get('content-type') || '';
        let data = null;

        if (contentType.includes('application/json')) {
            data = await response.json().catch(() => null);
        } else {
            const text = await response.text().catch(() => '');
            data = text ? { message: text } : null;
        }

        if (!response.ok) {
            const message = data && data.message
                ? data.message
                : `Error HTTP ${response.status} al comunicarse con el servidor.`;
            throw new Error(message);
        }
        return data;
    }

    async obtenerFacturas(filtros) {
        const params = new URLSearchParams();
        if (filtros) {
            if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
            if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
            if (filtros.estado) params.append('estado', filtros.estado);
            if (filtros.montoMinimo !== undefined && filtros.montoMinimo !== null && !isNaN(filtros.montoMinimo)) {
                params.append('montoMinimo', filtros.montoMinimo.toString());
            }
        }
        const qs = params.toString();
        return this.request(`/facturas${qs ? `?${qs}` : ''}`);
    }

    async obtenerFacturasPaginadas(filtros, pagina = 0, tamanio = 10) {
        const params = new URLSearchParams();
        if (filtros) {
            if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
            if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
            if (filtros.estado) params.append('estado', filtros.estado);
            if (filtros.montoMinimo !== undefined && filtros.montoMinimo !== null && !isNaN(filtros.montoMinimo)) {
                params.append('montoMinimo', filtros.montoMinimo.toString());
            }
        }
        params.append('pagina', String(Math.max(0, pagina)));
        params.append('tamanio', String(tamanio));
        return this.request(`/facturas/paginado?${params.toString()}`);
    }

    /** Totales del panel de control, calculados en el servidor. */
    obtenerResumen() {
        return this.request('/facturas/resumen');
    }

    obtenerFactura(id) {
        return this.request(`/facturas/${id}`);
    }

    crearFactura(factura) {
        return this.request('/facturas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
    }

    actualizarFactura(id, factura) {
        return this.request(`/facturas/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
    }

    actualizarEstado(id, estado, observaciones) {
        return this.actualizarFactura(id, { estado, observaciones });
    }

    emitirCae(id, tipoComprobante) {
        return this.request(`/facturas/${id}/emitir`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tipoComprobante ? { tipoComprobante } : {})
        });
    }

    eliminarFactura(id) {
        return this.request(`/facturas/${id}`, { method: 'DELETE' });
    }

    obtenerCatalogos() {
        return this.request('/catalogos');
    }

    obtenerEstadoAfip() {
        return this.request('/afip/estado');
    }

    probarConexionAfip() {
        return this.request('/afip/dummy', { method: 'POST' });
    }

    limpiarCacheAfip() {
        return this.request('/afip/cache', { method: 'DELETE' });
    }

    obtenerMonedasAfip() {
        return this.request('/afip/monedas');
    }

    sincronizarMonedasAfip() {
        return this.request('/afip/monedas/sincronizar', { method: 'POST' });
    }
}
