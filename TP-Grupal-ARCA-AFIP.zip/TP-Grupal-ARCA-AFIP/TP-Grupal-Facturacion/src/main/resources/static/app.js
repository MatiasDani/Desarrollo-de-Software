import { FacturaService } from './FacturaService.js';

const api = new FacturaService();

const state = {
    facturas: [],
    facturasCompletas: [],
    catalogos: {
        puntosVenta: [],
        clientes: [],
        condicionesIva: [],
        tiposMoneda: [],
        articulos: []
    },
    afip: null,
    detalles: [],
    detalleActual: null,
    filtros: {},
    paginacion: {
        pagina: 0,
        tamanio: 10,
        totalPaginas: 0,
        totalElementos: 0
    },
    vista: 'dashboard'
};

const VISTAS = {
    dashboard: ['Panel de control', 'Resumen de la facturación y estado de la integración.'],
    facturas: ['Comprobantes', 'Consultá, filtrá y gestioná las facturas del sistema.'],
    nueva: ['Nueva factura', 'Cargá los datos y emití el comprobante con CAE.'],
    afip: ['Estado AFIP', 'Estado de la conexión con ARCA / AFIP.']
};

const TIPOS_COMPROBANTE = {
    1: 'Factura A',
    3: 'Nota de Crédito A',
    6: 'Factura B',
    8: 'Nota de Crédito B',
    11: 'Factura C',
    13: 'Nota de Crédito C'
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

document.addEventListener('DOMContentLoaded', init);

async function init() {
    bindNavigation();
    bindFiltros();
    bindPaginacion();
    bindFormulario();
    bindAccionesGlobales();
    bindAfip();
    bindModales();

    setFechaHoy();

    await Promise.all([cargarCatalogos(), cargarAfipEstado()]);
    poblarSelects();
    resetFormulario();

    await cargarFacturas();
    switchView('dashboard');
}

/* ============================================================
   Navegación
   ============================================================ */
function bindNavigation() {
    const sidebar = $('#sidebar');
    const toggle = $('#nav-toggle');

    const menuAbierto = () => Boolean(sidebar?.classList.contains('is-open'));

    const cerrarMenu = () => {
        if (!menuAbierto()) {
            return;
        }
        sidebar.classList.remove('is-open');
        toggle?.setAttribute('aria-expanded', 'false');
        toggle?.setAttribute('aria-label', 'Abrir menú de navegación');
    };

    const abrirMenu = () => {
        sidebar?.classList.add('is-open');
        toggle?.setAttribute('aria-expanded', 'true');
        toggle?.setAttribute('aria-label', 'Cerrar menú de navegación');
    };

    toggle?.addEventListener('click', () => {
        if (menuAbierto()) {
            cerrarMenu();
        } else {
            abrirMenu();
        }
    });

    $$('.nav-item[data-view]').forEach((boton) => {
        boton.addEventListener('click', () => {
            switchView(boton.dataset.view);
            cerrarMenu();
        });
    });

    document.addEventListener('click', (evento) => {
        if (menuAbierto() && !sidebar.contains(evento.target)) {
            cerrarMenu();
        }
    });

    document.addEventListener('keydown', (evento) => {
        if (evento.key === 'Escape') {
            cerrarMenu();
        }
    });

    document.addEventListener('click', (evento) => {
        const destino = evento.target.closest('[data-go]');
        if (destino) {
            switchView(destino.dataset.go);
            cerrarMenu();
        }
    });

    $('#btn-refrescar')?.addEventListener('click', async (evento) => {
        const boton = evento.currentTarget;
        setBotonCargando(boton, true, 'Actualizando…');
        try {
            await Promise.all([cargarAfipEstado(), cargarFacturas(state.filtros)]);
            toast('Datos actualizados', 'Se refrescó la información del sistema.', 'success');
        } finally {
            setBotonCargando(boton, false);
        }
    });
}

function switchView(vista) {
    if (!VISTAS[vista]) {
        return;
    }
    state.vista = vista;

    $$('.view').forEach((seccion) => {
        seccion.hidden = seccion.id !== `view-${vista}`;
    });

    $$('.nav-item[data-view]').forEach((boton) => {
        boton.classList.toggle('is-active', boton.dataset.view === vista);
    });

    const [titulo, subtitulo] = VISTAS[vista];
    $('#page-title').textContent = titulo;
    $('#page-subtitle').textContent = subtitulo;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ============================================================
   Carga de datos
   ============================================================ */
async function cargarCatalogos() {
    try {
        const datos = await api.obtenerCatalogos();
        state.catalogos = {
            puntosVenta: datos?.puntosVenta || [],
            clientes: datos?.clientes || [],
            condicionesIva: datos?.condicionesIva || [],
            tiposMoneda: datos?.tiposMoneda || [],
            articulos: datos?.articulos || []
        };
    } catch (error) {
        toast('No se pudieron cargar los catálogos', error.message, 'error');
    }
}

async function cargarAfipEstado() {
    try {
        state.afip = await api.obtenerEstadoAfip();
    } catch (error) {
        state.afip = null;
        toast('No se pudo consultar el estado de AFIP', error.message, 'warning');
    }
    renderAfipUI();
}

async function cargarFacturas(filtros = state.filtros, pagina = state.paginacion.pagina) {
    setCargando(true);
    try {
        // El listado principal se pide paginado al backend; el panel de control
        // necesita el universo completo para calcular sus totales.
        const [paginaDatos, todas] = await Promise.all([
            api.obtenerFacturasPaginadas(filtros, pagina, state.paginacion.tamanio),
            api.obtenerFacturas()
        ]);
        state.facturas = paginaDatos?.contenido || [];
        state.paginacion = {
            pagina: paginaDatos?.pagina ?? 0,
            tamanio: paginaDatos?.tamanio ?? state.paginacion.tamanio,
            totalPaginas: paginaDatos?.totalPaginas ?? 0,
            totalElementos: paginaDatos?.totalElementos ?? 0
        };
        state.facturasCompletas = todas || [];
        renderDashboard();
        renderFacturas();
    } catch (error) {
        state.facturas = [];
        state.facturasCompletas = [];
        renderDashboard();
        renderFacturas(error.message);
        toast('Error al cargar los comprobantes', error.message, 'error');
    } finally {
        setCargando(false);
    }
}

/* ============================================================
   Dashboard
   ============================================================ */
function renderDashboard() {
    const facturas = state.facturasCompletas;
    const vigentes = facturas.filter((f) => f.estado !== 'ANULADA');
    const anuladas = facturas.filter((f) => f.estado === 'ANULADA');
    const conCae = vigentes.filter((f) => Boolean(f.cae));
    const pendientes = vigentes.filter((f) => !f.cae);
    const total = vigentes.reduce((acumulado, f) => acumulado + Number(f.importeTotal || 0), 0);

    $('#stat-total').textContent = formatearMoneda(total);
    $('#stat-total-foot').textContent = `${vigentes.length} comprobante${vigentes.length === 1 ? '' : 's'} vigente${vigentes.length === 1 ? '' : 's'}`;
    $('#stat-cae').textContent = String(conCae.length);
    $('#stat-pendientes').textContent = String(pendientes.length);
    $('#stat-anuladas').textContent = String(anuladas.length);

    const cuerpo = $('#dashboard-body');
    if (!cuerpo) return;

    if (facturas.length === 0) {
        cuerpo.innerHTML = filaVacia(6, 'Todavía no hay comprobantes', 'Creá la primera factura para empezar.');
        return;
    }

    const ultimas = [...facturas]
        .sort((a, b) => Number(b.id) - Number(a.id))
        .slice(0, 5);

    cuerpo.innerHTML = ultimas.map((f) => `
        <tr data-id="${f.id}">
            <td>
                <span class="cell-strong">${escaparHtml(numeroComprobante(f))}</span>
                <div class="hint">${escaparHtml(etiquetaTipo(f.tipoComprobante))}</div>
            </td>
            <td class="cell-nowrap">${formatearFecha(f.fechaEmision)}</td>
            <td>${escaparHtml(f.clienteDenominacion || 'Consumidor Final')}</td>
            <td class="cell-money">${formatearMoneda(f.importeTotal)}</td>
            <td>${badgeEstado(f.estado)}</td>
            <td style="text-align:right">
                <button type="button" class="btn btn-ghost btn-sm" data-action="ver" data-id="${f.id}">Ver</button>
            </td>
        </tr>
    `).join('');
}

/* ============================================================
   Listado de facturas
   ============================================================ */
function renderFacturas(mensajeError) {
    const cuerpo = $('#facturas-body');
    if (!cuerpo) return;

    const total = state.paginacion.totalElementos;
    const contador = $('#facturas-count');
    if (contador) {
        contador.textContent = mensajeError
            ? mensajeError
            : `${total} comprobante${total === 1 ? '' : 's'} encontrado${total === 1 ? '' : 's'}`;
    }

    if (state.facturas.length === 0) {
        cuerpo.innerHTML = filaVacia(9,
            mensajeError ? 'No se pudieron cargar los comprobantes' : 'No hay comprobantes para mostrar',
            mensajeError || 'Probá cambiando los filtros o creá una nueva factura.');
        renderPaginacion();
        return;
    }

    cuerpo.innerHTML = state.facturas.map((f) => {
        const puedeEmitir = !f.cae && f.estado !== 'ANULADA';
        const puedeAnular = f.estado !== 'ANULADA';
        // Un comprobante con CAE ya fue autorizado por AFIP: se anula, no se borra.
        const puedeEliminar = !f.cae;
        return `
            <tr data-id="${f.id}">
                <td>
                    <span class="cell-strong">${escaparHtml(numeroComprobante(f))}</span>
                    <div class="hint">${escaparHtml(etiquetaTipo(f.tipoComprobante))}</div>
                </td>
                <td class="cell-nowrap">${formatearFecha(f.fechaEmision)}</td>
                <td>${escaparHtml(f.clienteDenominacion || 'Consumidor Final')}</td>
                <td>${escaparHtml(f.condicionIva || '—')}</td>
                <td>${escaparHtml(f.puntoVentaDescripcion || '—')}</td>
                <td class="cell-money">${formatearMoneda(f.importeTotal)}</td>
                <td>${badgeEstado(f.estado)}</td>
                <td>${chipCae(f)}</td>
                <td>
                    <div class="row-actions">
                        <button type="button" class="icon-btn" data-action="ver" data-id="${f.id}" title="Ver detalle" aria-label="Ver detalle">
                            ${icono('ojo')}
                        </button>
                        ${puedeEmitir ? `
                            <button type="button" class="icon-btn" data-action="emitir" data-id="${f.id}" title="Emitir CAE" aria-label="Emitir CAE">
                                ${icono('rayo')}
                            </button>
                        ` : ''}
                        ${puedeAnular ? `
                            <button type="button" class="icon-btn" data-action="anular" data-id="${f.id}" title="Anular factura" aria-label="Anular factura">
                                ${icono('anular')}
                            </button>
                        ` : ''}
                        ${puedeEliminar ? `
                            <button type="button" class="icon-btn" data-action="eliminar" data-id="${f.id}" title="Eliminar factura" aria-label="Eliminar factura">
                                ${icono('papelera')}
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    renderPaginacion();
}

/* ============================================================
   Paginación
   ============================================================ */
function renderPaginacion() {
    const { pagina, tamanio, totalPaginas, totalElementos } = state.paginacion;

    const info = $('#facturas-rango');
    if (info) {
        const desde = totalElementos === 0 ? 0 : pagina * tamanio + 1;
        const hasta = Math.min((pagina + 1) * tamanio, totalElementos);
        info.textContent = totalElementos === 0
            ? 'Sin comprobantes'
            : `Mostrando ${desde}–${hasta} de ${totalElementos}`;
    }

    const etiqueta = $('#facturas-pagina');
    if (etiqueta) {
        etiqueta.textContent = totalPaginas === 0
            ? 'Página 0 de 0'
            : `Página ${pagina + 1} de ${totalPaginas}`;
    }

    const enPrimera = pagina <= 0;
    const enUltima = totalPaginas === 0 || pagina >= totalPaginas - 1;
    fijarDeshabilitado('#btn-pagina-primera', enPrimera);
    fijarDeshabilitado('#btn-pagina-anterior', enPrimera);
    fijarDeshabilitado('#btn-pagina-siguiente', enUltima);
    fijarDeshabilitado('#btn-pagina-ultima', enUltima);
}

function fijarDeshabilitado(selector, deshabilitado) {
    const boton = $(selector);
    if (boton) boton.disabled = deshabilitado;
}

function bindPaginacion() {
    $('#btn-pagina-primera')?.addEventListener('click', () => irAPagina(0));
    $('#btn-pagina-anterior')?.addEventListener('click', () => irAPagina(state.paginacion.pagina - 1));
    $('#btn-pagina-siguiente')?.addEventListener('click', () => irAPagina(state.paginacion.pagina + 1));
    $('#btn-pagina-ultima')?.addEventListener('click', () => irAPagina(state.paginacion.totalPaginas - 1));

    $('#facturas-tamanio')?.addEventListener('change', (evento) => {
        const tamanio = Number(evento.target.value);
        state.paginacion.tamanio = Number.isFinite(tamanio) && tamanio > 0 ? tamanio : 10;
        cargarFacturas(state.filtros, 0);
    });
}

function irAPagina(pagina) {
    if (pagina < 0) return;
    if (state.paginacion.totalPaginas > 0 && pagina > state.paginacion.totalPaginas - 1) return;
    if (pagina === state.paginacion.pagina) return;
    cargarFacturas(state.filtros, pagina);
}

/* ============================================================
   Filtros
   ============================================================ */
function bindFiltros() {
    $('#form-filtros')?.addEventListener('submit', async (evento) => {
        evento.preventDefault();
        const monto = $('#filtro-monto').value;
        state.filtros = {
            fechaDesde: $('#filtro-fecha-desde').value || undefined,
            fechaHasta: $('#filtro-fecha-hasta').value || undefined,
            estado: $('#filtro-estado').value || undefined,
            montoMinimo: monto !== '' ? Number(monto) : undefined
        };
        await cargarFacturas(state.filtros, 0);
    });

    $('#btn-limpiar-filtros')?.addEventListener('click', async () => {
        $('#form-filtros').reset();
        state.filtros = {};
        await cargarFacturas(state.filtros, 0);
    });
}

/* ============================================================
   Formulario de alta
   ============================================================ */
function bindFormulario() {
    $('#form-nueva')?.addEventListener('submit', (evento) => {
        evento.preventDefault();
        guardarFactura(false);
    });

    $('#btn-guardar-emitir')?.addEventListener('click', () => guardarFactura(true));
    $('#btn-agregar-item')?.addEventListener('click', agregarItem);
    $('#nueva-cliente')?.addEventListener('change', alCambiarCliente);
    $('#nueva-tipo-comprobante')?.addEventListener('change', () => renderItems());
    $('#nueva-moneda')?.addEventListener('change', () => renderItems());

    $('#nueva-cantidad')?.addEventListener('keydown', (evento) => {
        if (evento.key === 'Enter') {
            evento.preventDefault();
            agregarItem();
        }
    });
}

function poblarSelects() {
    const { puntosVenta, clientes, condicionesIva, tiposMoneda, articulos } = state.catalogos;

    $('#nueva-punto-venta').innerHTML = puntosVenta.length
        ? puntosVenta.map((pv) => `<option value="${pv.id}">${escaparHtml(`${pv.numero} · ${pv.descripcion}`)}</option>`).join('')
        : '<option value="">Sin puntos de venta</option>';

    $('#nueva-cliente').innerHTML = [
        '<option value="">Consumidor Final</option>',
        ...clientes.map((c) => `<option value="${c.id}">${escaparHtml(c.denominacion + (c.cuit ? ` · ${c.cuit}` : ''))}</option>`)
    ].join('');

    $('#nueva-condicion-iva').innerHTML = condicionesIva.length
        ? condicionesIva.map((ci) => `<option value="${ci.id}">${escaparHtml(ci.denominacion)}</option>`).join('')
        : '<option value="">Sin condiciones</option>';

    $('#nueva-moneda').innerHTML = tiposMoneda.length
        ? tiposMoneda.map((tm) => `<option value="${tm.id}">${escaparHtml(etiquetaMoneda(tm))}</option>`).join('')
        : '<option value="">Sin monedas</option>';

    $('#nueva-articulo').innerHTML = articulos.length
        ? articulos.map((a) => `<option value="${a.id}">${escaparHtml(`${a.codigo} · ${a.denominacion} — ${formatearMoneda(a.precioVenta)}`)}</option>`).join('')
        : '<option value="">Sin artículos</option>';
}

function resetFormulario() {
    const formulario = $('#form-nueva');
    formulario?.reset();
    setFechaHoy();

    const tipoDefault = state.afip?.tipoComprobanteDefault || 11;
    if ($('#nueva-tipo-comprobante')) {
        $('#nueva-tipo-comprobante').value = String(tipoDefault);
    }
    if (state.catalogos.puntosVenta[0]) {
        $('#nueva-punto-venta').value = String(state.catalogos.puntosVenta[0].id);
    }
    if (state.catalogos.condicionesIva[0]) {
        $('#nueva-condicion-iva').value = String(state.catalogos.condicionesIva[0].id);
    }
    if (state.catalogos.tiposMoneda[0]) {
        $('#nueva-moneda').value = String(state.catalogos.tiposMoneda[0].id);
    }
    if (state.catalogos.articulos[0]) {
        $('#nueva-articulo').value = String(state.catalogos.articulos[0].id);
    }

    actualizarHintCliente();
    state.detalles = [];
    renderItems();
}

function alCambiarCliente() {
    const cliente = clienteSeleccionado();
    if (cliente && cliente.condicionIvaId) {
        $('#nueva-condicion-iva').value = String(cliente.condicionIvaId);
    }
    actualizarHintCliente();
    renderItems();
}

function actualizarHintCliente() {
    const cliente = clienteSeleccionado();
    const hint = $('#nueva-cliente-hint');
    if (!hint) return;

    if (!cliente) {
        hint.textContent = 'Sin cliente: se emite a Consumidor Final (DocTipo 99).';
    } else if (cliente.cuit) {
        hint.textContent = `CUIT ${cliente.cuit} · DocTipo 80.`;
    } else {
        hint.textContent = 'El cliente no tiene CUIT: se usará DocTipo 99.';
    }
}

function agregarItem() {
    const articuloId = Number($('#nueva-articulo').value);
    const cantidad = Number($('#nueva-cantidad').value);
    const articulo = state.catalogos.articulos.find((a) => Number(a.id) === articuloId);

    if (!articulo) {
        toast('Seleccioná un artículo', 'No hay un artículo válido seleccionado.', 'warning');
        return;
    }
    if (!Number.isFinite(cantidad) || cantidad <= 0) {
        toast('Cantidad inválida', 'Ingresá una cantidad mayor a cero.', 'warning');
        $('#nueva-cantidad').focus();
        return;
    }

    const existente = state.detalles.find((d) => Number(d.articuloId) === articuloId);
    if (existente) {
        existente.cantidad += cantidad;
    } else {
        state.detalles.push({
            articuloId,
            cantidad,
            articulo
        });
    }

    $('#nueva-cantidad').value = '1';
    renderItems();
}

function renderItems() {
    const cuerpo = $('#items-body');
    if (!cuerpo) return;

    const vacio = state.detalles.length === 0;
    const contenedorTabla = cuerpo.closest('.table-wrap');
    if (contenedorTabla) contenedorTabla.hidden = vacio;
    $('#items-empty').hidden = !vacio;

    const moneda = monedaSeleccionada();
    cuerpo.innerHTML = state.detalles.map((detalle, indice) => `
        <tr>
            <td>
                <span class="cell-strong">${escaparHtml(detalle.articulo.denominacion)}</span>
                <div class="hint">${escaparHtml(detalle.articulo.codigo)}</div>
            </td>
            <td>${formatearMoneda(detalle.articulo.precioVenta, moneda)}</td>
            <td>${formatearCantidad(detalle.cantidad)}</td>
            <td class="cell-money">${formatearMoneda(detalle.articulo.precioVenta * detalle.cantidad, moneda)}</td>
            <td style="text-align:right">
                <button type="button" class="icon-btn" data-action="quitar-item" data-index="${indice}" title="Quitar ítem" aria-label="Quitar ítem">
                    ${icono('papelera')}
                </button>
            </td>
        </tr>
    `).join('');

    actualizarResumen();
}

function actualizarResumen() {
    const tipo = Number($('#nueva-tipo-comprobante')?.value || 11);
    const moneda = monedaSeleccionada();
    const total = state.detalles.reduce((acumulado, d) => acumulado + d.cantidad * d.articulo.precioVenta, 0);
    const discrimina = tipo === 1 || tipo === 6;
    const alicuota = Number(state.afip?.alicuotaIva ?? 21);
    const neto = discrimina ? total / (1 + alicuota / 100) : total;
    const iva = discrimina ? total - neto : 0;

    $('#resumen-subtotal').textContent = formatearMoneda(neto, moneda);
    $('#resumen-iva-label').textContent = discrimina ? `IVA ${alicuota}%` : 'IVA (no discriminado)';
    $('#resumen-iva').textContent = formatearMoneda(iva, moneda);
    $('#resumen-total').textContent = formatearMoneda(total, moneda);

    const nota = $('#resumen-nota');
    if (nota) {
        if (tipo === 11) {
            nota.textContent = 'Factura C: el importe total no discrimina IVA.';
        } else if (tipo === 1) {
            nota.textContent = 'Factura A: requiere CUIT del receptor y discrimina IVA.';
        } else {
            nota.textContent = 'Factura B: IVA incluido en el precio y discriminado en el comprobante.';
        }

        const cliente = clienteSeleccionado();
        if (tipo === 1 && (!cliente || !cliente.cuit)) {
            nota.textContent = 'Atención: una Factura A requiere un cliente con CUIT.';
            nota.style.color = 'var(--warning)';
        } else {
            nota.style.color = '';
        }
    }
}

async function guardarFactura(emitirCae) {
    const formulario = $('#form-nueva');
    if (!formulario.reportValidity()) {
        return;
    }
    if (state.detalles.length === 0) {
        toast('Faltan ítems', 'Agregá al menos un artículo antes de guardar la factura.', 'warning');
        $('#nueva-articulo')?.focus();
        return;
    }

    const tipo = Number($('#nueva-tipo-comprobante').value || 11);
    if (tipo === 1) {
        const cliente = clienteSeleccionado();
        if (!cliente || !cliente.cuit) {
            toast('Factura A inválida', 'Para emitir una Factura A el cliente debe tener CUIT.', 'warning');
            return;
        }
    }

    const clienteId = $('#nueva-cliente').value;
    const dto = {
        puntoVentaId: Number($('#nueva-punto-venta').value),
        clienteId: clienteId ? Number(clienteId) : null,
        condicionIvaId: Number($('#nueva-condicion-iva').value),
        tipoMonedaId: Number($('#nueva-moneda').value),
        tipoComprobante: tipo,
        fechaEmision: $('#nueva-fecha').value,
        importeCobrado: 0,
        estado: 'ACTIVA',
        observaciones: $('#nueva-observaciones').value || null,
        detalles: state.detalles.map((d) => ({ articuloId: d.articuloId, cantidad: d.cantidad }))
    };

    const boton = emitirCae ? $('#btn-guardar-emitir') : $('#btn-guardar');
    setBotonCargando(boton, true, emitirCae ? 'Emitiendo…' : 'Guardando…');

    try {
        const creada = await api.crearFactura(dto);

        if (emitirCae) {
            try {
                const detalle = await api.emitirCae(creada.id, tipo);
                if (detalle.cae) {
                    toast(
                        `Factura ${numeroComprobante(detalle)} emitida con CAE`,
                        `CAE ${detalle.cae} · vence ${formatearFecha(detalle.caeFechaVencimiento)}`,
                        'success'
                    );
                } else {
                    toast(
                        `Factura ${numeroComprobante(detalle)} guardada`,
                        detalle.motivoRechazo || 'AFIP no autorizó el comprobante.',
                        'warning'
                    );
                }
            } catch (error) {
                toast(
                    'Factura guardada, pero no se pudo emitir',
                    `${error.message} Podés reintentar desde el listado.`,
                    'warning'
                );
            }
        } else {
            toast(
                `Factura ${numeroComprobante(creada)} guardada`,
                'El comprobante quedó pendiente de CAE.',
                'success'
            );
        }

        resetFormulario();
        await cargarFacturas(state.filtros);
        switchView('facturas');
    } catch (error) {
        toast('No se pudo guardar la factura', error.message, 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

/* ============================================================
   Acciones sobre comprobantes
   ============================================================ */
function bindAccionesGlobales() {
    document.addEventListener('click', (evento) => {
        const boton = evento.target.closest('button[data-action]');
        if (boton) {
            const accion = boton.dataset.action;

            if (accion === 'quitar-item') {
                const indice = Number(boton.dataset.index);
                if (Number.isInteger(indice)) {
                    state.detalles.splice(indice, 1);
                    renderItems();
                }
                return;
            }

            const id = Number(boton.dataset.id);
            if (!id) return;

            if (accion === 'ver') openDetalle(id);
            if (accion === 'emitir') emitirFactura(id, boton);
            if (accion === 'anular') anularFactura(id);
            if (accion === 'eliminar') eliminarFactura(id);
            return;
        }

        const fila = evento.target.closest('tr[data-id]');
        if (fila && !evento.target.closest('button, a')) {
            openDetalle(Number(fila.dataset.id));
        }
    });
}

async function emitirFactura(id, boton) {
    const factura = state.facturas.find((f) => Number(f.id) === id);
    if (factura?.cae) {
        toast('La factura ya tiene CAE', `CAE ${factura.cae}`, 'info');
        return;
    }

    setBotonCargando(boton, true, 'Emitiendo…');
    try {
        const detalle = await api.emitirCae(id, factura?.tipoComprobante || undefined);
        if (detalle.cae) {
            toast(
                `Factura ${numeroComprobante(detalle)} autorizada`,
                `CAE ${detalle.cae} · vence ${formatearFecha(detalle.caeFechaVencimiento)}`,
                'success'
            );
        } else {
            toast(
                'AFIP no autorizó el comprobante',
                detalle.motivoRechazo || 'Revisá los datos fiscales e intentá nuevamente.',
                'warning'
            );
        }
        await cargarFacturas(state.filtros);
        if (!$('#modal-detalle').hidden) {
            await openDetalle(id);
        }
    } catch (error) {
        toast('No se pudo emitir el CAE', error.message, 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

async function anularFactura(id) {
    const factura = state.facturas.find((f) => Number(f.id) === id);
    const conCae = Boolean(factura?.cae);

    const confirmado = await confirmar({
        titulo: 'Anular comprobante',
        mensaje: conCae
            ? `La factura ${numeroComprobante(factura)} ya tiene CAE. Se realizará una anulación lógica; recordá que ante AFIP corresponde emitir una Nota de Crédito. ¿Continuar?`
            : `¿Querés anular la factura ${numeroComprobante(factura)}? El comprobante quedará marcado como ANULADA.`,
        textoConfirmar: 'Anular',
        peligro: true
    });
    if (!confirmado) return;

    try {
        await api.actualizarEstado(id, 'ANULADA', 'Anulada desde la interfaz web');
        toast('Comprobante anulado', 'La factura quedó marcada como ANULADA.', 'success');
        cerrarDetalle();
        await cargarFacturas(state.filtros);
    } catch (error) {
        toast('No se pudo anular', error.message, 'error');
    }
}

async function eliminarFactura(id) {
    const factura = state.facturas.find((f) => Number(f.id) === id);
    const confirmado = await confirmar({
        titulo: 'Eliminar comprobante',
        mensaje: `Se va a eliminar definitivamente la factura ${numeroComprobante(factura)}. Esta acción no se puede deshacer. ¿Continuar?`,
        textoConfirmar: 'Eliminar',
        peligro: true
    });
    if (!confirmado) return;

    try {
        await api.eliminarFactura(id);
        toast('Comprobante eliminado', 'El registro se eliminó del sistema.', 'success');
        cerrarDetalle();
        await cargarFacturas(state.filtros);
    } catch (error) {
        toast('No se pudo eliminar', error.message, 'error');
    }
}

/* ============================================================
   Modal de detalle
   ============================================================ */
function bindModales() {
    const modalDetalle = $('#modal-detalle');
    const modalConfirm = $('#modal-confirm');

    modalDetalle?.addEventListener('click', (evento) => {
        if (evento.target.closest('[data-close]')) cerrarDetalle();
    });

    $('#detalle-btn-emitir')?.addEventListener('click', (evento) => {
        const id = state.detalleActual?.id;
        if (id) emitirFactura(Number(id), evento.currentTarget);
    });

    modalConfirm?.addEventListener('click', (evento) => {
        if (evento.target.closest('[data-confirm-close]')) resolverConfirmacion(false);
    });

    $('#confirm-ok')?.addEventListener('click', () => resolverConfirmacion(true));

    document.addEventListener('keydown', (evento) => {
        if (evento.key !== 'Escape') return;
        if (!modalConfirm.hidden) resolverConfirmacion(false);
        else if (!modalDetalle.hidden) cerrarDetalle();
    });
}

async function openDetalle(id) {
    const modal = $('#modal-detalle');
    const cuerpo = $('#detalle-body');
    const botonEmitir = $('#detalle-btn-emitir');
    if (!modal || !cuerpo) return;

    modal.hidden = false;
    cuerpo.innerHTML = '<div class="empty-state">Cargando comprobante…</div>';
    botonEmitir.hidden = true;
    document.body.style.overflow = 'hidden';

    try {
        const detalle = await api.obtenerFactura(id);
        state.detalleActual = detalle;
        renderDetalle(detalle);
    } catch (error) {
        cuerpo.innerHTML = `<div class="empty-state"><strong>No se pudo cargar el comprobante</strong>${escaparHtml(error.message)}</div>`;
        toast('Error al abrir el comprobante', error.message, 'error');
    }
}

function renderDetalle(detalle) {
    const moneda = detalle.tipoMonedaCodigo || 'ARS';
    const puedeEmitir = !detalle.cae && detalle.estado !== 'ANULADA';

    $('#detalle-titulo').textContent = `Factura ${numeroComprobante(detalle)}`;
    $('#detalle-subtitulo').textContent = `${etiquetaTipo(detalle.tipoComprobante)} · ${formatearFecha(detalle.fechaEmision)}`;

    const filas = detalle.items.map((item) => `
        <tr>
            <td>
                <span class="cell-strong">${escaparHtml(item.denominacion)}</span>
                <div class="hint">${escaparHtml(item.codigo || '')}</div>
            </td>
            <td>${formatearCantidad(item.cantidad)}</td>
            <td>${formatearMoneda(item.precioUnitario, moneda)}</td>
            <td class="cell-money">${formatearMoneda(item.subtotal, moneda)}</td>
        </tr>
    `).join('');

    const fiscal = detalle.cae
        ? `
            <div class="fiscal-box">
                <h4>Autorización AFIP</h4>
                <div class="detail-grid" style="margin-bottom:0">
                    <div class="detail-item">
                        <span class="label">CAE</span>
                        <span class="value cae">${escaparHtml(detalle.cae)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Vencimiento CAE</span>
                        <span class="value">${formatearFecha(detalle.caeFechaVencimiento)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Resultado</span>
                        <span class="value">${escaparHtml(detalle.resultadoAfip || 'A')}</span>
                    </div>
                </div>
                ${detalle.motivoRechazo ? `<p class="motivo">${escaparHtml(detalle.motivoRechazo)}</p>` : ''}
                ${detalle.observaciones ? `<p class="obs">Observaciones: ${escaparHtml(detalle.observaciones)}</p>` : ''}
            </div>
        `
        : `
            <div class="fiscal-box">
                <h4>Sin CAE</h4>
                <p class="obs" style="margin:0">Este comprobante todavía no fue autorizado por AFIP.</p>
                ${detalle.motivoRechazo ? `<p class="motivo">${escaparHtml(detalle.motivoRechazo)}</p>` : ''}
            </div>
        `;

    $('#detalle-body').innerHTML = `
        <div class="detail-hero">
            <div>
                <h3>${escaparHtml(detalle.clienteDenominacion || 'Consumidor Final')}</h3>
                <p>${escaparHtml(detalle.condicionIva || '—')}${detalle.clienteCuit ? ` · CUIT ${escaparHtml(detalle.clienteCuit)}` : ''}</p>
            </div>
            <div class="detail-badges">
                ${badgeEstado(detalle.estado)}
                <span class="badge badge-activa">${escaparHtml(etiquetaTipo(detalle.tipoComprobante))}</span>
                ${detalle.cae ? '<span class="badge badge-emitida">Con CAE</span>' : '<span class="badge badge-simulado">Pendiente</span>'}
            </div>
        </div>

        <div class="detail-grid">
            <div class="detail-item"><span class="label">Fecha de emisión</span><span class="value">${formatearFecha(detalle.fechaEmision)}</span></div>
            <div class="detail-item"><span class="label">Punto de venta</span><span class="value">${escaparHtml(detalle.puntoVentaDescripcion || '—')}</span></div>
            <div class="detail-item"><span class="label">Moneda</span><span class="value">${escaparHtml(`${detalle.tipoMonedaCodigo || 'ARS'} · ${detalle.tipoMonedaDenominacion || ''}`)}</span></div>
            <div class="detail-item"><span class="label">Total</span><span class="value">${formatearMoneda(detalle.importeTotal, moneda)}</span></div>
            <div class="detail-item"><span class="label">Cobrado</span><span class="value">${formatearMoneda(detalle.importeCobrado, moneda)}</span></div>
            <div class="detail-item"><span class="label">Saldo</span><span class="value">${formatearMoneda(detalle.importeSaldo, moneda)}</span></div>
        </div>

        <div class="table-wrap">
            <table class="table" style="min-width:560px">
                <thead>
                <tr><th>Artículo</th><th>Cantidad</th><th>Precio unit.</th><th>Subtotal</th></tr>
                </thead>
                <tbody>${filas || filaVacia(4, 'Sin ítems', 'El comprobante no tiene renglones cargados.')}</tbody>
            </table>
        </div>

        ${fiscal}
    `;

    const botonEmitir = $('#detalle-btn-emitir');
    botonEmitir.hidden = !puedeEmitir;
    botonEmitir.textContent = 'Emitir CAE';
}

function cerrarDetalle() {
    const modal = $('#modal-detalle');
    if (!modal) return;
    modal.hidden = true;
    state.detalleActual = null;
    document.body.style.overflow = '';
}

/* ============================================================
   Confirmación
   ============================================================ */
let resolverConfirmacionActual = null;

function confirmar({ titulo, mensaje, textoConfirmar = 'Confirmar', peligro = true }) {
    const modal = $('#modal-confirm');
    if (!modal) return Promise.resolve(false);

    $('#confirm-title').textContent = titulo;
    $('#confirm-message').textContent = mensaje;

    const boton = $('#confirm-ok');
    boton.textContent = textoConfirmar;
    boton.className = 'btn ' + (peligro ? 'btn-danger' : 'btn-primary');

    modal.hidden = false;
    document.body.style.overflow = 'hidden';

    return new Promise((resolver) => {
        resolverConfirmacionActual = resolver;
    });
}

function resolverConfirmacion(valor) {
    const modal = $('#modal-confirm');
    if (modal) modal.hidden = true;
    document.body.style.overflow = '';
    if (resolverConfirmacionActual) {
        resolverConfirmacionActual(valor);
        resolverConfirmacionActual = null;
    }
}

/* ============================================================
   Estado AFIP
   ============================================================ */
function bindAfip() {
    $('#btn-probar-afip')?.addEventListener('click', probarConexionAfip);
    $('#btn-sync-monedas')?.addEventListener('click', sincronizarMonedasAfip);
}

function renderAfipUI() {
    const estado = state.afip;
    const pill = $('#afip-pill');
    const sidebar = $('#sidebar-afip');
    const sidebarTexto = $('#sidebar-afip-text');

    if (!estado) {
        if (pill) {
            pill.className = 'pill pill-muted';
            pill.innerHTML = '<span class="dot"></span> AFIP sin datos';
        }
        if (sidebarTexto) sidebarTexto.textContent = 'AFIP sin datos';
        return;
    }

    const info = etiquetaModo(estado);
    if (pill) {
        pill.className = `pill ${info.clase}`;
        pill.innerHTML = `<span class="dot"></span> ${escaparHtml(info.texto)}`;
    }
    if (sidebar) {
        sidebar.className = `sidebar-status ${info.clase === 'pill-ok' ? 'is-ok' : ''}`;
    }
    if (sidebarTexto) sidebarTexto.textContent = info.texto;

    const modoBadge = $('#afip-mode-badge');
    if (modoBadge) {
        modoBadge.className = `pill ${info.clase}`;
        modoBadge.innerHTML = `<span class="dot"></span> ${escaparHtml(estado.modo || '—')}`;
    }

    setTexto('#afip-mensaje', estado.mensaje || '—');
    setTexto('#afip-cuit', estado.cuit || 'No configurado');
    setTexto('#afip-credenciales', estado.credencialesConfiguradas ? 'Configuradas' : 'Pendientes');
    setTexto('#afip-tipo', etiquetaTipo(estado.tipoComprobanteDefault));
    setTexto('#afip-alicuota', `${estado.alicuotaIva ?? 21}%`);
    setTexto('#afip-cliente', estado.cliente || '—');

    const hint = $('#nueva-afip-hint');
    if (hint) {
        if (estado.simulado) {
            hint.textContent = 'Modo simulado: el CAE será ficticio y no se contactará a AFIP.';
        } else if (!estado.habilitado) {
            hint.textContent = 'AFIP deshabilitada: la factura se guardará sin CAE.';
        } else if (estado.credencialesConfiguradas) {
            hint.textContent = 'AFIP configurada: se solicitará el CAE al guardar y emitir.';
        } else {
            hint.textContent = 'Faltan credenciales AFIP: configuralas para emitir.';
        }
    }
}

async function probarConexionAfip(evento) {
    const boton = evento.currentTarget;
    setBotonCargando(boton, true, 'Probando…');
    const resultado = $('#afip-dummy-result');
    try {
        const respuesta = await api.probarConexionAfip();
        if (resultado) {
            resultado.hidden = false;
            resultado.className = `dummy-result ${respuesta.ok ? 'is-ok' : 'is-error'}`;
            const servidores = respuesta.servidores
                ? ` · AppServer: ${escaparHtml(respuesta.servidores.appServer || '—')} · DbServer: ${escaparHtml(respuesta.servidores.dbServer || '—')} · AuthServer: ${escaparHtml(respuesta.servidores.authServer || '—')}`
                : '';
            resultado.innerHTML = `<strong>${respuesta.ok ? 'Conexión OK' : 'Sin conexión'}</strong> — ${escaparHtml(respuesta.mensaje || '')}${servidores}`;
        }
        toast(
            respuesta.ok ? 'Diagnóstico AFIP OK' : 'Diagnóstico AFIP con observaciones',
            respuesta.mensaje,
            respuesta.ok ? 'success' : 'warning'
        );
    } catch (error) {
        if (resultado) {
            resultado.hidden = false;
            resultado.className = 'dummy-result is-error';
            resultado.innerHTML = `<strong>Error de conexión</strong> — ${escaparHtml(error.message)}`;
        }
        toast('Error al probar la conexión', error.message, 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

async function sincronizarMonedasAfip(evento) {
    const boton = evento.currentTarget;
    setBotonCargando(boton, true, 'Sincronizando…');
    const resultado = $('#monedas-sync-result');
    try {
        const respuesta = await api.sincronizarMonedasAfip();
        if (resultado) {
            resultado.hidden = false;
            resultado.className = `dummy-result ${respuesta.ok ? 'is-ok' : 'is-error'}`;
            resultado.innerHTML = `<strong>${respuesta.ok ? 'Sincronización OK' : 'Sin cambios'}</strong> — ${escaparHtml(respuesta.mensaje || '')}`;
        }
        if (respuesta.ok) {
            await cargarCatalogos();
            poblarSelects();
            renderItems();
        }
        toast(
            respuesta.ok ? 'Monedas sincronizadas' : 'Sincronización no disponible',
            respuesta.mensaje,
            respuesta.ok ? 'success' : 'warning'
        );
    } catch (error) {
        if (resultado) {
            resultado.hidden = false;
            resultado.className = 'dummy-result is-error';
            resultado.innerHTML = `<strong>Error al sincronizar</strong> — ${escaparHtml(error.message)}`;
        }
        toast('Error al sincronizar monedas', error.message, 'error');
    } finally {
        setBotonCargando(boton, false);
    }
}

/* ============================================================
   Helpers
   ============================================================ */
function clienteSeleccionado() {
    const valor = $('#nueva-cliente')?.value;
    if (!valor) return null;
    return state.catalogos.clientes.find((c) => Number(c.id) === Number(valor)) || null;
}

function monedaSeleccionada() {
    const valor = $('#nueva-moneda')?.value;
    const moneda = state.catalogos.tiposMoneda.find((m) => Number(m.id) === Number(valor));
    return moneda?.codigo || 'ARS';
}

function etiquetaTipo(codigo) {
    if (!codigo) return 'Comprobante';
    return TIPOS_COMPROBANTE[Number(codigo)] || `Comprobante ${codigo}`;
}

function etiquetaMoneda(moneda) {
    const iso = moneda.codigo || moneda.codigoAfip || '';
    const afip = moneda.codigoAfip && moneda.codigoAfip !== iso ? ` (${moneda.codigoAfip})` : '';
    return `${iso}${afip} · ${moneda.denominacion}`;
}

function numeroComprobante(factura) {
    if (!factura) return '—';
    const numero = factura.numeroFactura ?? factura.numero ?? factura.numeroAfip;
    return numero !== null && numero !== undefined ? `N° ${numero}` : 'N° —';
}

function etiquetaModo(estado) {
    if (estado.modo === 'SIMULADO') return { texto: 'AFIP simulada', clase: 'pill-warn' };
    if (estado.modo === 'HOMOLOGACION') return { texto: 'AFIP homologación', clase: 'pill-ok' };
    if (estado.modo === 'PRODUCCION') return { texto: 'AFIP producción', clase: 'pill-info' };
    if (estado.modo === 'DESHABILITADO') return { texto: 'AFIP deshabilitada', clase: 'pill-danger' };
    return { texto: 'AFIP', clase: 'pill-muted' };
}

function badgeEstado(estado) {
    const valor = String(estado || 'ACTIVA').toUpperCase();
    const clase = valor === 'ANULADA' ? 'badge-anulada' : (valor === 'EMITIDA' ? 'badge-emitida' : 'badge-activa');
    return `<span class="badge ${clase}">${escaparHtml(valor)}</span>`;
}

function chipCae(factura) {
    if (factura.cae) {
        return `<span class="cae-chip" title="CAE ${escaparHtml(factura.cae)}">${escaparHtml(factura.cae)}</span>`;
    }
    return '<span class="cae-chip is-pending">Pendiente</span>';
}

function filaVacia(columnas, titulo, detalle) {
    return `<tr><td colspan="${columnas}"><div class="empty-state"><strong>${escaparHtml(titulo)}</strong>${escaparHtml(detalle || '')}</div></td></tr>`;
}

function icono(nombre) {
    const trazos = {
        ojo: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',
        rayo: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
        anular: '<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',
        papelera: '<path d="M4 7h16"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M6 7l1 13h10l1-13"/><path d="M9 7V4h6v3"/>'
    };
    return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${trazos[nombre] || ''}</svg>`;
}

function formatearMoneda(valor, codigo = 'ARS') {
    const numero = Number(valor || 0);
    try {
        return new Intl.NumberFormat('es-AR', {
            style: 'currency',
            currency: codigo || 'ARS',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(numero);
    } catch (error) {
        return `$ ${numero.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
}

function formatearCantidad(valor) {
    const numero = Number(valor || 0);
    return Number.isInteger(numero) ? String(numero) : numero.toLocaleString('es-AR', { maximumFractionDigits: 2 });
}

function formatearFecha(valor) {
    if (!valor) return '—';
    if (typeof valor === 'string') {
        const soloFecha = valor.substring(0, 10);
        const partes = soloFecha.split('-');
        if (partes.length === 3 && partes[0].length === 4) {
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }
    }
    const fecha = new Date(valor);
    if (Number.isNaN(fecha.getTime())) return '—';
    return fecha.toLocaleDateString('es-AR');
}

function setFechaHoy() {
    const fecha = new Date();
    const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
    const input = $('#nueva-fecha');
    if (input) input.value = local.toISOString().slice(0, 10);
}

function setTexto(selector, valor) {
    const elemento = $(selector);
    if (elemento) elemento.textContent = valor ?? '—';
}

function escaparHtml(valor) {
    return String(valor ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function setCargando(activo) {
    $('#progress-bar')?.classList.toggle('is-active', activo);
}

function setBotonCargando(boton, cargando, texto = 'Procesando…') {
    if (!boton) return;
    if (cargando) {
        boton.dataset.htmlOriginal = boton.innerHTML;
        boton.disabled = true;
        boton.innerHTML = `<span class="spinner"></span>${escaparHtml(texto)}`;
    } else {
        boton.disabled = false;
        if (boton.dataset.htmlOriginal) {
            boton.innerHTML = boton.dataset.htmlOriginal;
            delete boton.dataset.htmlOriginal;
        }
    }
}

function toast(titulo, mensaje, tipo = 'info') {
    const contenedor = $('#toast-container');
    if (!contenedor) return;

    const iconos = { success: '✓', error: '!', warning: '!', info: 'i' };
    const elemento = document.createElement('div');
    elemento.className = `toast is-${tipo}`;
    elemento.innerHTML = `
        <div class="toast-icon">${iconos[tipo] || 'i'}</div>
        <div class="toast-content">
            <span class="toast-title">${escaparHtml(titulo)}</span>
            ${mensaje ? `<span class="toast-message">${escaparHtml(mensaje)}</span>` : ''}
        </div>
        <button type="button" class="toast-close" aria-label="Cerrar">×</button>
    `;

    const quitar = () => {
        elemento.style.opacity = '0';
        elemento.style.transform = 'translateX(12px)';
        elemento.style.transition = 'opacity .18s ease, transform .18s ease';
        setTimeout(() => elemento.remove(), 190);
    };

    elemento.querySelector('.toast-close').addEventListener('click', quitar);
    contenedor.appendChild(elemento);
    setTimeout(quitar, 6500);
}
