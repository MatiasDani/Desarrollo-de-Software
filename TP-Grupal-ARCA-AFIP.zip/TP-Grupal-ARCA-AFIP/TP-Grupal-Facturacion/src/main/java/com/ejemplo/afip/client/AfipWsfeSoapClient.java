package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipException;
import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.MonedasAfip;
import com.ejemplo.afip.model.AfipAuth;
import com.ejemplo.afip.model.CaeResultado;
import com.ejemplo.afip.model.ComprobanteAfip;
import com.ejemplo.afip.model.EstadoServidores;
import com.ejemplo.afip.model.MonedaAfip;
import com.ejemplo.afip.model.UltimoComprobante;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Cliente WSFEv1 para homologación/producción.
 *
 * <p>Implementación SOAP manual (sin stubs). Se usa como respaldo cuando el
 * cliente JAX-WS generado no puede inicializarse. Implementa las operaciones
 * usadas por el circuito de facturación:
 * {@code FEDummy} (diagnóstico), {@code FECompUltimoAutorizado} (último
 * número) y {@code FECAESolicitar} (obtención del CAE).</p>
 */
@Component
public class AfipWsfeSoapClient {

    private static final Logger log = LoggerFactory.getLogger(AfipWsfeSoapClient.class);
    private static final String NS = "http://ar.gov.afip.dif.FEV1/";
    private static final String ACCION_ULTIMO = NS + "FECompUltimoAutorizado";
    private static final String ACCION_CAE = NS + "FECAESolicitar";
    private static final String ACCION_DUMMY = NS + "FEDummy";
    private static final String ACCION_MONEDAS = NS + "FEParamGetTiposMonedas";
    private static final String ACCION_COTIZACION = NS + "FEParamGetCotizacion";
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("yyyyMMdd");

    private final AfipProperties properties;

    public AfipWsfeSoapClient(AfipProperties properties) {
        this.properties = properties;
    }

    public EstadoServidores dummy() {
        String envelope = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:ar=\"" + NS + "\">"
                + "<soapenv:Header/><soapenv:Body><ar:FEDummy/></soapenv:Body>"
                + "</soapenv:Envelope>";

        Document document = enviarYParsear(envelope, ACCION_DUMMY);
        Element resultado = SoapSupport.primerElemento(document.getDocumentElement(), "FEDummyResult");
        return new EstadoServidores(
                SoapSupport.texto(resultado, "AppServer"),
                SoapSupport.texto(resultado, "DbServer"),
                SoapSupport.texto(resultado, "AuthServer"));
    }

    public UltimoComprobante ultimoComprobante(AfipAuth auth, int puntoVenta, int tipoComprobante) {
        String envelope = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:ar=\"" + NS + "\">"
                + "<soapenv:Header/><soapenv:Body>"
                + "<ar:FECompUltimoAutorizado>"
                + authXml(auth)
                + "<ar:PtoVta>" + puntoVenta + "</ar:PtoVta>"
                + "<ar:CbteTipo>" + tipoComprobante + "</ar:CbteTipo>"
                + "</ar:FECompUltimoAutorizado>"
                + "</soapenv:Body></soapenv:Envelope>";

        Document document = enviarYParsear(envelope, ACCION_ULTIMO);
        Element resultado = SoapSupport.primerElemento(
                document.getDocumentElement(), "FECompUltimoAutorizadoResult");
        if (resultado == null) {
            throw new AfipException("WSFEv1 no devolvió FECompUltimoAutorizadoResult.");
        }

        long numero = SoapSupport.entero(resultado, "CbteNro", 0);
        List<String> errores = SoapSupport.leerMensajes(SoapSupport.hijo(resultado, "Errors"), "Err");
        List<String> eventos = SoapSupport.leerMensajes(SoapSupport.hijo(resultado, "Events"), "Evt");

        if (!errores.isEmpty()) {
            throw new AfipException("AFIP rechazó la consulta del último comprobante: " + String.join(" | ", errores));
        }

        log.info("WSFEv1: último comprobante ptoVta={} tipo={} => {}", puntoVenta, tipoComprobante, numero);
        return new UltimoComprobante(numero, errores, eventos);
    }

    public CaeResultado solicitarCae(AfipAuth auth, ComprobanteAfip comprobante) {
        String envelope = construirEnvelopeCae(auth, comprobante);
        Document document = enviarYParsear(envelope, ACCION_CAE);
        return parsearCae(document, comprobante);
    }

    /** Construye el sobre SOAP de FECAESolicitar (visible para tests). */
    String construirEnvelopeCae(AfipAuth auth, ComprobanteAfip comprobante) {
        double total = redondear(comprobante.importeTotal());
        double neto;
        double iva;
        int idIva = idAlicuota(comprobante.alicuotaIva());

        if (comprobante.esFacturaC() || comprobante.alicuotaIva() <= 0) {
            neto = total;
            iva = 0;
        } else {
            double divisor = 1 + (comprobante.alicuotaIva() / 100.0);
            neto = redondear(total / divisor);
            iva = redondear(total - neto);
        }

        StringBuilder xml = new StringBuilder();
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
                .append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" ")
                .append("xmlns:ar=\"").append(NS).append("\">")
                .append("<soapenv:Header/><soapenv:Body>")
                .append("<ar:FECAESolicitar>")
                .append(authXml(auth))
                .append("<ar:FeCAEReq>")
                .append("<ar:FeCabReq>")
                .append("<ar:CantReg>1</ar:CantReg>")
                .append("<ar:PtoVta>").append(comprobante.puntoVenta()).append("</ar:PtoVta>")
                .append("<ar:CbteTipo>").append(comprobante.tipoComprobante()).append("</ar:CbteTipo>")
                .append("</ar:FeCabReq>")
                .append("<ar:FeDetReq>")
                .append("<ar:FECAEDetRequest>")
                .append("<ar:Concepto>1</ar:Concepto>")
                .append("<ar:DocTipo>").append(comprobante.docTipo()).append("</ar:DocTipo>")
                .append("<ar:DocNro>").append(comprobante.docNro()).append("</ar:DocNro>")
                .append("<ar:CbteDesde>").append(comprobante.numero()).append("</ar:CbteDesde>")
                .append("<ar:CbteHasta>").append(comprobante.numero()).append("</ar:CbteHasta>")
                .append("<ar:CbteFch>").append(comprobante.fecha().format(FORMATO_FECHA)).append("</ar:CbteFch>")
                .append("<ar:ImpTotal>").append(formatear(total)).append("</ar:ImpTotal>")
                .append("<ar:ImpTotConc>0.00</ar:ImpTotConc>")
                .append("<ar:ImpNeto>").append(formatear(neto)).append("</ar:ImpNeto>")
                .append("<ar:ImpOpEx>0.00</ar:ImpOpEx>")
                .append("<ar:ImpTrib>0.00</ar:ImpTrib>")
                .append("<ar:ImpIVA>").append(formatear(iva)).append("</ar:ImpIVA>");

        // AFIP exige MonId aunque el comprobante sea en pesos (error 10037 si falta).
        // Se normaliza el código ISO (ARS/USD/EUR…) al código AFIP (PES/DOL/060…).
        String moneda = MonedasAfip.codigoAfip(comprobante.moneda());
        double cotizacion = comprobante.cotizacion() <= 0 ? 1.0 : comprobante.cotizacion();
        xml.append("<ar:MonId>").append(SoapSupport.escapar(moneda)).append("</ar:MonId>")
                .append("<ar:MonCotiz>").append(formatear(cotizacion)).append("</ar:MonCotiz>");

        // Obligatorio desde la RG 5616 (abril 2025): condición IVA del receptor.
        if (comprobante.condicionIvaReceptor() > 0) {
            xml.append("<ar:CondicionIVAReceptorId>")
                    .append(comprobante.condicionIvaReceptor())
                    .append("</ar:CondicionIVAReceptorId>");
        }

        if (iva > 0 && idIva > 0) {
            xml.append("<ar:Iva><ar:AlicIva>")
                    .append("<ar:Id>").append(idIva).append("</ar:Id>")
                    .append("<ar:BaseImp>").append(formatear(neto)).append("</ar:BaseImp>")
                    .append("<ar:Importe>").append(formatear(iva)).append("</ar:Importe>")
                    .append("</ar:AlicIva></ar:Iva>");
        }

        xml.append("</ar:FECAEDetRequest>")
                .append("</ar:FeDetReq>")
                .append("</ar:FeCAEReq>")
                .append("</ar:FECAESolicitar>")
                .append("</soapenv:Body></soapenv:Envelope>");

        return xml.toString();
    }

    private CaeResultado parsearCae(Document document, ComprobanteAfip comprobante) {
        Element resultado = SoapSupport.primerElemento(document.getDocumentElement(), "FECAESolicitarResult");
        if (resultado == null) {
            throw new AfipException("WSFEv1 no devolvió FECAESolicitarResult.");
        }

        List<String> errores = SoapSupport.leerMensajes(SoapSupport.hijo(resultado, "Errors"), "Err");
        List<String> eventos = SoapSupport.leerMensajes(SoapSupport.hijo(resultado, "Events"), "Evt");

        Element cabecera = SoapSupport.hijo(resultado, "FeCabResp");
        Element detalle = SoapSupport.primerElemento(resultado, "FECAEDetResponse");

        String resultadoCab = SoapSupport.texto(cabecera, "Resultado");
        String resultadoDet = SoapSupport.texto(detalle, "Resultado");
        String estado = resultadoDet != null && !resultadoDet.isBlank() ? resultadoDet : resultadoCab;

        String cae = SoapSupport.texto(detalle, "CAE");
        String caeVto = SoapSupport.texto(detalle, "CAEFchVto");
        List<String> observaciones = SoapSupport.leerMensajes(
                SoapSupport.hijo(detalle, "Observaciones"), "Obs");

        if (errores.isEmpty() && detalle != null) {
            errores = SoapSupport.leerMensajes(SoapSupport.hijo(detalle, "Errors"), "Err");
        }

        boolean aprobado = "A".equalsIgnoreCase(estado) && cae != null && !cae.isBlank();
        LocalDate vencimiento = parsearFecha(caeVto);
        String modo = properties.getModo() == null ? "DESCONOCIDO" : properties.getModo().name();

        if (aprobado) {
            log.info("WSFEv1: comprobante autorizado ptoVta={} tipo={} nro={} CAE={} vto={}",
                    comprobante.puntoVenta(), comprobante.tipoComprobante(),
                    comprobante.numero(), cae, vencimiento);
            return new CaeResultado(true, estado, cae, vencimiento, comprobante.numero(),
                    comprobante.tipoComprobante(), modo, observaciones, errores, eventos);
        }

        if (errores.isEmpty() && observaciones.isEmpty()) {
            errores = List.of("AFIP no autorizó el comprobante (resultado: " + estado + ").");
        }
        return new CaeResultado(false, estado, null, null, comprobante.numero(),
                comprobante.tipoComprobante(), modo, observaciones, errores, eventos);
    }

    /** {@code FEParamGetTiposMonedas}: catálogo de monedas habilitadas por AFIP. */
    public List<MonedaAfip> tiposMonedas(AfipAuth auth) {
        String envelope = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:ar=\"" + NS + "\">"
                + "<soapenv:Header/><soapenv:Body>"
                + "<ar:FEParamGetTiposMonedas>" + authXml(auth) + "</ar:FEParamGetTiposMonedas>"
                + "</soapenv:Body></soapenv:Envelope>";

        Document document = enviarYParsear(envelope, ACCION_MONEDAS);
        Element resultado = SoapSupport.primerElemento(
                document.getDocumentElement(), "FEParamGetTiposMonedasResult");
        if (resultado == null) {
            throw new AfipException("WSFEv1 no devolvió FEParamGetTiposMonedasResult.");
        }

        List<String> errores = SoapSupport.leerMensajes(SoapSupport.hijo(resultado, "Errors"), "Err");
        if (!errores.isEmpty()) {
            throw new AfipException("AFIP rechazó la consulta de monedas: " + String.join(" | ", errores));
        }

        List<MonedaAfip> monedas = new java.util.ArrayList<>();
        Element array = SoapSupport.hijo(resultado, "ResultGet");
        for (Element moneda : SoapSupport.elementos(array, "Moneda")) {
            String id = SoapSupport.texto(moneda, "Id");
            if (id == null || id.isBlank()) {
                continue;
            }
            monedas.add(new MonedaAfip(
                    id.trim(),
                    SoapSupport.texto(moneda, "Desc"),
                    SoapSupport.texto(moneda, "FchDesde"),
                    SoapSupport.texto(moneda, "FchHasta")));
        }
        log.info("WSFEv1: FEParamGetTiposMonedas devolvió {} monedas", monedas.size());
        return monedas;
    }

    /** {@code FEParamGetCotizacion}: cotización oficial de una moneda para una fecha. */
    public Double cotizacion(AfipAuth auth, String monId, LocalDate fecha) {
        String fchCotiz = fecha == null ? "" : fecha.format(FORMATO_FECHA);
        String envelope = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:ar=\"" + NS + "\">"
                + "<soapenv:Header/><soapenv:Body>"
                + "<ar:FEParamGetCotizacion>"
                + authXml(auth)
                + "<ar:MonId>" + SoapSupport.escapar(monId) + "</ar:MonId>"
                + "<ar:FchCotiz>" + fchCotiz + "</ar:FchCotiz>"
                + "</ar:FEParamGetCotizacion>"
                + "</soapenv:Body></soapenv:Envelope>";

        Document document = enviarYParsear(envelope, ACCION_COTIZACION);
        Element resultado = SoapSupport.primerElemento(
                document.getDocumentElement(), "FEParamGetCotizacionResult");
        if (resultado == null) {
            return null;
        }
        List<String> errores = SoapSupport.leerMensajes(SoapSupport.hijo(resultado, "Errors"), "Err");
        Element cotizacion = SoapSupport.hijo(resultado, "ResultGet");
        if (!errores.isEmpty() || cotizacion == null) {
            return null;
        }
        double valor = SoapSupport.decimal(cotizacion, "MonCotiz", 0);
        return valor > 0 ? valor : null;
    }

    private Document enviarYParsear(String envelope, String accion) {
        String respuesta = SoapSupport.enviar(
                properties.getWsfeUrl(), envelope, accion, properties.getTimeoutMs());
        Document document = SoapSupport.parsear(respuesta);
        SoapSupport.lanzarSiFault(document);
        return document;
    }

    private String authXml(AfipAuth auth) {
        return "<ar:Auth>"
                + "<ar:Token>" + SoapSupport.escapar(auth.token()) + "</ar:Token>"
                + "<ar:Sign>" + SoapSupport.escapar(auth.sign()) + "</ar:Sign>"
                + "<ar:Cuit>" + auth.cuit() + "</ar:Cuit>"
                + "</ar:Auth>";
    }

    private int idAlicuota(double alicuota) {
        if (Math.abs(alicuota - 21.0) < 0.01) return 5;
        if (Math.abs(alicuota - 10.5) < 0.01) return 4;
        if (Math.abs(alicuota - 27.0) < 0.01) return 6;
        if (Math.abs(alicuota - 5.0) < 0.01) return 8;
        if (Math.abs(alicuota - 2.5) < 0.01) return 9;
        return alicuota > 0 ? 5 : 0;
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    private static String formatear(double valor) {
        return String.format(Locale.US, "%.2f", valor);
    }

    private static LocalDate parsearFecha(String valor) {
        if (valor == null || valor.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(valor, FORMATO_FECHA);
        } catch (Exception e) {
            return null;
        }
    }
}
