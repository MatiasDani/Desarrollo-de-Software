package com.ejemplo.afip.client;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * Par clave privada + certificado X.509 usado para firmar el TRA de WSAA.
 */
public record AfipCredentials(PrivateKey clavePrivada, X509Certificate certificado) {
}
