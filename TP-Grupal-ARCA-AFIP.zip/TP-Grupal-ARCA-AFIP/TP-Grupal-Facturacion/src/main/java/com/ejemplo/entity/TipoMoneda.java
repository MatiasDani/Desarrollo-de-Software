package com.ejemplo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "tipo_moneda")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class TipoMoneda extends EntityId {

    /** Código ISO 4217 usado para mostrar importes (ARS, USD, EUR…). */
    @Column(nullable = false)
    private String codigo;

    /** Identificador que exige WSFEv1 en el campo MonId (PES, DOL, 060…). */
    @Column(name = "codigo_afip")
    private String codigoAfip;

    @Column(nullable = false)
    private String denominacion;

    private double cotizacion;
}
