package com.ejemplo.controller;

import com.ejemplo.afip.AfipService;
import com.ejemplo.afip.client.AfipWsaaClient;
import com.ejemplo.afip.dto.AfipConexionDTO;
import com.ejemplo.afip.dto.AfipEstadoDTO;
import com.ejemplo.afip.dto.MonedasSyncDTO;
import com.ejemplo.dto.CatalogoDTO;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/afip")
public class AfipController {

    private final AfipService afipService;
    private final AfipWsaaClient wsaaClient;

    public AfipController(AfipService afipService, AfipWsaaClient wsaaClient) {
        this.afipService = afipService;
        this.wsaaClient = wsaaClient;
    }

    @GetMapping("/estado")
    public AfipEstadoDTO estado() {
        return afipService.estado();
    }

    @PostMapping("/dummy")
    public AfipConexionDTO probarConexion() {
        return afipService.probarConexion();
    }

    @DeleteMapping("/cache")
    public Map<String, String> limpiarCache() {
        wsaaClient.limpiarCache();
        return Map.of("message",
                "Caché en memoria invalidada. Se reutilizará el TA guardado en disco hasta su vencimiento.");
    }

    /** Catálogo local de monedas (ISO + código AFIP). */
    @GetMapping("/monedas")
    public List<CatalogoDTO.MonedaItem> monedas() {
        return afipService.monedas();
    }

    /** Refresca el catálogo de monedas con FEParamGetTiposMonedas de AFIP. */
    @PostMapping("/monedas/sincronizar")
    public MonedasSyncDTO sincronizarMonedas() {
        return afipService.sincronizarMonedas();
    }
}
