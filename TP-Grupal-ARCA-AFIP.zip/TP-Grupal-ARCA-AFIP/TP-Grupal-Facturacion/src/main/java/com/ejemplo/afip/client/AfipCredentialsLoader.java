package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipException;
import com.ejemplo.afip.AfipProperties;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Enumeration;

/**
 * Carga las credenciales desde un PFX/PKCS#12 o desde un par de archivos PEM.
 *
 * <p>Se admiten rutas de sistema de archivos y recursos tipo
 * {@code classpath:} o {@code file:}.</p>
 */
@Component
public class AfipCredentialsLoader {

    private static final String BC = BouncyCastleProvider.PROVIDER_NAME;

    private final AfipProperties properties;
    private final ResourceLoader resourceLoader;

    public AfipCredentialsLoader(AfipProperties properties, ResourceLoader resourceLoader) {
        this.properties = properties;
        this.resourceLoader = resourceLoader;
        registrarProveedor();
    }

    public AfipCredentials cargar() {
        try {
            if (tieneTexto(properties.getPfxPath())) {
                return cargarPfx();
            }
            if (tieneTexto(properties.getCertificadoPath()) && tieneTexto(properties.getClavePath())) {
                return cargarPem();
            }
            throw new AfipException(
                    "No hay credenciales AFIP configuradas. Definí afip.pfx-path o bien " +
                            "afip.certificado-path + afip.clave-path en application.properties.");
        } catch (AfipException e) {
            throw e;
        } catch (Exception e) {
            throw new AfipException("No se pudieron cargar las credenciales AFIP: " + e.getMessage(), e);
        }
    }

    private AfipCredentials cargarPfx() throws Exception {
        char[] password = properties.getPfxPassword() == null
                ? new char[0]
                : properties.getPfxPassword().toCharArray();

        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        try (InputStream in = abrir(properties.getPfxPath())) {
            keyStore.load(in, password);
        }

        String alias = null;
        Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            String actual = aliases.nextElement();
            if (keyStore.isKeyEntry(actual)) {
                alias = actual;
                break;
            }
        }
        if (alias == null) {
            throw new AfipException("El archivo PFX no contiene ninguna clave privada.");
        }

        PrivateKey clave = (PrivateKey) keyStore.getKey(alias, password);
        Certificate certificado = keyStore.getCertificate(alias);
        if (!(certificado instanceof X509Certificate x509)) {
            throw new AfipException("El archivo PFX no contiene un certificado X.509 válido.");
        }
        return new AfipCredentials(clave, x509);
    }

    private AfipCredentials cargarPem() throws Exception {
        byte[] claveBytes;
        try (InputStream in = abrir(properties.getClavePath())) {
            claveBytes = in.readAllBytes();
        }

        X509Certificate certificado;
        try (InputStream in = abrir(properties.getCertificadoPath())) {
            certificado = (X509Certificate) CertificateFactory.getInstance("X.509")
                    .generateCertificate(in);
        }

        return new AfipCredentials(leerClavePrivada(claveBytes), certificado);
    }

    private PrivateKey leerClavePrivada(byte[] contenido) throws Exception {
        String pem = new String(contenido, StandardCharsets.UTF_8);

        // Primer intento: PKCS#8 ("BEGIN PRIVATE KEY")
        try {
            String limpio = pem
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s", "");
            byte[] der = Base64.getDecoder().decode(limpio);
            return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der));
        } catch (Exception ignored) {
            // Puede ser una clave PKCS#1 ("BEGIN RSA PRIVATE KEY"); se intenta con BouncyCastle.
        }

        try (PEMParser parser = new PEMParser(new StringReader(pem))) {
            Object objeto = parser.readObject();
            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider(BC);
            if (objeto instanceof PEMKeyPair keyPair) {
                return converter.getKeyPair(keyPair).getPrivate();
            }
            if (objeto instanceof org.bouncycastle.asn1.pkcs.PrivateKeyInfo privateKeyInfo) {
                return converter.getPrivateKey(privateKeyInfo);
            }
        }

        throw new AfipException("Formato de clave privada no reconocido. Usá PEM PKCS#8 o PKCS#1, o un PFX.");
    }

    private InputStream abrir(String ubicacion) throws IOException {
        if (ubicacion.startsWith("classpath:") || ubicacion.startsWith("file:") || ubicacion.startsWith("http")) {
            return resourceLoader.getResource(ubicacion).getInputStream();
        }
        Path path = Paths.get(ubicacion);
        if (!Files.exists(path)) {
            throw new AfipException("No se encontró el archivo de credenciales: " + ubicacion);
        }
        return Files.newInputStream(path);
    }

    private static boolean tieneTexto(String valor) {
        return valor != null && !valor.isBlank();
    }

    private static void registrarProveedor() {
        if (Security.getProvider(BC) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }
}
