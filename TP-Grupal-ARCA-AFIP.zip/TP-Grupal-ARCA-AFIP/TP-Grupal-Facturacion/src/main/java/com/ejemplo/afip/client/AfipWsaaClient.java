package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipException;
import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.model.AfipAuth;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.nio.charset.StandardCharsets;
import java.security.Security;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Cliente WSAA (Web Service de Autenticación y Autorización).
 *
 * <p>Genera el TRA, lo firma con PKCS#7/CMS usando BouncyCastle y llama al
 * endpoint {@code LoginCms} para obtener el Token y Sign que luego consume
 * WSFEv1. El ticket se cachea hasta pocos minutos antes de su vencimiento.</p>
 */
@Component
public class AfipWsaaClient {

    private static final Logger log = LoggerFactory.getLogger(AfipWsaaClient.class);
    private static final String BC = BouncyCastleProvider.PROVIDER_NAME;
    private static final DateTimeFormatter FORMATO_AFIP = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
    private static final ZoneId ZONA_AR = ZoneId.of("America/Argentina/Buenos_Aires");

    private final AfipProperties properties;
    private final AfipCredentialsLoader credentialsLoader;
    private final AtomicLong ultimoUniqueId = new AtomicLong();

    private volatile AfipAuth cache;

    public AfipWsaaClient(AfipProperties properties, AfipCredentialsLoader credentialsLoader) {
        this.properties = properties;
        this.credentialsLoader = credentialsLoader;
    }

    public AfipAuth obtenerAuth() {
        AfipAuth actual = cache;
        if (actual != null && actual.vencimiento().isAfter(LocalDateTime.now().plusMinutes(2))) {
            return actual;
        }

        synchronized (this) {
            actual = cache;
            if (actual != null && actual.vencimiento().isAfter(LocalDateTime.now().plusMinutes(2))) {
                return actual;
            }
            actual = leerTaGuardado();
            if (actual != null && actual.vencimiento().isAfter(LocalDateTime.now().plusMinutes(2))) {
                cache = actual;
                return actual;
            }
            AfipAuth nuevo = solicitarTicket();
            cache = nuevo;
            return nuevo;
        }
    }

    public void limpiarCache() {
        cache = null;
    }

    private AfipAuth solicitarTicket() {
        long cuit = cuitEmisor();
        AfipCredentials credenciales = credentialsLoader.cargar();
        String tra = construirTra();
        String cms = firmarTra(tra, credenciales);
        String respuesta = SoapSupport.enviar(
                properties.getWsaaUrl(),
                construirEnvelope(cms),
                "",
                properties.getTimeoutMs());

        Document document = SoapSupport.parsear(respuesta);
        SoapSupport.lanzarSiFault(document);

        Element loginReturn = SoapSupport.primerElemento(document.getDocumentElement(), "loginCmsReturn");
        if (loginReturn == null) {
            throw new AfipException("WSAA no devolvió el nodo loginCmsReturn. Respuesta: " + respuesta);
        }

        String xmlTicket = loginReturn.getTextContent();
        if (xmlTicket == null || xmlTicket.isBlank()) {
            throw new AfipException("WSAA devolvió una respuesta vacía.");
        }
        if (xmlTicket.contains("&lt;")) {
            xmlTicket = SoapSupport.desescaparXml(xmlTicket);
        }

        AfipAuth auth = parsearTicket(xmlTicket);
        guardarTa(xmlTicket);
        log.info("WSAA: ticket obtenido para CUIT {} (vence {})", auth.cuit(), auth.vencimiento());
        return auth;
    }

    private AfipAuth parsearTicket(String xmlTicket) {
        Document ticket = SoapSupport.parsear(xmlTicket);
        Element raiz = ticket.getDocumentElement();
        Element credenciales = SoapSupport.primerElemento(raiz, "credentials");
        Element cabecera = SoapSupport.primerElemento(raiz, "header");
        String token = credenciales == null ? null : SoapSupport.texto(credenciales, "token");
        String sign = credenciales == null ? null : SoapSupport.texto(credenciales, "sign");
        String expiration = cabecera == null ? null : SoapSupport.texto(cabecera, "expirationTime");

        if (token == null || token.isBlank() || sign == null || sign.isBlank()) {
            throw new AfipException("WSAA no devolvió Token/Sign válidos.");
        }

        return new AfipAuth(token, sign, cuitEmisor(), parsearVencimiento(expiration));
    }

    /**
     * Reutiliza el Ticket de Acceso guardado en disco. AFIP rechaza pedir un
     * TA nuevo mientras el anterior siga vigente para el mismo certificado.
     */
    private AfipAuth leerTaGuardado() {
        try {
            java.nio.file.Path ruta = rutaTa();
            if (!java.nio.file.Files.exists(ruta)) {
                return null;
            }
            String xml = java.nio.file.Files.readString(ruta, StandardCharsets.UTF_8);
            AfipAuth auth = parsearTicket(xml);
            if (auth.vencimiento().isAfter(LocalDateTime.now().plusMinutes(2))) {
                log.info("WSAA: reutilizando TA guardado (vence {})", auth.vencimiento());
                return auth;
            }
            log.info("WSAA: el TA guardado venció el {}; se solicita uno nuevo", auth.vencimiento());
        } catch (Exception e) {
            log.warn("WSAA: no se pudo leer el TA guardado ({}); se solicita uno nuevo", e.getMessage());
        }
        return null;
    }

    private void guardarTa(String xmlTicket) {
        try {
            java.nio.file.Path ruta = rutaTa();
            if (ruta.getParent() != null) {
                java.nio.file.Files.createDirectories(ruta.getParent());
            }
            java.nio.file.Files.writeString(ruta, xmlTicket, StandardCharsets.UTF_8);
            log.info("WSAA: TA guardado en {}", ruta.toAbsolutePath());
        } catch (Exception e) {
            log.warn("WSAA: no se pudo guardar el TA en {}: {}", properties.getTaPath(), e.getMessage());
        }
    }

    private java.nio.file.Path rutaTa() {
        String configurada = properties.getTaPath();
        if (configurada == null || configurada.isBlank()) {
            configurada = "ta_wsfe.xml";
        }
        return java.nio.file.Paths.get(configurada);
    }

    private String construirTra() {
        ZonedDateTime ahora = ZonedDateTime.now(ZONA_AR);
        long uniqueId = Math.max(ahora.toEpochSecond(), ultimoUniqueId.incrementAndGet());

        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<loginTicketRequest version=\"1.0\">"
                + "<header>"
                + "<uniqueId>" + uniqueId + "</uniqueId>"
                + "<generationTime>" + ahora.minusMinutes(5).format(FORMATO_AFIP) + "</generationTime>"
                + "<expirationTime>" + ahora.plusMinutes(10).format(FORMATO_AFIP) + "</expirationTime>"
                + "</header>"
                + "<service>wsfe</service>"
                + "</loginTicketRequest>";
    }

    private String firmarTra(String tra, AfipCredentials credenciales) {
        try {
            if (Security.getProvider(BC) == null) {
                Security.addProvider(new BouncyCastleProvider());
            }

            CMSSignedDataGenerator generador = new CMSSignedDataGenerator();
            ContentSigner firmante = new JcaContentSignerBuilder("SHA256withRSA")
                    .setProvider(BC)
                    .build(credenciales.clavePrivada());

            generador.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(
                    new JcaDigestCalculatorProviderBuilder().setProvider(BC).build())
                    .build(firmante, credenciales.certificado()));

            generador.addCertificates(new JcaCertStore(Collections.singletonList(credenciales.certificado())));

            CMSSignedData firmado = generador.generate(
                    new CMSProcessableByteArray(tra.getBytes(StandardCharsets.UTF_8)), true);

            return Base64.getEncoder().encodeToString(firmado.getEncoded());
        } catch (Exception e) {
            throw new AfipException("No se pudo firmar el TRA con PKCS#7/CMS: " + e.getMessage(), e);
        }
    }

    private String construirEnvelope(String cmsBase64) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:nso=\"http://wsaa.afip.gov.ar/ws/services/LoginCms\">"
                + "<soapenv:Header/>"
                + "<soapenv:Body>"
                + "<nso:loginCms>"
                + "<nso:in0>" + cmsBase64 + "</nso:in0>"
                + "</nso:loginCms>"
                + "</soapenv:Body>"
                + "</soapenv:Envelope>";
    }

    private LocalDateTime parsearVencimiento(String expiration) {
        if (expiration == null || expiration.isBlank()) {
            return LocalDateTime.now().plusHours(10);
        }
        try {
            // Se normaliza a la zona de la máquina para poder comparar contra
            // LocalDateTime.now() sin importar dónde se ejecute la app.
            return OffsetDateTime.parse(expiration)
                    .atZoneSameInstant(ZoneId.systemDefault())
                    .toLocalDateTime();
        } catch (Exception ignorado) {
            try {
                return LocalDateTime.parse(expiration);
            } catch (Exception e) {
                return LocalDateTime.now().plusHours(10);
            }
        }
    }

    private long cuitEmisor() {
        String cuit = properties.cuitNormalizado();
        if (cuit == null || cuit.length() != 11) {
            throw new AfipException("Configurá un CUIT válido de 11 dígitos en afip.cuit.");
        }
        return Long.parseLong(cuit);
    }
}
