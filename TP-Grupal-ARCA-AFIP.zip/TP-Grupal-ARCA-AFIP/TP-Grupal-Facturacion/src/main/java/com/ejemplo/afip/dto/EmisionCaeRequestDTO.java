package com.ejemplo.afip.dto;

/**
 * Permite indicar el tipo de comprobante al momento de pedir el CAE.
 * Si es null se usa el tipo guardado en la factura o el default configurado.
 */
public record EmisionCaeRequestDTO(Integer tipoComprobante) {
}
