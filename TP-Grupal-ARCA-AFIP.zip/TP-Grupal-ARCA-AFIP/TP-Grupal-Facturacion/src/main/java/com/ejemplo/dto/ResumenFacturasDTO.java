package com.ejemplo.dto;

import java.util.List;

/**
 * Totales del panel de control.
 *
 * <p>Se calculan con consultas de agregación ({@code COUNT}/{@code SUM}) en la
 * base de datos, de modo que el panel no necesita descargar el listado completo
 * de comprobantes: la respuesta tiene siempre el mismo tamaño, haya 100 o 100
 * millones de facturas.</p>
 *
 * @param importeVigente suma de {@code importeTotal} de las facturas no anuladas.
 * @param vigentes       cantidad de facturas no anuladas.
 * @param conCae         facturas vigentes que ya tienen CAE.
 * @param pendientes     facturas vigentes sin CAE.
 * @param anuladas       cantidad de facturas anuladas.
 * @param ultimas        las últimas facturas cargadas (de la más nueva a la más vieja).
 */
public record ResumenFacturasDTO(
        double importeVigente,
        long vigentes,
        long conCae,
        long pendientes,
        long anuladas,
        List<FacturaReporteDTO> ultimas) {
}
