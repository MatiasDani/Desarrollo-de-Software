package com.ejemplo.dto;

import java.util.List;

/**
 * Envoltorio genérico para respuestas paginadas.
 *
 * <p>Se usa en el listado de comprobantes para no traer todas las facturas de
 * una sola vez. Los nombres de los campos son neutros y estables para que el
 * frontend no dependa del formato interno de Spring Data.</p>
 *
 * @param contenido      los elementos de la página solicitada.
 * @param pagina         número de página devuelto (base 0).
 * @param tamanio        cantidad de elementos por página.
 * @param totalElementos total de elementos que cumplen el filtro.
 * @param totalPaginas   cantidad total de páginas.
 * @param primera        {@code true} si es la primera página.
 * @param ultima         {@code true} si es la última página.
 */
public record PaginaDTO<T>(
        List<T> contenido,
        int pagina,
        int tamanio,
        long totalElementos,
        int totalPaginas,
        boolean primera,
        boolean ultima) {
}
