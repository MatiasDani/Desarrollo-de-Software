package com.ejemplo.afip.dto;

import com.ejemplo.afip.model.EstadoServidores;

/**
 * Resultado del diagnóstico FEDummy.
 */
public record AfipConexionDTO(boolean ok, String modo, EstadoServidores servidores, String mensaje) {
}
