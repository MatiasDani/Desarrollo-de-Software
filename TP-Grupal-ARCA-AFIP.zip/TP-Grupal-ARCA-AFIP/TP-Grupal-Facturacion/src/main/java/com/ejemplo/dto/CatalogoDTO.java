package com.ejemplo.dto;

import java.util.List;

/**
 * Catálogos usados por el frontend para reemplazar los inputs de IDs por
 * selects amigables.
 */
public record CatalogoDTO(
        List<PuntoVentaItem> puntosVenta,
        List<ClienteItem> clientes,
        List<CondicionIvaItem> condicionesIva,
        List<MonedaItem> tiposMoneda,
        List<ArticuloItem> articulos
) {
    public record PuntoVentaItem(Long id, int numero, String descripcion, String domicilio) {
    }

    public record ClienteItem(Long id, String denominacion, String cuit, String email,
                              Long condicionIvaId, String condicionIva) {
    }

    public record CondicionIvaItem(Long id, int codigo, String denominacion) {
    }

    public record MonedaItem(Long id, String codigo, String codigoAfip, String denominacion, double cotizacion) {
    }

    public record ArticuloItem(Long id, String codigo, String denominacion, double precioVenta) {
    }
}
