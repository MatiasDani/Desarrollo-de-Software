package com.ejemplo.controller;

import com.ejemplo.dto.CatalogoDTO;
import com.ejemplo.repository.ArticuloRepository;
import com.ejemplo.repository.ClienteRepository;
import com.ejemplo.repository.CondicionIvaRepository;
import com.ejemplo.repository.PuntoVentaRepository;
import com.ejemplo.repository.TipoMonedaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/catalogos")
public class CatalogoController {

    private final PuntoVentaRepository puntoVentaRepository;
    private final ClienteRepository clienteRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final ArticuloRepository articuloRepository;

    public CatalogoController(PuntoVentaRepository puntoVentaRepository,
                              ClienteRepository clienteRepository,
                              CondicionIvaRepository condicionIvaRepository,
                              TipoMonedaRepository tipoMonedaRepository,
                              ArticuloRepository articuloRepository) {
        this.puntoVentaRepository = puntoVentaRepository;
        this.clienteRepository = clienteRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.articuloRepository = articuloRepository;
    }

    @GetMapping
    public CatalogoDTO obtenerCatalogos() {
        return new CatalogoDTO(
                puntoVentaRepository.findAll().stream()
                        .map(pv -> new CatalogoDTO.PuntoVentaItem(
                                pv.getId(), pv.getNumero(), pv.getDescripcion(), pv.getDomicilio()))
                        .toList(),
                clienteRepository.findAll().stream()
                        .map(c -> new CatalogoDTO.ClienteItem(
                                c.getId(),
                                c.getDenominacion(),
                                c.getCuit(),
                                c.getEmail(),
                                c.getCondicionIva() == null ? null : c.getCondicionIva().getId(),
                                c.getCondicionIva() == null ? null : c.getCondicionIva().getDenominacion()))
                        .toList(),
                condicionIvaRepository.findAll().stream()
                        .map(ci -> new CatalogoDTO.CondicionIvaItem(
                                ci.getId(), ci.getCodigo(), ci.getDenominacion()))
                        .toList(),
                tipoMonedaRepository.findAll().stream()
                        .map(tm -> new CatalogoDTO.MonedaItem(
                                tm.getId(), tm.getCodigo(), tm.getCodigoAfip(),
                                tm.getDenominacion(), tm.getCotizacion()))
                        .toList(),
                articuloRepository.findAll().stream()
                        .map(a -> new CatalogoDTO.ArticuloItem(
                                a.getId(), a.getCodigo(), a.getDenominacion(), a.getPrecioVenta()))
                        .toList());
    }
}
