package com.ejemplo.afip.model;

/**
 * Estado devuelto por {@code FEDummy}.
 */
public record EstadoServidores(String appServer, String dbServer, String authServer) {

    public boolean todoOk() {
        return "OK".equalsIgnoreCase(appServer)
                && "OK".equalsIgnoreCase(dbServer)
                && "OK".equalsIgnoreCase(authServer);
    }
}
