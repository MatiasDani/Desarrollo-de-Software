package com.ejemplo.afip.client;

import com.ejemplo.afip.AfipException;
import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.MonedasAfip;
import com.ejemplo.afip.model.AfipAuth;
import com.ejemplo.afip.model.CaeResultado;
import com.ejemplo.afip.model.ComprobanteAfip;
import com.ejemplo.afip.model.EstadoServidores;
import com.ejemplo.afip.model.MonedaAfip;
import com.ejemplo.afip.model.UltimoComprobante;
import com.ejemplo.afip.wsfe.AlicIva;
import com.ejemplo.afip.wsfe.ArrayOfAlicIva;
import com.ejemplo.afip.wsfe.ArrayOfErr;
import com.ejemplo.afip.wsfe.ArrayOfEvt;
import com.ejemplo.afip.wsfe.ArrayOfFECAEDetRequest;
import com.ejemplo.afip.wsfe.ArrayOfFECAEDetResponse;
import com.ejemplo.afip.wsfe.ArrayOfMoneda;
import com.ejemplo.afip.wsfe.ArrayOfObs;
import com.ejemplo.afip.wsfe.Cotizacion;
import com.ejemplo.afip.wsfe.DummyResponse;
import com.ejemplo.afip.wsfe.Err;
import com.ejemplo.afip.wsfe.Evt;
import com.ejemplo.afip.wsfe.FECAERequest;
import com.ejemplo.afip.wsfe.FECAEResponse;
import com.ejemplo.afip.wsfe.FECAEDetRequest;
import com.ejemplo.afip.wsfe.FECAEDetResponse;
import com.ejemplo.afip.wsfe.FECAECabRequest;
import com.ejemplo.afip.wsfe.FEAuthRequest;
import com.ejemplo.afip.wsfe.FECotizacionResponse;
import com.ejemplo.afip.wsfe.FERecuperaLastCbteResponse;
import com.ejemplo.afip.wsfe.Moneda;
import com.ejemplo.afip.wsfe.MonedaResponse;
import com.ejemplo.afip.wsfe.Obs;
import com.ejemplo.afip.wsfe.Service;
import com.ejemplo.afip.wsfe.ServiceSoap;
import com.sun.xml.ws.developer.JAXWSProperties;
import jakarta.xml.ws.BindingProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Cliente WSFEv1 basado en los stubs JAX-WS generados con XML-WS Tools
 * (paquete {@code com.ejemplo.afip.wsfe}) a partir del WSDL oficial de
 * {@code wsfev1/service.asmx}.
 *
 * <p>A diferencia del cliente SOAP armado a mano, acá el marshalling/unmarshalling
 * lo hace JAXB y la invocación la resuelve el runtime de JAX-WS ({@code jaxws-rt}).
 * Se usan las operaciones {@code FEDummy}, {@code FECompUltimoAutorizado},
 * {@code FECAESolicitar}, {@code FEParamGetTiposMonedas} y
 * {@code FEParamGetCotizacion}.</p>
 */
@Component
public class AfipWsfeJaxwsClient {

    private static final Logger log = LoggerFactory.getLogger(AfipWsfeJaxwsClient.class);
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("yyyyMMdd");

    private final AfipProperties properties;
    private final Object candado = new Object();

    /** Puerto JAX-WS cacheado; se crea la primera vez que se invoca una operación. */
    private volatile ServiceSoap puerto;

    public AfipWsfeJaxwsClient(AfipProperties properties) {
        this.properties = properties;
    }

    // ------------------------------------------------------------------
    // Operaciones WSFEv1
    // ------------------------------------------------------------------

    public EstadoServidores dummy() {
        try {
            DummyResponse respuesta = puerto().feDummy();
            return new EstadoServidores(
                    respuesta.getAppServer(),
                    respuesta.getDbServer(),
                    respuesta.getAuthServer());
        } catch (AfipException e) {
            throw e;
        } catch (RuntimeException e) {
            throw error("FEDummy", e);
        }
    }

    public UltimoComprobante ultimoComprobante(AfipAuth auth, int puntoVenta, int tipoComprobante) {
        try {
            FERecuperaLastCbteResponse respuesta =
                    puerto().feCompUltimoAutorizado(auth(auth), puntoVenta, tipoComprobante);

            List<String> errores = mensajes(respuesta.getErrors());
            List<String> eventos = eventos(respuesta.getEvents());
            long numero = respuesta.getCbteNro();

            if (!errores.isEmpty()) {
                throw new AfipException("AFIP rechazó la consulta del último comprobante: "
                        + String.join(" | ", errores));
            }

            log.info("WSFEv1 (JAX-WS): último comprobante ptoVta={} tipo={} => {}",
                    puntoVenta, tipoComprobante, numero);
            return new UltimoComprobante(numero, errores, eventos);
        } catch (AfipException e) {
            throw e;
        } catch (RuntimeException e) {
            throw error("FECompUltimoAutorizado", e);
        }
    }

    public CaeResultado solicitarCae(AfipAuth auth, ComprobanteAfip comprobante) {
        try {
            FECAEResponse respuesta = puerto().fecaeSolicitar(auth(auth), construirRequest(comprobante));
            return interpretarCae(respuesta, comprobante);
        } catch (AfipException e) {
            throw e;
        } catch (RuntimeException e) {
            throw error("FECAESolicitar", e);
        }
    }

    /** {@code FEParamGetTiposMonedas}: catálogo de monedas habilitadas por AFIP. */
    public List<MonedaAfip> tiposMonedas(AfipAuth auth) {
        try {
            MonedaResponse respuesta = puerto().feParamGetTiposMonedas(auth(auth));
            List<String> errores = mensajes(respuesta.getErrors());
            if (!errores.isEmpty()) {
                throw new AfipException("AFIP rechazó la consulta de monedas: "
                        + String.join(" | ", errores));
            }

            ArrayOfMoneda array = respuesta.getResultGet();
            List<MonedaAfip> monedas = new ArrayList<>();
            if (array != null) {
                for (Moneda moneda : array.getMoneda()) {
                    if (moneda == null || moneda.getId() == null || moneda.getId().isBlank()) {
                        continue;
                    }
                    monedas.add(new MonedaAfip(
                            moneda.getId().trim(),
                            moneda.getDesc(),
                            moneda.getFchDesde(),
                            moneda.getFchHasta()));
                }
            }

            log.info("WSFEv1 (JAX-WS): FEParamGetTiposMonedas devolvió {} monedas", monedas.size());
            return monedas;
        } catch (AfipException e) {
            throw e;
        } catch (RuntimeException e) {
            throw error("FEParamGetTiposMonedas", e);
        }
    }

    /** {@code FEParamGetCotizacion}: cotización oficial de una moneda para una fecha. */
    public Double cotizacion(AfipAuth auth, String monId, LocalDate fecha) {
        try {
            String fchCotiz = fecha == null ? null : fecha.format(FORMATO_FECHA);
            FECotizacionResponse respuesta = puerto().feParamGetCotizacion(auth(auth), monId, fchCotiz);
            List<String> errores = mensajes(respuesta.getErrors());
            if (!errores.isEmpty()) {
                log.warn("WSFEv1 (JAX-WS): sin cotización para {}: {}", monId, String.join(" | ", errores));
                return null;
            }
            Cotizacion resultado = respuesta.getResultGet();
            if (resultado == null || resultado.getMonCotiz() <= 0) {
                return null;
            }
            return resultado.getMonCotiz();
        } catch (RuntimeException e) {
            log.warn("WSFEv1 (JAX-WS): no se pudo obtener la cotización de {}: {}", monId, e.getMessage());
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Construcción del request y lectura de la respuesta
    // ------------------------------------------------------------------

    /** Arma el {@code FECAERequest} que espera {@code FECAESolicitar}. Visible para tests. */
    FECAERequest construirRequest(ComprobanteAfip comprobante) {
        double total = redondear(comprobante.importeTotal());
        double neto;
        double iva;
        int idIva = idAlicuota(comprobante.alicuotaIva());

        if (comprobante.esFacturaC() || comprobante.alicuotaIva() <= 0) {
            neto = total;
            iva = 0;
        } else {
            double divisor = 1 + (comprobante.alicuotaIva() / 100.0);
            neto = redondear(total / divisor);
            iva = redondear(total - neto);
        }

        FECAECabRequest cabecera = new FECAECabRequest();
        cabecera.setCantReg(1);
        cabecera.setPtoVta(comprobante.puntoVenta());
        cabecera.setCbteTipo(comprobante.tipoComprobante());

        FECAEDetRequest detalle = new FECAEDetRequest();
        detalle.setConcepto(1);
        detalle.setDocTipo(comprobante.docTipo());
        detalle.setDocNro(comprobante.docNro());
        detalle.setCbteDesde(comprobante.numero());
        detalle.setCbteHasta(comprobante.numero());
        detalle.setCbteFch(comprobante.fecha().format(FORMATO_FECHA));
        detalle.setImpTotal(total);
        detalle.setImpTotConc(0);
        detalle.setImpNeto(neto);
        detalle.setImpOpEx(0);
        detalle.setImpTrib(0);
        detalle.setImpIVA(iva);

        // AFIP exige MonId siempre (error 10037). Se normaliza ISO -> código AFIP.
        detalle.setMonId(MonedasAfip.codigoAfip(comprobante.moneda()));
        detalle.setMonCotiz(comprobante.cotizacion() <= 0 ? 1.0 : redondear(comprobante.cotizacion()));

        // Obligatorio desde la RG 5616 (abril 2025): condición IVA del receptor.
        if (comprobante.condicionIvaReceptor() > 0) {
            detalle.setCondicionIVAReceptorId(comprobante.condicionIvaReceptor());
        }

        if (iva > 0 && idIva > 0) {
            AlicIva alicuota = new AlicIva();
            alicuota.setId(idIva);
            alicuota.setBaseImp(neto);
            alicuota.setImporte(iva);

            ArrayOfAlicIva ivaArray = new ArrayOfAlicIva();
            ivaArray.getAlicIva().add(alicuota);
            detalle.setIva(ivaArray);
        }

        ArrayOfFECAEDetRequest detalles = new ArrayOfFECAEDetRequest();
        detalles.getFECAEDetRequest().add(detalle);

        FECAERequest request = new FECAERequest();
        request.setFeCabReq(cabecera);
        request.setFeDetReq(detalles);
        return request;
    }

    private CaeResultado interpretarCae(FECAEResponse respuesta, ComprobanteAfip comprobante) {
        List<String> errores = mensajes(respuesta.getErrors());
        List<String> eventos = eventos(respuesta.getEvents());

        FECAEDetResponse detalle = primerDetalle(respuesta);
        String resultadoCabecera = respuesta.getFeCabResp() == null
                ? null
                : respuesta.getFeCabResp().getResultado();
        String resultadoDetalle = detalle == null ? null : detalle.getResultado();
        String estado = resultadoDetalle != null && !resultadoDetalle.isBlank()
                ? resultadoDetalle
                : resultadoCabecera;

        String cae = detalle == null ? null : detalle.getCAE();
        String caeVto = detalle == null ? null : detalle.getCAEFchVto();
        List<String> observaciones = observaciones(detalle);

        boolean aprobado = "A".equalsIgnoreCase(estado) && cae != null && !cae.isBlank();
        LocalDate vencimiento = parsearFecha(caeVto);
        String modo = properties.getModo() == null ? "DESCONOCIDO" : properties.getModo().name();

        if (aprobado) {
            log.info("WSFEv1 (JAX-WS): comprobante autorizado ptoVta={} tipo={} nro={} CAE={} vto={}",
                    comprobante.puntoVenta(), comprobante.tipoComprobante(),
                    comprobante.numero(), cae, vencimiento);
            return new CaeResultado(true, estado, cae, vencimiento, comprobante.numero(),
                    comprobante.tipoComprobante(), modo, observaciones, errores, eventos);
        }

        if (errores.isEmpty() && observaciones.isEmpty()) {
            errores = List.of("AFIP no autorizó el comprobante (resultado: " + estado + ").");
        }
        return new CaeResultado(false, estado, null, null, comprobante.numero(),
                comprobante.tipoComprobante(), modo, observaciones, errores, eventos);
    }

    private static FECAEDetResponse primerDetalle(FECAEResponse respuesta) {
        ArrayOfFECAEDetResponse array = respuesta.getFeDetResp();
        if (array == null || array.getFECAEDetResponse().isEmpty()) {
            return null;
        }
        return array.getFECAEDetResponse().get(0);
    }

    private static List<String> observaciones(FECAEDetResponse detalle) {
        if (detalle == null) {
            return List.of();
        }
        ArrayOfObs array = detalle.getObservaciones();
        if (array == null) {
            return List.of();
        }
        List<String> resultado = new ArrayList<>();
        for (Obs obs : array.getObs()) {
            if (obs != null) {
                resultado.add(obs.getCode() + ": " + obs.getMsg());
            }
        }
        return resultado;
    }

    private static List<String> mensajes(ArrayOfErr array) {
        if (array == null) {
            return List.of();
        }
        List<String> resultado = new ArrayList<>();
        for (Err err : array.getErr()) {
            if (err != null) {
                resultado.add(err.getCode() + ": " + err.getMsg());
            }
        }
        return resultado;
    }

    private static List<String> eventos(ArrayOfEvt array) {
        if (array == null) {
            return List.of();
        }
        List<String> resultado = new ArrayList<>();
        for (Evt evt : array.getEvt()) {
            if (evt != null) {
                resultado.add(evt.getCode() + ": " + evt.getMsg());
            }
        }
        return resultado;
    }

    private static FEAuthRequest auth(AfipAuth auth) {
        if (auth == null) {
            throw new AfipException("Falta el ticket de acceso (TA) de WSAA para invocar WSFEv1.");
        }
        FEAuthRequest request = new FEAuthRequest();
        request.setToken(auth.token());
        request.setSign(auth.sign());
        request.setCuit(auth.cuit());
        return request;
    }

    // ------------------------------------------------------------------
    // Infraestructura JAX-WS
    // ------------------------------------------------------------------

    ServiceSoap puerto() {
        ServiceSoap actual = puerto;
        if (actual == null) {
            synchronized (candado) {
                actual = puerto;
                if (actual == null) {
                    actual = crearPuerto();
                    puerto = actual;
                }
            }
        }
        return actual;
    }

    private ServiceSoap crearPuerto() {
        try {
            // El WSDL se toma del endpoint configurado (homologación o producción).
            Service servicio = new Service(urlWsdl());
            ServiceSoap soap = servicio.getServiceSoap();

            Map<String, Object> contexto = ((BindingProvider) soap).getRequestContext();
            contexto.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, properties.getWsfeUrl());
            contexto.put(JAXWSProperties.CONNECT_TIMEOUT, properties.getTimeoutMs());
            contexto.put(JAXWSProperties.REQUEST_TIMEOUT, properties.getTimeoutMs());

            log.info("WSFEv1: cliente JAX-WS inicializado (WSDL {}, endpoint {})",
                    urlWsdl(), properties.getWsfeUrl());
            return soap;
        } catch (MalformedURLException e) {
            throw new AfipException("La URL de WSFEv1 no es válida: " + properties.getWsfeUrl(), e);
        } catch (RuntimeException e) {
            throw new AfipException(
                    "No se pudo inicializar el cliente JAX-WS de WSFEv1 (" + e.getMessage() + ").", e);
        }
    }

    private URL urlWsdl() throws MalformedURLException {
        String endpoint = properties.getWsfeUrl();
        if (endpoint == null || endpoint.isBlank()) {
            throw new MalformedURLException("afip.wsfe-url no está configurada");
        }
        String wsdl = endpoint.contains("?") ? endpoint : endpoint + "?WSDL";
        return new URL(wsdl);
    }

    private AfipException error(String operacion, RuntimeException causa) {
        log.warn("WSFEv1 (JAX-WS): falló {}: {}", operacion, causa.toString());
        return new AfipException("Error invocando " + operacion + " vía JAX-WS: " + causa.getMessage(), causa);
    }

    private static int idAlicuota(double alicuota) {
        if (Math.abs(alicuota - 21.0) < 0.01) return 5;
        if (Math.abs(alicuota - 10.5) < 0.01) return 4;
        if (Math.abs(alicuota - 27.0) < 0.01) return 6;
        if (Math.abs(alicuota - 5.0) < 0.01) return 8;
        if (Math.abs(alicuota - 2.5) < 0.01) return 9;
        return alicuota > 0 ? 5 : 0;
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    private static LocalDate parsearFecha(String valor) {
        if (valor == null || valor.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(valor, FORMATO_FECHA);
        } catch (Exception e) {
            return null;
        }
    }
}
