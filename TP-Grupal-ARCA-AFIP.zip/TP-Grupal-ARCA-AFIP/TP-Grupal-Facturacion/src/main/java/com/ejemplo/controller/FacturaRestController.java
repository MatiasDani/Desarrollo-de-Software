package com.ejemplo.controller;

import com.ejemplo.afip.dto.EmisionCaeRequestDTO;
import com.ejemplo.dto.FacturaDetalleDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ResumenFacturasDTO;
import com.ejemplo.service.FacturaService;
import com.ejemplo.service.ReporteService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Date;
import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/facturas")
public class FacturaRestController {

    private final FacturaService facturaService;
    private final ReporteService reporteService;

    public FacturaRestController(FacturaService facturaService, ReporteService reporteService) {
        this.facturaService = facturaService;
        this.reporteService = reporteService;
    }

    @GetMapping
    public ResponseEntity<List<FacturaReporteDTO>> buscarFacturas(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {

        List<FacturaReporteDTO> facturas = facturaService.buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);
        return ResponseEntity.ok(facturas);
    }

    /**
     * Listado paginado de comprobantes. Aplica los mismos filtros que
     * {@link #buscarFacturas(Date, Date, String, Double)} pero devuelve una sola
     * página junto con los metadatos de navegación (total de elementos, total de
     * páginas, etc.), de modo que el frontend no tenga que traer todo el listado.
     *
     * @param pagina  número de página solicitado (base 0).
     * @param tamanio cantidad de filas por página (el servicio la acota a 100).
     */
    @GetMapping("/paginado")
    public ResponseEntity<PaginaDTO<FacturaReporteDTO>> buscarFacturasPaginadas(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "10") int tamanio) {

        PaginaDTO<FacturaReporteDTO> resultado = facturaService.buscarFacturasPaginadas(
                fechaDesde, fechaHasta, estado, montoMinimo, pagina, tamanio);
        return ResponseEntity.ok(resultado);
    }

    /**
     * Totales del panel de control (importe vigente, cantidades por estado y las
     * últimas facturas), calculados en la base de datos. Reemplaza el uso del
     * listado completo en el dashboard, que no escala con muchos comprobantes.
     */
    @GetMapping("/resumen")
    public ResponseEntity<ResumenFacturasDTO> obtenerResumen() {
        return ResponseEntity.ok(facturaService.obtenerResumen());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FacturaDetalleDTO> obtenerFactura(@PathVariable Long id) {
        return ResponseEntity.ok(facturaService.obtenerDetalle(id));
    }

    @GetMapping("/reporte/pdf")
    public ResponseEntity<byte[]> descargarPdf() {
        byte[] pdf = reporteService.generarPdf();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.pdf")
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE)
                .body(pdf);
    }

    @GetMapping("/reporte/excel")
    public ResponseEntity<byte[]> descargarExcel() throws IOException {
        byte[] excel = reporteService.generarExcel();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.xlsx")
                .header(HttpHeaders.CONTENT_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                .body(excel);
    }

    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crearFactura(@RequestBody FacturaRequestDTO dto) {
        FacturaReporteDTO reporte = facturaService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(reporte);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FacturaReporteDTO> actualizarFactura(@PathVariable Long id, @RequestBody FacturaRequestDTO dto) {
        FacturaReporteDTO reporte = facturaService.actualizar(id, dto);
        return ResponseEntity.ok(reporte);
    }

    /**
     * Solicita el CAE del comprobante. En modo SIMULADO genera un CAE ficticio.
     * Si AFIP rechaza el comprobante, se devuelve la factura con el motivo.
     */
    @PostMapping("/{id}/emitir")
    public ResponseEntity<FacturaDetalleDTO> emitirCae(
            @PathVariable Long id,
            @RequestBody(required = false) EmisionCaeRequestDTO request) {
        Integer tipo = request == null ? null : request.tipoComprobante();
        return ResponseEntity.ok(facturaService.emitirCae(id, tipo));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarFactura(@PathVariable Long id) {
        facturaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
