package com.ejemplo.service;

import com.ejemplo.afip.AfipException;
import com.ejemplo.afip.AfipProperties;
import com.ejemplo.afip.AfipService;
import com.ejemplo.afip.model.CaeResultado;
import com.ejemplo.dto.FacturaDetalleDTO;
import com.ejemplo.dto.FacturaDetalleRequestDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.dto.PaginaDTO;
import com.ejemplo.dto.ResumenFacturasDTO;
import com.ejemplo.entity.Articulo;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.CondicionIva;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.FacturaVentaDetalle;
import com.ejemplo.entity.PuntoVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.exception.RecursoNoEncontradoException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaService {

    /** Proyección común del listado de comprobantes (constructor expression). */
    private static final String SELECT_REPORTE =
            "SELECT new com.ejemplo.dto.FacturaReporteDTO(" +
            "    f.id, COALESCE(f.numeroAfip, f.numero), f.fechaEmision, " +
            "    COALESCE(c.denominacion, 'Consumidor Final'), ci.denominacion, pv.descripcion, " +
            "    f.importeTotal, COUNT(d), f.estado, f.cae, f.caeFechaVencimiento, " +
            "    f.resultadoAfip, f.tipoComprobante" +
            ") " +
            "FROM FacturaVenta f " +
            "LEFT JOIN f.cliente c " +
            "JOIN f.condicionIva ci " +
            "JOIN f.puntoVenta pv " +
            "LEFT JOIN f.detalles d ";

    /** Agrupamiento requerido por el {@code COUNT(d)} de la proyección. */
    private static final String GROUP_BY_REPORTE =
            "GROUP BY f.id, f.numeroAfip, f.numero, f.fechaEmision, c.denominacion, " +
            "ci.denominacion, pv.descripcion, f.importeTotal, f.estado, f.cae, " +
            "f.caeFechaVencimiento, f.resultadoAfip, f.tipoComprobante ";

    private final EntityManager em;
    private final AfipService afipService;
    private final AfipProperties afipProperties;

    public FacturaService(EntityManager em, AfipService afipService, AfipProperties afipProperties) {
        this.em = em;
        this.afipService = afipService;
        this.afipProperties = afipProperties;
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> obtenerReporte() {
        String jpql = SELECT_REPORTE + GROUP_BY_REPORTE + "ORDER BY f.id";
        return em.createQuery(jpql, FacturaReporteDTO.class).getResultList();
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        Map<String, Object> params = new HashMap<>();
        String filtros = construirFiltros(fechaDesde, fechaHasta, estado, montoMinimo, params);

        String jpql = SELECT_REPORTE + "WHERE 1=1 " + filtros + GROUP_BY_REPORTE + "ORDER BY f.id";

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql, FacturaReporteDTO.class);
        params.forEach(query::setParameter);

        return query.getResultList();
    }

    /**
     * Listado paginado de comprobantes. Aplica los mismos filtros que
     * {@link #buscarFacturasFiltradas(Date, Date, String, Double)} y devuelve
     * una única página junto con los totales necesarios para la navegación.
     *
     * @param pagina  número de página solicitado (base 0).
     * @param tamanio cantidad de filas por página (se acota entre 1 y 100).
     */
    @Transactional(readOnly = true)
    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(Date fechaDesde, Date fechaHasta, String estado,
                                                                Double montoMinimo, int pagina, int tamanio) {
        int tamanioPagina = Math.min(Math.max(tamanio, 1), 100);

        Map<String, Object> params = new HashMap<>();
        String filtros = construirFiltros(fechaDesde, fechaHasta, estado, montoMinimo, params);

        TypedQuery<Long> conteo = em.createQuery(
                "SELECT COUNT(f) FROM FacturaVenta f WHERE 1=1 " + filtros, Long.class);
        params.forEach(conteo::setParameter);
        long total = conteo.getSingleResult();

        int totalPaginas = total == 0 ? 0 : (int) Math.ceil(total / (double) tamanioPagina);
        // Si se pidió una página fuera de rango (p. ej. tras eliminar filas) se
        // devuelve la última disponible en lugar de una página vacía.
        int paginaActual = totalPaginas == 0 ? 0 : Math.min(Math.max(pagina, 0), totalPaginas - 1);

        String jpql = SELECT_REPORTE + "WHERE 1=1 " + filtros + GROUP_BY_REPORTE + "ORDER BY f.id";

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql, FacturaReporteDTO.class);
        params.forEach(query::setParameter);
        query.setFirstResult(paginaActual * tamanioPagina);
        query.setMaxResults(tamanioPagina);

        List<FacturaReporteDTO> contenido = query.getResultList();

        return new PaginaDTO<>(
                contenido,
                paginaActual,
                tamanioPagina,
                total,
                totalPaginas,
                paginaActual == 0,
                totalPaginas == 0 || paginaActual >= totalPaginas - 1);
    }

    /** Cantidad de comprobantes recientes que muestra el panel de control. */
    private static final int ULTIMAS_DEL_RESUMEN = 5;

    /** Condición JPQL "la factura tiene CAE" (no nulo y no vacío). */
    private static final String TIENE_CAE = "(f.cae IS NOT NULL AND f.cae <> '')";

    /**
     * Totales del panel de control calculados en la base de datos.
     *
     * <p>Una sola consulta de agregación resuelve los contadores y el importe, y
     * otra trae únicamente las últimas {@value #ULTIMAS_DEL_RESUMEN} facturas.
     * Así el costo de la respuesta no crece con la cantidad de comprobantes.</p>
     */
    @Transactional(readOnly = true)
    public ResumenFacturasDTO obtenerResumen() {
        Object[] totales = em.createQuery(
                "SELECT " +
                "  COALESCE(SUM(CASE WHEN f.estado <> 'ANULADA' THEN f.importeTotal ELSE 0 END), 0), " +
                "  COALESCE(SUM(CASE WHEN f.estado <> 'ANULADA' THEN 1 ELSE 0 END), 0), " +
                "  COALESCE(SUM(CASE WHEN f.estado <> 'ANULADA' AND " + TIENE_CAE + " THEN 1 ELSE 0 END), 0), " +
                "  COALESCE(SUM(CASE WHEN f.estado = 'ANULADA' THEN 1 ELSE 0 END), 0) " +
                "FROM FacturaVenta f", Object[].class).getSingleResult();

        double importeVigente = ((Number) totales[0]).doubleValue();
        long vigentes = ((Number) totales[1]).longValue();
        long conCae = ((Number) totales[2]).longValue();
        long anuladas = ((Number) totales[3]).longValue();

        List<FacturaReporteDTO> ultimas = em.createQuery(
                        SELECT_REPORTE + GROUP_BY_REPORTE + "ORDER BY f.id DESC", FacturaReporteDTO.class)
                .setMaxResults(ULTIMAS_DEL_RESUMEN)
                .getResultList();

        return new ResumenFacturasDTO(importeVigente, vigentes, conCae, vigentes - conCae, anuladas, ultimas);
    }

    /**
     * Arma la cláusula de filtros (sin {@code WHERE}) y carga los parámetros
     * nombrados en el mapa recibido. Se comparte entre el listado completo y el
     * paginado para que ambos apliquen exactamente los mismos criterios.
     */
    private String construirFiltros(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo,
                                    Map<String, Object> params) {
        StringBuilder filtros = new StringBuilder();

        if (fechaDesde != null) {
            filtros.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            filtros.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            filtros.append("AND f.estado = :estado ");
            params.put("estado", estado.trim().toUpperCase());
        }
        if (montoMinimo != null) {
            filtros.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }

        return filtros.toString();
    }

    @Transactional(readOnly = true)
    public FacturaDetalleDTO obtenerDetalle(Long id) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }
        return toDetalle(factura);
    }

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.getPuntoVentaId() == null || dto.getCondicionIvaId() == null || dto.getTipoMonedaId() == null) {
            throw new IllegalArgumentException("Los IDs de PuntoVenta, CondicionIva y TipoMoneda son requeridos");
        }

        PuntoVenta puntoVenta = em.find(PuntoVenta.class, dto.getPuntoVentaId());
        CondicionIva condicionIva = em.find(CondicionIva.class, dto.getCondicionIvaId());
        TipoMoneda tipoMoneda = em.find(TipoMoneda.class, dto.getTipoMonedaId());

        if (puntoVenta == null) throw new RecursoNoEncontradoException("Punto de venta no encontrado con ID: " + dto.getPuntoVentaId());
        if (condicionIva == null) throw new RecursoNoEncontradoException("Condición de IVA no encontrada con ID: " + dto.getCondicionIvaId());
        if (tipoMoneda == null) throw new RecursoNoEncontradoException("Tipo de moneda no encontrado con ID: " + dto.getTipoMonedaId());

        Cliente cliente = null;
        if (dto.getClienteId() != null) {
            cliente = em.find(Cliente.class, dto.getClienteId());
            if (cliente == null) throw new RecursoNoEncontradoException("Cliente no encontrado con ID: " + dto.getClienteId());
        }

        FacturaVenta factura = new FacturaVenta();
        factura.setFechaEmision(dto.getFechaEmision() != null ? dto.getFechaEmision() : new Date());
        factura.setPuntoVenta(puntoVenta);
        factura.setCondicionIva(condicionIva);
        factura.setTipoMoneda(tipoMoneda);
        factura.setCliente(cliente);
        factura.setImporteCobrado(dto.getImporteCobrado());
        factura.setObservaciones(dto.getObservaciones());
        factura.setTipoComprobante(dto.getTipoComprobante());
        factura.setEstado(dto.getEstado() != null && !dto.getEstado().trim().isEmpty()
                ? dto.getEstado().trim().toUpperCase()
                : "ACTIVA");

        Long maxNum = em.createQuery("SELECT MAX(f.numero) FROM FacturaVenta f", Long.class).getSingleResult();
        factura.setNumero(maxNum == null ? 1 : maxNum + 1);

        if (dto.getDetalles() != null) {
            for (FacturaDetalleRequestDTO detDto : dto.getDetalles()) {
                Articulo articulo = em.find(Articulo.class, detDto.getArticuloId());
                if (articulo == null) {
                    throw new RecursoNoEncontradoException("Artículo no encontrado con ID: " + detDto.getArticuloId());
                }
                factura.agregarDetalle(articulo, detDto.getCantidad());
            }
        }

        em.persist(factura);
        em.flush();

        if (afipProperties.isAutoEmitir()
                && afipProperties.getModo() != AfipProperties.Modo.DESHABILITADO) {
            try {
                CaeResultado resultado = afipService.emitir(factura, factura.getTipoComprobante());
                aplicarResultadoCae(factura, resultado);
                em.flush();
            } catch (AfipException e) {
                factura.setMotivoRechazo(e.getMessage());
            }
        }

        return toReporte(factura);
    }

    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }

        if (tieneCae(factura)) {
            validarEdicionConCae(factura, dto);
        }

        if (dto.getEstado() != null && !dto.getEstado().trim().isEmpty()) {
            String nuevoEstado = dto.getEstado().trim().toUpperCase();
            factura.setEstado(nuevoEstado);
            if ("ANULADA".equals(nuevoEstado) && factura.getFechaAnulacion() == null) {
                factura.setFechaAnulacion(new Date());
            }
        }

        if (dto.getObservaciones() != null) {
            factura.setObservaciones(dto.getObservaciones());
        }

        if (dto.getFechaEmision() != null) {
            factura.setFechaEmision(dto.getFechaEmision());
        }

        if (dto.getPuntoVentaId() != null) {
            PuntoVenta pv = em.find(PuntoVenta.class, dto.getPuntoVentaId());
            if (pv == null) throw new RecursoNoEncontradoException("Punto de venta no encontrado con ID: " + dto.getPuntoVentaId());
            factura.setPuntoVenta(pv);
        }

        if (dto.getClienteId() != null) {
            Cliente cli = em.find(Cliente.class, dto.getClienteId());
            if (cli == null) throw new RecursoNoEncontradoException("Cliente no encontrado con ID: " + dto.getClienteId());
            factura.setCliente(cli);
        }

        if (dto.getCondicionIvaId() != null) {
            CondicionIva ci = em.find(CondicionIva.class, dto.getCondicionIvaId());
            if (ci == null) throw new RecursoNoEncontradoException("Condición de IVA no encontrada con ID: " + dto.getCondicionIvaId());
            factura.setCondicionIva(ci);
        }

        if (dto.getTipoMonedaId() != null) {
            TipoMoneda tm = em.find(TipoMoneda.class, dto.getTipoMonedaId());
            if (tm == null) throw new RecursoNoEncontradoException("Tipo de moneda no encontrado con ID: " + dto.getTipoMonedaId());
            factura.setTipoMoneda(tm);
        }

        if (dto.getTipoComprobante() != null) {
            factura.setTipoComprobante(dto.getTipoComprobante());
        }

        if (dto.getImporteCobrado() > 0) {
            factura.setImporteCobrado(dto.getImporteCobrado());
        }

        // Actualizar ítems si fueron proporcionados en la petición
        if (dto.getDetalles() != null) {
            factura.getDetalles().clear();
            for (FacturaDetalleRequestDTO detDto : dto.getDetalles()) {
                Articulo articulo = em.find(Articulo.class, detDto.getArticuloId());
                if (articulo == null) {
                    throw new RecursoNoEncontradoException("Artículo no encontrado con ID: " + detDto.getArticuloId());
                }
                factura.agregarDetalle(articulo, detDto.getCantidad());
            }
        }

        factura.calcularTotal();
        em.merge(factura);

        return toReporte(factura);
    }

    /**
     * Solicita el CAE a AFIP (o lo simula) y persiste el resultado fiscal.
     */
    @Transactional
    public FacturaDetalleDTO emitirCae(Long id, Integer tipoComprobante) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }

        CaeResultado resultado = afipService.emitir(factura, tipoComprobante);
        aplicarResultadoCae(factura, resultado);
        em.flush();

        return toDetalle(factura);
    }

    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }
        if (tieneCae(factura)) {
            throw new IllegalStateException("No se puede eliminar la factura: ya fue autorizada por AFIP (CAE "
                    + factura.getCae() + "). Un comprobante autorizado se anula emitiendo una Nota de Crédito.");
        }
        em.remove(factura);
    }

    private static boolean tieneCae(FacturaVenta factura) {
        return factura.getCae() != null && !factura.getCae().isBlank();
    }

    /**
     * Un comprobante autorizado por AFIP no puede cambiar sus datos fiscales
     * (fecha, punto de venta, receptor, moneda, tipo ni ítems): solo se permite
     * actualizar el estado (anulación lógica), las observaciones y lo cobrado.
     * Se toleran valores iguales a los actuales para no romper formularios que
     * reenvían la factura completa.
     */
    private void validarEdicionConCae(FacturaVenta factura, FacturaRequestDTO dto) {
        List<String> campos = new java.util.ArrayList<>();
        if (dto.getDetalles() != null) campos.add("ítems");
        if (dto.getFechaEmision() != null && !mismaFecha(dto.getFechaEmision(), factura.getFechaEmision())) {
            campos.add("fecha de emisión");
        }
        if (dto.getPuntoVentaId() != null && !dto.getPuntoVentaId().equals(factura.getPuntoVenta().getId())) {
            campos.add("punto de venta");
        }
        if (dto.getClienteId() != null
                && (factura.getCliente() == null || !dto.getClienteId().equals(factura.getCliente().getId()))) {
            campos.add("cliente");
        }
        if (dto.getCondicionIvaId() != null && !dto.getCondicionIvaId().equals(factura.getCondicionIva().getId())) {
            campos.add("condición de IVA");
        }
        if (dto.getTipoMonedaId() != null && !dto.getTipoMonedaId().equals(factura.getTipoMoneda().getId())) {
            campos.add("moneda");
        }
        if (dto.getTipoComprobante() != null && !dto.getTipoComprobante().equals(factura.getTipoComprobante())) {
            campos.add("tipo de comprobante");
        }
        if (!campos.isEmpty()) {
            throw new IllegalStateException("La factura ya tiene CAE: no se puede modificar "
                    + String.join(", ", campos) + ". Solo se permite anularla o cambiar las observaciones.");
        }
    }

    private static boolean mismaFecha(Date a, Date b) {
        if (a == null || b == null) return a == b;
        // java.sql.Date#toLocalDate evita el toInstant() que no soporta java.sql.Date.
        return new java.sql.Date(a.getTime()).toLocalDate().equals(
                new java.sql.Date(b.getTime()).toLocalDate());
    }

    private void aplicarResultadoCae(FacturaVenta factura, CaeResultado resultado) {
        factura.setTipoComprobante(resultado.tipoComprobante());

        if (resultado.aprobado()) {
            factura.setCae(resultado.cae());
            factura.setCaeFechaVencimiento(resultado.caeVencimiento() == null
                    ? null
                    : java.sql.Date.valueOf(resultado.caeVencimiento()));
            factura.setResultadoAfip(resultado.resultado());
            factura.setNumeroAfip(resultado.numeroComprobante());
            factura.setMotivoRechazo(null);
            factura.setEstado("EMITIDA");
        } else {
            factura.setResultadoAfip(resultado.resultado() == null ? "R" : resultado.resultado());
            factura.setMotivoRechazo(construirMotivo(resultado));
        }
    }

    private String construirMotivo(CaeResultado resultado) {
        StringBuilder motivo = new StringBuilder();
        if (resultado.errores() != null && !resultado.errores().isEmpty()) {
            motivo.append(String.join(" | ", resultado.errores()));
        }
        if (resultado.observaciones() != null && !resultado.observaciones().isEmpty()) {
            if (motivo.length() > 0) motivo.append(" | ");
            motivo.append(String.join(" | ", resultado.observaciones()));
        }
        return motivo.length() == 0 ? "AFIP no autorizó el comprobante." : motivo.toString();
    }

    private FacturaReporteDTO toReporte(FacturaVenta factura) {
        return new FacturaReporteDTO(
                factura.getId(),
                factura.getNumeroAfip() != null ? factura.getNumeroAfip() : factura.getNumero(),
                factura.getFechaEmision(),
                factura.getCliente() != null ? factura.getCliente().getDenominacion() : "Consumidor Final",
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getImporteTotal(),
                factura.getDetalles() == null ? 0 : factura.getDetalles().size(),
                factura.getEstado(),
                factura.getCae(),
                factura.getCaeFechaVencimiento(),
                factura.getResultadoAfip(),
                factura.getTipoComprobante());
    }

    private FacturaDetalleDTO toDetalle(FacturaVenta factura) {
        List<FacturaDetalleDTO.Item> items = factura.getDetalles().stream()
                .map(this::toItem)
                .toList();

        Cliente cliente = factura.getCliente();
        return new FacturaDetalleDTO(
                factura.getId(),
                factura.getNumeroAfip() != null ? factura.getNumeroAfip() : factura.getNumero(),
                factura.getNumeroAfip(),
                factura.getFechaEmision(),
                cliente == null ? null : cliente.getId(),
                cliente == null ? "Consumidor Final" : cliente.getDenominacion(),
                cliente == null ? null : cliente.getCuit(),
                factura.getCondicionIva().getId(),
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getId(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getPuntoVenta().getNumero(),
                factura.getTipoMoneda().getId(),
                factura.getTipoMoneda().getCodigo(),
                factura.getTipoMoneda().getDenominacion(),
                factura.getImporteCobrado(),
                factura.getImporteSaldo(),
                factura.getImporteTotal(),
                factura.getEstado(),
                factura.getObservaciones(),
                factura.getCae(),
                factura.getCaeFechaVencimiento(),
                factura.getResultadoAfip(),
                factura.getMotivoRechazo(),
                factura.getTipoComprobante(),
                factura.getFechaAnulacion(),
                items);
    }

    private FacturaDetalleDTO.Item toItem(FacturaVentaDetalle detalle) {
        Articulo articulo = detalle.getArticulo();
        return new FacturaDetalleDTO.Item(
                articulo.getId(),
                articulo.getCodigo(),
                articulo.getDenominacion(),
                detalle.getCantidad(),
                detalle.getPrecioUnitario(),
                detalle.getSubtotal());
    }
}
