package com.ejemplo.afip;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Configuración de la integración con ARCA (ex AFIP).
 *
 * <p>Los valores se toman de {@code application.properties} con el prefijo
 * {@code afip.*}. El modo por defecto es {@link Modo#SIMULADO} para que el
 * sistema pueda demostrarse sin certificados; para emitir comprobantes reales
 * en testing se debe usar {@link Modo#HOMOLOGACION} y configurar las
 * credenciales.</p>
 */
@Component
@ConfigurationProperties(prefix = "afip")
public class AfipProperties {

    public enum Modo {
        DESHABILITADO,
        SIMULADO,
        HOMOLOGACION,
        PRODUCCION
    }

    private Modo modo = Modo.SIMULADO;
    private String cuit;
    private int tipoComprobante = 11;
    private double alicuotaIva = 21.0;
    private String wsaaUrl = "https://wsaahomo.afip.gov.ar/ws/services/LoginCms";
    private String wsfeUrl = "https://wswhomo.afip.gov.ar/wsfev1/service.asmx";
    private String certificadoPath;
    private String clavePath;
    private String pfxPath;
    private String pfxPassword;
    private boolean autoEmitir = false;
    private int timeoutMs = 30_000;
    private String taPath = "ta_wsfe.xml";
    /** Usar los stubs JAX-WS generados (true) o el cliente SOAP manual (false). */
    private boolean usarJaxws = true;

    public boolean esSimulado() {
        return modo == Modo.SIMULADO;
    }

    public boolean usaRed() {
        return modo == Modo.HOMOLOGACION || modo == Modo.PRODUCCION;
    }

    public boolean tieneCredenciales() {
        return tieneTexto(pfxPath) || (tieneTexto(certificadoPath) && tieneTexto(clavePath));
    }

    public String cuitNormalizado() {
        return cuit == null ? null : cuit.replaceAll("[^0-9]", "");
    }

    private boolean tieneTexto(String valor) {
        return valor != null && !valor.isBlank();
    }

    public Modo getModo() {
        return modo;
    }

    public void setModo(Modo modo) {
        this.modo = modo;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public int getTipoComprobante() {
        return tipoComprobante;
    }

    public void setTipoComprobante(int tipoComprobante) {
        this.tipoComprobante = tipoComprobante;
    }

    public double getAlicuotaIva() {
        return alicuotaIva;
    }

    public void setAlicuotaIva(double alicuotaIva) {
        this.alicuotaIva = alicuotaIva;
    }

    public String getWsaaUrl() {
        return wsaaUrl;
    }

    public void setWsaaUrl(String wsaaUrl) {
        this.wsaaUrl = wsaaUrl;
    }

    public String getWsfeUrl() {
        return wsfeUrl;
    }

    public void setWsfeUrl(String wsfeUrl) {
        this.wsfeUrl = wsfeUrl;
    }

    public String getCertificadoPath() {
        return certificadoPath;
    }

    public void setCertificadoPath(String certificadoPath) {
        this.certificadoPath = certificadoPath;
    }

    public String getClavePath() {
        return clavePath;
    }

    public void setClavePath(String clavePath) {
        this.clavePath = clavePath;
    }

    public String getPfxPath() {
        return pfxPath;
    }

    public void setPfxPath(String pfxPath) {
        this.pfxPath = pfxPath;
    }

    public String getPfxPassword() {
        return pfxPassword;
    }

    public void setPfxPassword(String pfxPassword) {
        this.pfxPassword = pfxPassword;
    }

    public boolean isAutoEmitir() {
        return autoEmitir;
    }

    public void setAutoEmitir(boolean autoEmitir) {
        this.autoEmitir = autoEmitir;
    }

    public int getTimeoutMs() {
        return timeoutMs;
    }

    public void setTimeoutMs(int timeoutMs) {
        this.timeoutMs = timeoutMs;
    }

    public String getTaPath() {
        return taPath;
    }

    public void setTaPath(String taPath) {
        this.taPath = taPath;
    }

    public boolean isUsarJaxws() {
        return usarJaxws;
    }

    public void setUsarJaxws(boolean usarJaxws) {
        this.usarJaxws = usarJaxws;
    }
}
