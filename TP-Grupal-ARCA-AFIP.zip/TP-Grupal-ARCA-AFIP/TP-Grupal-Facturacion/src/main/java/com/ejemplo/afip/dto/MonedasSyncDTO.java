package com.ejemplo.afip.dto;

import com.ejemplo.dto.CatalogoDTO;

import java.util.List;

/**
 * Resultado de sincronizar el catálogo de monedas contra
 * {@code FEParamGetTiposMonedas} de AFIP.
 */
public record MonedasSyncDTO(
        boolean ok,
        String modo,
        String mensaje,
        int nuevas,
        int actualizadas,
        long total,
        List<CatalogoDTO.MonedaItem> monedas
) {
}
