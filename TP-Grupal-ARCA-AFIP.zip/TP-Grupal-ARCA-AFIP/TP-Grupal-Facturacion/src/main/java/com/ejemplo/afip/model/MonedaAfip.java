package com.ejemplo.afip.model;

/**
 * Ítem del catálogo de monedas informado por WSFEv1 en
 * {@code FEParamGetTiposMonedas}.
 *
 * @param codigo        identificador AFIP ({@code PES}, {@code DOL}, {@code 060}…)
 * @param denominacion  descripción oficial
 * @param vigenciaDesde fecha desde la que rige (yyyyMMdd, puede ser null)
 * @param vigenciaHasta fecha hasta la que rige (yyyyMMdd, puede ser null)
 */
public record MonedaAfip(String codigo, String denominacion, String vigenciaDesde, String vigenciaHasta) {
}
