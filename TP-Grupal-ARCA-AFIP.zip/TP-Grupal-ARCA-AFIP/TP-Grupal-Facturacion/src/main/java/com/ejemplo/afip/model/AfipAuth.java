package com.ejemplo.afip.model;

import java.time.LocalDateTime;

/**
 * Token y firma devueltos por WSAA junto con su vencimiento.
 */
public record AfipAuth(String token, String sign, long cuit, LocalDateTime vencimiento) {
}
