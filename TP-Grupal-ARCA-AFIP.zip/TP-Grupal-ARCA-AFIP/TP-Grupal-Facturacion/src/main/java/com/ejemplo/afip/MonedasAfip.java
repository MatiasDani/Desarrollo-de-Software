package com.ejemplo.afip;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Catálogo de monedas soportadas por ARCA/AFIP (WSFEv1).
 *
 * <p>Cada moneda tiene dos identificadores:</p>
 * <ul>
 *   <li>{@code codigoIso}: código ISO 4217 (ARS, USD, EUR…) que usa la aplicación
 *       para mostrar importes con {@code Intl.NumberFormat}.</li>
 *   <li>{@code codigoAfip}: identificador que exige WSFEv1 en el campo
 *       {@code MonId} ({@code PES}, {@code DOL}, {@code 002}…).</li>
 * </ul>
 *
 * <p>Este catálogo es una copia fiel de lo que devuelve
 * {@code FEParamGetTiposMonedas} en homologación al 2026-11-16 (49 monedas).
 * Se usa para sembrar la base y para poder trabajar sin conectividad; en modo
 * HOMOLOGACION/PRODUCCION se puede refrescar contra AFIP con
 * {@code POST /api/afip/monedas/sincronizar}.</p>
 */
public final class MonedasAfip {

    /** Moneda tal como la maneja la aplicación. */
    public record Definicion(String codigoIso, String codigoAfip, String denominacion) {
    }

    /**
     * Catálogo real de AFIP ({@code FEParamGetTiposMonedas}). El ISO es sólo para
     * presentación; el {@code codigoAfip} es el valor que viaja en {@code MonId}.
     */
    private static final List<Definicion> CATALOGO = List.of(
            new Definicion("USD", "002", "Dólar Libre EEUU"),
            new Definicion("CHF", "009", "Franco Suizo"),
            new Definicion("MXN", "010", "Pesos Mejicanos"),
            new Definicion("UYU", "011", "Pesos Uruguayos"),
            new Definicion("BRL", "012", "Real"),
            new Definicion("DKK", "014", "Coronas Danesas"),
            new Definicion("NOK", "015", "Coronas Noruegas"),
            new Definicion("SEK", "016", "Coronas Suecas"),
            new Definicion("CAD", "018", "Dólar Canadiense"),
            new Definicion("JPY", "019", "Yens"),
            new Definicion("GBP", "021", "Libra Esterlina"),
            new Definicion("VES", "023", "Bolívar Venezolano"),
            new Definicion("CZK", "024", "Corona Checa"),
            new Definicion("RSD", "025", "Dinar Serbio"),
            new Definicion("AUD", "026", "Dólar Australiano"),
            new Definicion("ANG", "028", "Florín (Antillas Holandesas)"),
            new Definicion("PYG", "029", "Guaraní"),
            new Definicion("ILS", "030", "Shekel (Israel)"),
            new Definicion("BOB", "031", "Peso Boliviano"),
            new Definicion("COP", "032", "Peso Colombiano"),
            new Definicion("CLP", "033", "Peso Chileno"),
            new Definicion("ZAR", "034", "Rand Sudafricano"),
            new Definicion("PEN", "035", "Nuevo Sol Peruano"),
            new Definicion("RON", "040", "Leu Rumano"),
            new Definicion("XDR", "041", "Derechos Especiales de Giro"),
            new Definicion("DOP", "042", "Peso Dominicano"),
            new Definicion("PAB", "043", "Balboas Panameñas"),
            new Definicion("NIO", "044", "Córdoba Nicaragüense"),
            new Definicion("MAD", "045", "Dirham Marroquí"),
            new Definicion("EGP", "046", "Libra Egipcia"),
            new Definicion("SAR", "047", "Riyal Saudita"),
            new Definicion("XAU", "049", "Gramos de Oro Fino"),
            new Definicion("HKD", "051", "Dólar de Hong Kong"),
            new Definicion("SGD", "052", "Dólar de Singapur"),
            new Definicion("JMD", "053", "Dólar de Jamaica"),
            new Definicion("TWD", "054", "Dólar de Taiwan"),
            new Definicion("GTQ", "055", "Quetzal Guatemalteco"),
            new Definicion("HUF", "056", "Forint (Hungría)"),
            new Definicion("THB", "057", "Baht (Tailandia)"),
            new Definicion("KWD", "059", "Dinar Kuwaiti"),
            new Definicion("EUR", "060", "Euro"),
            new Definicion("PLN", "061", "Zloty Polaco"),
            new Definicion("INR", "062", "Rupia Hindú"),
            new Definicion("HNL", "063", "Lempira Hondureña"),
            new Definicion("CNY", "064", "Yuan (Rep. Pop. China)"),
            new Definicion("ARS", "PES", "Pesos Argentinos"),
            new Definicion("USD", "DOL", "Dólar Estadounidense"),
            new Definicion("NZD", "NZD", "Dólar Neozelandes"),
            new Definicion("RUB", "RUB", "Rublo (Rusia)")
    );

    /**
     * Índice ISO → definición. Hay ISO repetidos (USD aparece como {@code 002} y
     * {@code DOL}); se prefiere el código alfabético de AFIP.
     */
    private static final Map<String, Definicion> POR_ISO = CATALOGO.stream()
            .collect(Collectors.toMap(
                    Definicion::codigoIso,
                    Function.identity(),
                    (actual, candidato) -> esCodigoAlfabetico(actual.codigoAfip()) ? actual : candidato));

    private static final Map<String, Definicion> POR_AFIP = CATALOGO.stream()
            .collect(Collectors.toMap(Definicion::codigoAfip, Function.identity()));

    private MonedasAfip() {
    }

    public static List<Definicion> catalogo() {
        return CATALOGO;
    }

    /**
     * Normaliza cualquier identificador de moneda al {@code MonId} que espera WSFEv1.
     * Acepta el código ISO (USD), el código AFIP (DOL) o el numérico (002).
     */
    public static String codigoAfip(String codigo) {
        if (codigo == null || codigo.isBlank()) {
            return "PES";
        }
        String valor = codigo.trim().toUpperCase(Locale.ROOT);
        Definicion porAfip = POR_AFIP.get(valor);
        if (porAfip != null) {
            return porAfip.codigoAfip();
        }
        Definicion porIso = POR_ISO.get(valor);
        if (porIso != null) {
            return porIso.codigoAfip();
        }
        return valor;
    }

    /**
     * Devuelve el código ISO asociado a un identificador AFIP. Si AFIP informa una
     * moneda que no está en el catálogo base se usa el propio id como código.
     */
    public static String codigoIso(String codigoAfip) {
        if (codigoAfip == null || codigoAfip.isBlank()) {
            return "ARS";
        }
        String valor = codigoAfip.trim().toUpperCase(Locale.ROOT);
        Definicion definicion = POR_AFIP.get(valor);
        if (definicion != null) {
            return definicion.codigoIso();
        }
        definicion = POR_ISO.get(valor);
        return definicion != null ? definicion.codigoIso() : valor;
    }

    private static boolean esCodigoAlfabetico(String codigo) {
        return codigo != null && !codigo.isEmpty() && !Character.isDigit(codigo.charAt(0));
    }
}
