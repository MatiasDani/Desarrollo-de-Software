package com.ejemplo.afip;

/**
 * Error controlado de la integración con ARCA/AFIP.
 */
public class AfipException extends RuntimeException {

    public AfipException(String mensaje) {
        super(mensaje);
    }

    public AfipException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
