package com.ejemplo.repository;

import com.ejemplo.entity.TipoMoneda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TipoMonedaRepository extends JpaRepository<TipoMoneda, Long> {

    Optional<TipoMoneda> findByCodigoAfip(String codigoAfip);

    Optional<TipoMoneda> findByCodigo(String codigo);
}
