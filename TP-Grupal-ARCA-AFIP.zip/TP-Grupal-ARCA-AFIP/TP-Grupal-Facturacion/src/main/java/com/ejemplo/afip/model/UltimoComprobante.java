package com.ejemplo.afip.model;

import java.util.List;

/**
 * Resultado de {@code FECompUltimoAutorizado}.
 */
public record UltimoComprobante(long numero, List<String> errores, List<String> eventos) {

    public boolean tieneErrores() {
        return errores != null && !errores.isEmpty();
    }
}
