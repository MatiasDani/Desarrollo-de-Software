package com.ejemplo.config;

import com.ejemplo.afip.MonedasAfip;
import com.ejemplo.entity.Articulo;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.CondicionIva;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.PuntoVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.repository.ArticuloRepository;
import com.ejemplo.repository.ClienteRepository;
import com.ejemplo.repository.CondicionIvaRepository;
import com.ejemplo.repository.FacturaVentaRepository;
import com.ejemplo.repository.PuntoVentaRepository;
import com.ejemplo.repository.TipoMonedaRepository;
import com.ejemplo.service.ReporteService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Component
public class CargaDatos implements CommandLineRunner {

    private final CondicionIvaRepository condicionIvaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final ClienteRepository clienteRepository;
    private final ArticuloRepository articuloRepository;
    private final FacturaVentaRepository facturaVentaRepository;
    private final ReporteService reporteService;

    public CargaDatos(CondicionIvaRepository condicionIvaRepository, TipoMonedaRepository tipoMonedaRepository,
                      PuntoVentaRepository puntoVentaRepository, ClienteRepository clienteRepository,
                      ArticuloRepository articuloRepository, FacturaVentaRepository facturaVentaRepository,
                      ReporteService reporteService) {
        this.condicionIvaRepository = condicionIvaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.clienteRepository = clienteRepository;
        this.articuloRepository = articuloRepository;
        this.facturaVentaRepository = facturaVentaRepository;
        this.reporteService = reporteService;
    }

    @Override
    public void run(String... args) throws Exception {
        CondicionIva responsableInscripto = crearCondicionIva(1, "IVA Responsable Inscripto");
        CondicionIva exento = crearCondicionIva(4, "IVA Sujeto Exento");
        CondicionIva consumidorFinal = crearCondicionIva(5, "Consumidor Final");
        CondicionIva monotributo = crearCondicionIva(6, "Responsable Monotributo");

        TipoMoneda pesos = null;
        // Catálogo de monedas de AFIP (ISO 4217 + código MonId de WSFEv1).
        for (MonedasAfip.Definicion definicion : MonedasAfip.catalogo()) {
            TipoMoneda moneda = new TipoMoneda();
            moneda.setCodigo(definicion.codigoIso());
            moneda.setCodigoAfip(definicion.codigoAfip());
            moneda.setDenominacion(definicion.denominacion());
            // Las monedas extranjeras quedan sin cotización: se resuelve contra
            // AFIP (FEParamGetCotizacion) al emitir, o se sincroniza desde la UI.
            moneda.setCotizacion("PES".equals(definicion.codigoAfip()) ? 1 : 0);
            moneda = tipoMonedaRepository.save(moneda);
            if ("PES".equals(definicion.codigoAfip())) {
                pesos = moneda;
            }
        }

        PuntoVenta central = crearPuntoVenta(1, "Sucursal Central", "San Martín 1200, Mendoza");
        PuntoVenta godoyCruz = crearPuntoVenta(2, "Sucursal Godoy Cruz", "Perú 450, Godoy Cruz");

        Cliente empresaTech = crearCliente("Empresa Tech S.A.", "30-71234567-8", "compras@empresatech.com", responsableInscripto);
        Cliente distribuidora = crearCliente("Distribuidora Andina S.R.L.", "30-70987654-3", "admin@andina.com", responsableInscripto);
        Cliente juanPerez = crearCliente("Juan Pérez", "20-30111222-5", "juanperez@gmail.com", monotributo);
        Cliente fundacion = crearCliente("Fundación Educar", "30-69876543-1", "contacto@educar.org", exento);

        Articulo notebook = crearArticulo("A001", "Notebook 15 pulgadas", 950000);
        Articulo mouse = crearArticulo("A002", "Mouse inalámbrico", 18000);
        Articulo teclado = crearArticulo("A003", "Teclado mecánico", 65000);
        Articulo monitor = crearArticulo("A004", "Monitor 24 pulgadas", 280000);
        Articulo auriculares = crearArticulo("A005", "Auriculares", 45000);
        Articulo webcam = crearArticulo("A006", "Webcam HD", 38000);
        Articulo cableHdmi = crearArticulo("A007", "Cable HDMI", 6500);
        Articulo pendrive = crearArticulo("A008", "Pendrive 64GB", 12000);

        FacturaVenta f1 = crearFactura(1001L, "2026-03-15", central, null, consumidorFinal, pesos, "EMITIDA");
        f1.agregarDetalle(mouse, 1);
        f1.agregarDetalle(cableHdmi, 2);
        guardarFactura(f1);

        FacturaVenta f2 = crearFactura(1002L, "2026-03-20", central, empresaTech, responsableInscripto, pesos, "EMITIDA");
        f2.agregarDetalle(notebook, 2);
        f2.agregarDetalle(monitor, 2);
        f2.agregarDetalle(teclado, 2);
        f2.agregarDetalle(mouse, 2);
        f2.agregarDetalle(webcam, 1);
        guardarFactura(f2);

        FacturaVenta f3 = crearFactura(1003L, "2026-03-28", godoyCruz, juanPerez, monotributo, pesos, "ANULADA");
        f3.agregarDetalle(auriculares, 1);
        f3.agregarDetalle(pendrive, 3);
        f3.setFechaAnulacion(Date.valueOf("2026-03-29"));
        f3.setObservaciones("Error en los datos del cliente");
        guardarFactura(f3);

        FacturaVenta f4 = crearFactura(1004L, "2026-04-02", godoyCruz, distribuidora, responsableInscripto, pesos, "EMITIDA");
        f4.agregarDetalle(monitor, 5);
        f4.agregarDetalle(cableHdmi, 10);
        f4.agregarDetalle(teclado, 5);
        guardarFactura(f4);

        FacturaVenta f5 = crearFactura(1005L, "2026-04-10", godoyCruz, null, consumidorFinal, pesos, "EMITIDA");
        f5.agregarDetalle(pendrive, 2);
        f5.agregarDetalle(mouse, 1);
        guardarFactura(f5);

        FacturaVenta f6 = crearFactura(1006L, "2026-04-18", central, empresaTech, responsableInscripto, pesos, "EMITIDA");
        f6.agregarDetalle(webcam, 4);
        f6.agregarDetalle(auriculares, 4);
        f6.agregarDetalle(mouse, 4);
        f6.agregarDetalle(teclado, 4);
        guardarFactura(f6);

        FacturaVenta f7 = crearFactura(1007L, "2026-05-05", central, fundacion, exento, pesos, "EMITIDA");
        f7.agregarDetalle(notebook, 3);
        f7.agregarDetalle(mouse, 3);
        guardarFactura(f7);

        FacturaVenta f8 = crearFactura(1008L, "2026-05-12", central, distribuidora, responsableInscripto, pesos, "ANULADA");
        f8.agregarDetalle(monitor, 1);
        f8.agregarDetalle(cableHdmi, 1);
        f8.agregarDetalle(webcam, 1);
        f8.setFechaAnulacion(Date.valueOf("2026-05-13"));
        f8.setObservaciones("El cliente rechazó la compra");
        guardarFactura(f8);

        List<Articulo> articulos = List.of(notebook, mouse, teclado, monitor,
                auriculares, webcam, cableHdmi, pendrive);
        cargarFacturasVariadas(articulos, central, godoyCruz, empresaTech, distribuidora,
                juanPerez, fundacion, responsableInscripto, exento, consumidorFinal, monotributo, pesos);

        System.out.println("Se cargaron " + facturaVentaRepository.count() + " facturas de ejemplo");

        reporteService.guardarArchivos();
    }

    /**
     * Completa la carga inicial hasta 100 comprobantes combinando Facturas A, B y C,
     * distintos clientes, puntos de venta, fechas, importes y estados
     * (EMITIDA con CAE simulado, ACTIVA pendiente de CAE y ANULADA).
     */
    private void cargarFacturasVariadas(List<Articulo> articulos, PuntoVenta central, PuntoVenta godoyCruz,
                                        Cliente empresaTech, Cliente distribuidora, Cliente juanPerez,
                                        Cliente fundacion, CondicionIva responsableInscripto, CondicionIva exento,
                                        CondicionIva consumidorFinal, CondicionIva monotributo, TipoMoneda pesos) {
        LocalDate fechaBase = LocalDate.of(2026, 1, 5);

        for (int i = 101; i <= 200; i++) {
            long numero = 1000L + i;
            // Las pendientes de CAE (ACTIVA) se fechan hoy: AFIP solo autoriza
            // comprobantes de productos con fecha dentro de ±5 días (error 10016).
            LocalDate fecha = i % 10 == 5 ? LocalDate.now() : fechaBase.plusDays((i - 101) * 2L);
            int tipoComprobante = i % 3 == 0 ? 1 : (i % 3 == 1 ? 6 : 11);

            Cliente cliente;
            CondicionIva condicionIva;
            if (tipoComprobante == 1) {
                cliente = i % 2 == 0 ? empresaTech : distribuidora;
                condicionIva = responsableInscripto;
            } else if (tipoComprobante == 6) {
                int variante = i % 3;
                if (variante == 0) {
                    cliente = null;
                    condicionIva = consumidorFinal;
                } else if (variante == 1) {
                    cliente = juanPerez;
                    condicionIva = monotributo;
                } else {
                    cliente = fundacion;
                    condicionIva = exento;
                }
            } else {
                int variante = i % 4;
                if (variante == 0) {
                    cliente = null;
                    condicionIva = consumidorFinal;
                } else if (variante == 1) {
                    cliente = juanPerez;
                    condicionIva = monotributo;
                } else if (variante == 2) {
                    cliente = fundacion;
                    condicionIva = exento;
                } else {
                    cliente = distribuidora;
                    condicionIva = responsableInscripto;
                }
            }

            String estado;
            if (i % 10 == 0) {
                estado = "ANULADA";
            } else if (i % 10 == 5) {
                estado = "ACTIVA";
            } else {
                estado = "EMITIDA";
            }

            if ("ACTIVA".equals(estado)) {
                // Las pendientes se dejan listas para pedir un CAE real en homologación:
                // Factura C (la del emisor configurado) a Consumidor Final. Los CUIT de los
                // clientes de ejemplo son ficticios y AFIP los rechaza (error 10015: no
                // registrado en el padrón).
                cliente = null;
                condicionIva = consumidorFinal;
                tipoComprobante = 11;
            }

            FacturaVenta factura = crearFacturaGenerada(
                    numero, fecha.toString(), i % 2 == 0 ? central : godoyCruz,
                    cliente, condicionIva, pesos, estado, tipoComprobante,
                    !"ACTIVA".equals(estado));

            if ("ANULADA".equals(estado)) {
                factura.setFechaAnulacion(Date.valueOf(fecha.plusDays(1)));
                factura.setObservaciones("Anulación de carga masiva");
            } else if ("ACTIVA".equals(estado)) {
                factura.setObservaciones("Pendiente de emisión de CAE (masivo)");
            }

            int cantidadItems = 1 + (i % 4);
            for (int j = 0; j < cantidadItems; j++) {
                Articulo articulo = articulos.get((i + j * 3) % articulos.size());
                double cantidad = 1 + ((i + j) % 5);
                factura.agregarDetalle(articulo, cantidad);
            }
            guardarFactura(factura);
        }
    }

    private FacturaVenta crearFacturaGenerada(Long numero, String fecha, PuntoVenta puntoVenta, Cliente cliente,
                                              CondicionIva condicionIva, TipoMoneda moneda, String estado,
                                              int tipoComprobante, boolean conCae) {
        FacturaVenta factura = FacturaVenta.builder()
                .numero(numero)
                .fechaEmision(Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .cliente(cliente)
                .condicionIva(condicionIva)
                .tipoMoneda(moneda)
                .estado(estado)
                .tipoComprobante(tipoComprobante)
                .build();

        if (conCae) {
            factura.setNumeroAfip(numero);
            factura.setResultadoAfip("A");
            factura.setCae("7400000000" + numero);
            factura.setCaeFechaVencimiento(Date.valueOf(LocalDate.parse(fecha).plusDays(10)));
        }
        return factura;
    }

    private CondicionIva crearCondicionIva(int codigo, String denominacion) {
        CondicionIva condicionIva = new CondicionIva();
        condicionIva.setCodigo(codigo);
        condicionIva.setDenominacion(denominacion);
        return condicionIvaRepository.save(condicionIva);
    }

    private PuntoVenta crearPuntoVenta(int numero, String descripcion, String domicilio) {
        PuntoVenta puntoVenta = new PuntoVenta();
        puntoVenta.setNumero(numero);
        puntoVenta.setDescripcion(descripcion);
        puntoVenta.setDomicilio(domicilio);
        return puntoVentaRepository.save(puntoVenta);
    }

    private Cliente crearCliente(String denominacion, String cuit, String email, CondicionIva condicionIva) {
        Cliente cliente = new Cliente();
        cliente.setDenominacion(denominacion);
        cliente.setCuit(cuit);
        cliente.setEmail(email);
        cliente.setCondicionIva(condicionIva);
        return clienteRepository.save(cliente);
    }

    private Articulo crearArticulo(String codigo, String denominacion, double precio) {
        Articulo articulo = new Articulo();
        articulo.setCodigo(codigo);
        articulo.setDenominacion(denominacion);
        articulo.setPrecioVenta(precio);
        return articuloRepository.save(articulo);
    }

    private FacturaVenta crearFactura(Long numero, String fecha, PuntoVenta puntoVenta, Cliente cliente,
                                      CondicionIva condicionIva, TipoMoneda moneda, String estado) {
        return FacturaVenta.builder()
                .numero(numero)
                .numeroAfip(numero)
                .fechaEmision(Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .cliente(cliente)
                .condicionIva(condicionIva)
                .tipoMoneda(moneda)
                .estado(estado)
                .tipoComprobante(condicionIva.getCodigo() == 1 ? 1 : 11)
                .resultadoAfip("A")
                .cae("7400000000" + numero)
                .caeFechaVencimiento(Date.valueOf(LocalDate.parse(fecha).plusDays(10)))
                .build();
    }

    private void guardarFactura(FacturaVenta factura) {
        factura.setImporteCobrado(factura.getImporteTotal());
        factura.calcularTotal();
        facturaVentaRepository.save(factura);
    }
}
