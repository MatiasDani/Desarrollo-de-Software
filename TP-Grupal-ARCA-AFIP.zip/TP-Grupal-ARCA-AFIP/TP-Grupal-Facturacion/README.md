# Facturación electrónica ARCA / AFIP

Trabajo práctico de **Desarrollo de Software** (U10). Sistema de facturación
electrónica en **Spring Boot 3.5 + Java 17** con integración real a los
web services de **ARCA (ex AFIP)** mediante **WSAA + WSFEv1**, y un frontend
web liviano incluido en el propio backend.

El circuito completo (autenticación, numeración y solicitud de CAE) está
implementado. El proyecto se entrega en **modo HOMOLOGACION** con un certificado
de prueba de AFIP incluido, de modo que se puede emitir un CAE real contra el
entorno de testing. El modo `SIMULADO` sigue disponible para desarrollar sin
conectividad.

---

## 1. Requisitos

- JDK 17 o superior.
- Maven no hace falta instalarlo: el proyecto incluye **Maven Wrapper** (`mvnw.cmd`).
- No requiere base de datos externa: usa **H2 en memoria**.

Verificar la versión de Java:

```bash
java -version
```

> En Windows, si el `java` del sistema es Java 8, no hace falta tocar nada: los
> scripts `run.cmd` / `run.ps1` buscan automáticamente un JDK 17+ instalado
> (por ejemplo en `%USERPROFILE%\.jdks`) y lo usan para Maven.
>
> Si preferís hacerlo a mano:
>
> ```powershell
> $env:JAVA_HOME='C:\ruta\a\jdk-17'
> ```

## 2. Ejecutar la aplicación

Desde la carpeta `TP-Grupal-Facturacion`, la forma más simple en Windows:

```bat
run.cmd
```

El script detecta un JDK 17+ y arranca Spring Boot. Abrir
<http://localhost:8080>.

Equivalentes:

```powershell
.\run.ps1                  # mismo arranque, desde PowerShell
.\mvnw.cmd spring-boot:run # solo si JAVA_HOME ya apunta a un JDK 17+
```

Para correr los tests:

```bat
run.cmd test
```

Para generar el JAR ejecutable:

```bat
run.cmd clean package
java -jar target/facturacion-0.0.1-SNAPSHOT.jar
```

---

## 3. Modos de integración

La integración se controla con la propiedad `afip.modo` en
`src/main/resources/application.properties`:

| Modo | Descripción |
| --- | --- |
| `DESHABILITADO` | No se puede emitir CAE. La factura se guarda sin autorización. |
| `SIMULADO` | Genera un CAE ficticio, sin llamadas a AFIP. Ideal para desarrollar sin conectividad. |
| `HOMOLOGACION` | **Valor por defecto.** Emite contra el entorno de pruebas de AFIP (`wswhomo`) usando el certificado de prueba incluido. |
| `PRODUCCION` | Emite contra el entorno real. Requiere certificado de producción y CUIT habilitado. |

### 3.1. Configuración por defecto (homologación)

El repositorio incluye las credenciales de prueba y ya viene configurado:

```properties
afip.modo=HOMOLOGACION
afip.cuit=20459662732
afip.tipo-comprobante=11
afip.alicuota-iva=21

afip.certificado-path=classpath:certificados/certificado_test.crt
afip.clave-path=classpath:certificados/privada_test.key
afip.ta-path=ta_wsfe.xml
```

El certificado (`CN=aliasTest`, `CUIT 20459662732`) está emitido por
`CN=Computadores Test` de AFIP y el servicio **wsfe** ya está delegado al alias.
Con esta configuración el botón **Probar conexión** llama a `FEDummy` y la
emisión obtiene un CAE real de homologación.

> **Ticket de Acceso (TA):** WSAA rechaza pedir un TA nuevo mientras el anterior
> siga vigente. Por eso el ticket se guarda en `afip.ta-path` (por defecto
> `ta_wsfe.xml`, en la raíz del proyecto) y se reutiliza hasta 2 minutos antes de
> su vencimiento. Si el archivo existe pero venció, la aplicación pide uno nuevo
> automáticamente. No hace falta tocar el archivo: si venció, se renueva solo.

### 3.2. Volver al modo simulado

```properties
afip.modo=SIMULADO
afip.cuit=20111111112
afip.tipo-comprobante=11
afip.alicuota-iva=21
```

En este modo el botón **Guardar y emitir CAE** y la acción **Emitir CAE** del
listado generan un CAE de 14 dígitos con vencimiento a 10 días. El detalle del
comprobante muestra el resultado `SIMULADO`.

### 3.3. Usar credenciales propias (PEM o PFX)

```properties
afip.modo=HOMOLOGACION
afip.cuit=<CUIT del emisor>

# Opción A: certificado + clave en PEM
afip.certificado-path=C:/certs/certificado_test.crt
afip.clave-path=C:/certs/privada_test.key

# Opción B: archivo PKCS#12 / PFX
# afip.pfx-path=C:/certs/facturacion.pfx
# afip.pfx-password=********

afip.wsaa-url=https://wsaahomo.afip.gov.ar/ws/services/LoginCms
afip.wsfe-url=https://wswhomo.afip.gov.ar/wsfev1/service.asmx

# Opcional: emitir el CAE automáticamente al crear la factura
afip.auto-emitir=false

# Timeout de las llamadas SOAP (ms)
afip.timeout-ms=30000

# Cliente de WSFEv1: true usa los stubs JAX-WS generados (com.ejemplo.afip.wsfe),
# false fuerza el cliente SOAP manual. Si JAX-WS no puede inicializarse, se
# degrada solo al cliente manual.
afip.usar-jaxws=true
```

> **Importante:** en un repositorio real no se deben versionar certificados,
> claves privadas ni contraseñas. Las credenciales incluidas son de
> homologación y solo sirven para probar. Usar variables de entorno o un archivo
> de configuración local fuera del control de versiones.

### 3.4. Obtener el certificado de homologación

1. Generar la clave privada y la solicitud de certificado (CSR):

   ```bash
   openssl genrsa -out privada_test.key 2048

   openssl req -new -key privada_test.key \
     -subj "/C=AR/O=TEST/CN=TEST/serialNumber=CUIT 20111111112" \
     -out solicitud_test.csr
   ```

2. Ingresar a **WSASS** (homologación) con Clave Fiscal, crear un alias,
   subir el CSR y descargar el certificado.
3. En el **Administrador de Relaciones**, delegar el servicio **wsfe** al
   alias creado.
4. Configurar las rutas del certificado y la clave en `application.properties`
   y cambiar `afip.modo` a `HOMOLOGACION`.

Los pasos completos están también explicados dentro de la vista
**Integración AFIP** de la aplicación.

---

## 4. Cómo funciona la integración

```
Frontend (app.js)
      │  POST /api/facturas/{id}/emitir
      ▼
FacturaService ──► AfipService
                        │
                        ├─ WSAA  (LoginCms) ──► Token + Sign
                        │      firma CMS PKCS#7 con BouncyCastle
                        │
                        └─ WSFEv1
                               ├─ FECompUltimoAutorizado
                               └─ FECAESolicitar ──► CAE + vencimiento
```

- **WSAA**: se firma el *Ticket de Requerimiento de Acceso* (TRA) en XML con la
  clave privada, se envía por SOAP a `LoginCms` y se obtiene un `Token`/`Sign`
  que se cachea hasta su vencimiento.
- **WSFEv1**:
  - `FECompUltimoAutorizado` obtiene el último número autorizado para el punto
    de venta y tipo de comprobante.
  - `FECAESolicitar` envía el comprobante con su número siguiente y devuelve el
    CAE o los errores/observaciones. Incluye `CondicionIVAReceptorId` a partir
    de la condición IVA de la factura (obligatorio desde la RG 5616) y el
    `MonId`/`MonCotiz` de la moneda de la factura.
  - `FEParamGetTiposMonedas` sincroniza el catálogo de monedas de AFIP y
    `FEParamGetCotizacion` resuelve la cotización de una divisa al emitir.
- El cliente de WSFEv1 usa por defecto los **stubs JAX-WS generados con XML-WS
  Tools** (paquete `com.ejemplo.afip.wsfe`, namespace `jakarta.*`). El cliente
  SOAP armado a mano queda como respaldo: si JAX-WS no puede inicializarse, el
  sistema se degrada automáticamente sin cortar el circuito de facturación.
  Se puede forzar con `afip.usar-jaxws`.
- Los rechazos de negocio de AFIP **no** se devuelven como error HTTP: la
  factura queda guardada con `resultadoAfip` y `motivoRechazo`, y el detalle lo
  muestra en la interfaz.
- Los errores de configuración o de red sí se informan como `502 Bad Gateway`.
- Antes de llamar a AFIP se valida que la fecha de emisión esté dentro de
  **N-5 / N+5 días** (regla de WSFEv1 para Concepto 1 = Productos, error
  `10016`). Si no, se responde `409 Conflict` con un mensaje claro.
- Un comprobante **con CAE** no se puede eliminar ni cambiar sus datos fiscales
  (fecha, punto de venta, cliente, condición IVA, moneda, tipo ni ítems):
  responde `409 Conflict`. Solo se permite la anulación lógica y editar
  observaciones; ante AFIP la anulación real es una Nota de Crédito. En la
  interfaz el botón de eliminar se oculta para esos comprobantes.
- Las facturas **pendientes** (`ACTIVA`) de la carga inicial se generan con la
  fecha del día, como Factura C a Consumidor Final, para poder pedirles un CAE
  real en homologación. Los CUIT de los clientes de ejemplo son ficticios: AFIP
  los rechaza (`10015`, no registrado en el padrón), así que para emitir a un
  cliente con CUIT hay que usar uno real.

### Monedas

Cada moneda maneja dos identificadores:

- **ISO 4217** (`ARS`, `USD`, `EUR`…): se usa en la vista para formatear
  importes con `Intl.NumberFormat`.
- **`MonId` de AFIP** (`PES`, `DOL`, `060`…): es el valor que exige WSFEv1.

El catálogo base (`afip/MonedasAfip.java`) replica las **49 monedas** que
devuelve `FEParamGetTiposMonedas` en homologación y se usa para sembrar la base
al arrancar. En modo `HOMOLOGACION`/`PRODUCCION` se puede refrescar contra AFIP
con `POST /api/afip/monedas/sincronizar` (botón **Sincronizar con AFIP** en la
vista Integración AFIP).

### Archivos principales del backend

| Archivo | Responsabilidad |
| --- | --- |
| `afip/AfipProperties.java` | Configuración `afip.*`. |
| `afip/AfipService.java` | Orquesta simulación, WSAA, WSFEv1 y sincronización de monedas. |
| `afip/MonedasAfip.java` | Catálogo ISO ↔ `MonId` de AFIP. |
| `afip/client/AfipWsaaClient.java` | Firma CMS y obtención/caché de Token/Sign. |
| `afip/client/AfipWsfeClient.java` | Fachada del cliente WSFEv1 (JAX-WS con respaldo SOAP). |
| `afip/client/AfipWsfeJaxwsClient.java` | Operaciones WSFEv1 usando los stubs JAX-WS generados. |
| `afip/client/AfipWsfeSoapClient.java` | Cliente SOAP manual de respaldo. |
| `afip/wsfe/**` | Stubs JAX-WS generados con XML-WS Tools desde el WSDL de WSFEv1. |
| `afip/client/AfipCredentialsLoader.java` | Carga credenciales PEM (PKCS#8/PKCS#1) y PFX/PKCS#12. |
| `service/FacturaService.java` | Alta, edición, anulación, emisión de CAE y DTOs. |
| `controller/FacturaRestController.java` | API REST de facturas. |
| `controller/CatalogoController.java` | Catálogos para los selects del frontend. |
| `controller/AfipController.java` | Estado, diagnóstico y limpieza de caché. |

---

## 5. API REST

| Método | Ruta | Descripción |
| --- | --- | --- |
| `GET` | `/api/facturas` | Lista todos los comprobantes. Filtros: `fechaDesde`, `fechaHasta`, `estado`, `montoMinimo`. |
| `GET` | `/api/facturas/paginado` | Listado paginado. Mismos filtros que `/api/facturas` más `pagina` (base 0, por defecto 0) y `tamanio` (por defecto 10, máximo 100). Devuelve `contenido`, `pagina`, `tamanio`, `totalElementos`, `totalPaginas`, `primera` y `ultima`. |
| `GET` | `/api/facturas/{id}` | Detalle completo con ítems y datos fiscales. |
| `POST` | `/api/facturas` | Crea una factura. |
| `PUT` | `/api/facturas/{id}` | Actualiza cabecera, estado u observaciones. |
| `POST` | `/api/facturas/{id}/emitir` | Solicita el CAE (real o simulado). |
| `DELETE` | `/api/facturas/{id}` | Elimina físicamente el registro (solo si no tiene CAE; si lo tiene, `409`). |
| `GET` | `/api/facturas/reporte/pdf` | Descarga el reporte PDF. |
| `GET` | `/api/facturas/reporte/excel` | Descarga el reporte Excel. |
| `GET` | `/api/catalogos` | Puntos de venta, clientes, condiciones IVA, monedas y artículos. |
| `GET` | `/api/afip/estado` | Estado de configuración de AFIP. |
| `POST` | `/api/afip/dummy` | Diagnóstico de conexión (o simulado). |
| `GET` | `/api/afip/monedas` | Catálogo local de monedas (ISO + `MonId` de AFIP). |
| `POST` | `/api/afip/monedas/sincronizar` | Refresca el catálogo con `FEParamGetTiposMonedas`. |
| `DELETE` | `/api/afip/cache` | Invalida el Token/Sign en memoria; el TA en disco se reutiliza hasta vencer. |

Ejemplo de emisión:

```bash
curl -X POST http://localhost:8080/api/facturas/1/emitir \
  -H "Content-Type: application/json" \
  -d '{"tipoComprobante":11}'
```

---

## 6. Frontend

El frontend se sirve como contenido estático desde
`src/main/resources/static` y no requiere build:

- `index.html`: estructura de las vistas (panel, comprobantes, nueva factura,
  integración AFIP) y modales.
- `styles.css`: diseño **mobile-first** (teléfono primero, con puntos de quiebre
  en 640, 980, 1024, 1100 y 1200 px), tarjetas, tablas, badges y notificaciones.
- `app.js`: lógica de la interfaz (módulo ES).
- `FacturaService.js`: cliente HTTP contra `/api`.

Vistas principales:

- **Panel de control**: total facturado, comprobantes con CAE, pendientes y
  anuladas, más los últimos movimientos.
- **Comprobantes**: filtros por fecha, estado y monto; listado paginado por el
  backend (selector de filas por página y navegación primera/anterior/siguiente/
  última); acciones de ver, emitir,
  anular y eliminar.
- **Nueva factura**: selects de catálogos, carga de ítems y resumen con IVA
  estimado según el tipo de comprobante.
- **Integración AFIP**: estado de la configuración (incluido el cliente WSFEv1
  activo), prueba de conexión, catálogo de monedas con sincronización contra
  AFIP, limpieza del token y guía de configuración.

Diseño responsivo (mobile-first):

- En teléfonos la barra lateral se convierte en una cabecera fija con la marca y
  un **botón hamburguesa** que despliega las opciones de operaciones como menú
  emergente (se cierra al elegir una opción, al tocar fuera o con `Escape`); el
  panel muestra 2 columnas y los formularios, filtros, ítems y grillas pasan a 1
  columna. Las tablas se desplazan en horizontal sin romper el layout.
- Los modales entran como hoja inferior en el teléfono y se centran en pantallas
  grandes. Los controles tienen un alto mínimo cómodo para tocar (44 px) y los
  campos usan 16 px en móvil para evitar el zoom automático de iOS.
- A partir de 980 px aparece la barra lateral fija de escritorio (el menú pasa a
  ser una columna siempre visible y desaparece el botón hamburguesa), a 1100 px
  el formulario de factura se parte en dos columnas y a 1200 px el panel usa 4
  tarjetas.

> Los archivos `.ts` que quedan en `static/` son material de referencia de una
> iteración anterior. El runtime real son los `.js`; no hay paso de compilación
> de TypeScript en el build de Maven.

---

## 7. Pruebas

`src/test/java/com/ejemplo/FacturacionApplicationTests.java` cubre:

- Reporte completo y filtros por estado/monto.
- Paginación del listado (tamaño, metadatos, sin solapamiento entre páginas,
  acotado del tamaño y de la página pedida, filtros combinados con paginación).
- Alta, edición, anulación lógica y eliminación física.
- Emisión de CAE en modo simulado.
- Bloqueo de eliminación y de cambios fiscales en facturas con CAE (la
  anulación lógica sigue permitida).
- Rechazo de la emisión con fecha fuera del rango N±5 de AFIP.
- Emisión de una factura pendiente de la carga inicial.

`src/test/java/com/ejemplo/FacturaPaginacionApiTest.java` verifica el endpoint
`GET /api/facturas/paginado` con `MockMvc`: estructura de la respuesta,
metadatos, acotado del tamaño máximo y filtros aplicados junto con la paginación.

`src/test/java/com/ejemplo/afip/client/AfipWsfeSoapClientTest.java` verifica el XML
de `FECAESolicitar` del cliente SOAP: `MonId=PES`/`MonCotiz` (error 10037 de
AFIP) y `CondicionIVAReceptorId` (RG 5616) en la posición esperada por WSFEv1.
`AfipWsfeJaxwsClientTest.java` verifica el armado del `FECAERequest` de los
stubs JAX-WS y el mapeo ISO ↔ `MonId` de las 49 monedas.

Los tests de contexto fuerzan `afip.modo=SIMULADO` para no depender de AFIP ni
consumir el TA de homologación.

```bash
run.cmd test
```

---

## 8. Solución de problemas

| Síntoma | Causa probable | Solución |
| --- | --- | --- |
| `UnsupportedClassVersionError` | Maven usa Java 8. | Usar `run.cmd` / `run.ps1` (detectan JDK 17+) o configurar `JAVA_HOME` a JDK 17+. |
| `Faltan credenciales AFIP` | `afip.modo` real sin certificado. | Configurar PEM o PFX, o volver a `SIMULADO`. |
| `AFIP no autorizó el comprobante` | Datos fiscales inválidos (CUIT, tipo de comprobante, punto de venta). | Revisar el motivo en el detalle y la delegación del servicio `wsfe`. |
| Error `10037` / falta `MonId` | AFIP exige moneda y cotización en el detalle. | El cliente envía `MonId` (p. ej. `PES`) y `MonCotiz` de la moneda de la factura; no quitar esos campos. |
| Error `10242` / `10246` | Falta la condición IVA del receptor (RG 5616). | Enviar `CondicionIVAReceptorId`; para Consumidor Final es `5`. |
| `El CEE ya posee un TA valido` | Se pidió un TA nuevo antes del vencimiento. | Reutilizar `ta_wsfe.xml` (`afip.ta-path`) o esperar el vencimiento. |
| Error de conexión / timeout | Sin salida a Internet o endpoint incorrecto. | Verificar `afip.wsaa-url`, `afip.wsfe-url` y `afip.timeout-ms`. |
| El CAE tarda o falla tras reiniciar | Token cacheado vencido. | Usar **Limpiar token WSAA** en la vista Integración AFIP. |

---

## 9. Notas de seguridad

- Los datos de AFIP se configuran por propiedades; para producción se
  recomienda externalizarlos con variables de entorno.
- No versionar certificados, claves privadas ni contraseñas.
- La anulación desde la interfaz es **lógica** (estado `ANULADA`). Ante AFIP,
  un comprobante autorizado se anula fiscalmente emitiendo una **Nota de
  Crédito**.
