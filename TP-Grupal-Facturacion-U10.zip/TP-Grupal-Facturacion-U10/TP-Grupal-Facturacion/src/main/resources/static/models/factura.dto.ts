export interface FacturaRequestDTO {
    puntoVentaId?: number;
    clienteId?: number | null;
    condicionIvaId?: number;
    tipoMonedaId?: number;
    fechaEmision?: string | Date;
    importeCobrado?: number;
    observaciones?: string;
    estado?: string;
    detalles?: FacturaDetalleRequestDTO[];
}

export interface FacturaDetalleRequestDTO {
    articuloId: number;
    cantidad: number;
}

export interface FacturaReporteDTO {
    id: number;
    numeroFactura: number;
    fechaEmision: string | Date;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    importeTotal: number;
    cantidadItems: number;
    estado: string;
}

export interface FacturaFiltrosDTO {
    fechaDesde?: string;
    fechaHasta?: string;
    estado?: string;
    montoMinimo?: number;
}
