export class FacturaService {
    baseUrl = 'http://localhost:8080/api/facturas';

    async obtenerFacturas(filtros) {
        let queryParams = '';
        if (filtros) {
            const params = new URLSearchParams();
            if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
            if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
            if (filtros.estado) params.append('estado', filtros.estado);
            if (filtros.montoMinimo !== undefined && !isNaN(filtros.montoMinimo)) {
                params.append('montoMinimo', filtros.montoMinimo.toString());
            }
            const qs = params.toString();
            if (qs) queryParams = `?${qs}`;
        }

        const response = await fetch(`${this.baseUrl}${queryParams}`);
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al obtener facturas');
        }
        return await response.json();
    }

    async crearFactura(factura) {
        const response = await fetch(this.baseUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(factura)
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al crear factura');
        }
        return await response.json();
    }

    async actualizarEstado(id, estado, observaciones) {
        const payload = {
            estado,
            observaciones
        };
        
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al actualizar factura');
        }
        return await response.json();
    }

    async eliminarFactura(id) {
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al eliminar factura');
        }
    }
}
