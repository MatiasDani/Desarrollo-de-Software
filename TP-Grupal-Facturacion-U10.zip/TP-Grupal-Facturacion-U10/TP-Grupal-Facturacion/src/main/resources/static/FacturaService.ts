import { FacturaRequestDTO, FacturaReporteDTO, FacturaFiltrosDTO } from './models/factura.dto.js';

export class FacturaService {
    private baseUrl = 'http://localhost:8080/api/facturas';

    async obtenerFacturas(filtros?: FacturaFiltrosDTO): Promise<FacturaReporteDTO[]> {
        let queryParams = '';
        if (filtros) {
            const params = new URLSearchParams();
            if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
            if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
            if (filtros.estado) params.append('estado', filtros.estado);
            if (filtros.montoMinimo !== undefined && !isNaN(filtros.montoMinimo)) {
                params.append('montoMinimo', filtros.montoMinimo.toString());
            }
            const qs = params.toString();
            if (qs) queryParams = `?${qs}`;
        }

        const response = await fetch(`${this.baseUrl}${queryParams}`);
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al obtener facturas');
        }
        return await response.json();
    }

    async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        const response = await fetch(this.baseUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(factura)
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al crear factura');
        }
        return await response.json();
    }

    async actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO> {
        const payload: FacturaRequestDTO = {
            estado,
            observaciones
        };
        
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al actualizar factura');
        }
        return await response.json();
    }

    async eliminarFactura(id: number): Promise<void> {
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Error al eliminar factura');
        }
    }
}
