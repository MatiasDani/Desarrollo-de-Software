import { FacturaService } from './FacturaService.js';

const facturaService = new FacturaService();
let detallesLocales = [];

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar fecha de hoy en el formulario de alta
    const hoy = new Date().toISOString().split('T')[0];
    const inputFecha = document.getElementById('alta-fecha');
    if (inputFecha) inputFecha.value = hoy;

    cargarFacturas();

    // Event listeners para los formularios
    document.getElementById('form-filtros')?.addEventListener('submit', handleBuscar);
    document.getElementById('btn-limpiar-filtros')?.addEventListener('click', handleLimpiarFiltros);
    document.getElementById('form-alta')?.addEventListener('submit', handleCrearFactura);
    document.getElementById('btn-add-detalle')?.addEventListener('click', handleAgregarDetalle);
});

async function cargarFacturas(filtros) {
    try {
        const facturas = await facturaService.obtenerFacturas(filtros);
        renderTablaFacturas(facturas);
    } catch (error) {
        console.error("Error al cargar facturas", error);
        alert(error.message || "Error al cargar facturas");
    }
}

function renderTablaFacturas(facturas) {
    const tbody = document.querySelector('#tabla-facturas tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (facturas.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" style="text-align:center; padding: 20px;">No se encontraron facturas.</td></tr>';
        return;
    }

    facturas.forEach(f => {
        const tr = document.createElement('tr');
        const estadoClase = f.estado === 'ANULADA' ? 'badge-anulada' : (f.estado === 'EMITIDA' ? 'badge-emitida' : 'badge-activa');
        const estadoBadge = `<span class="badge ${estadoClase}">${f.estado || 'ACTIVA'}</span>`;
        
        tr.innerHTML = `
            <td><strong>#${f.id}</strong></td>
            <td>${f.numeroFactura}</td>
            <td>${formatearFecha(f.fechaEmision)}</td>
            <td>${f.clienteDenominacion || 'Consumidor Final'}</td>
            <td>${f.condicionIva}</td>
            <td>${f.puntoVentaDescripcion}</td>
            <td>$${f.importeTotal.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            <td>${f.cantidadItems}</td>
            <td>${estadoBadge}</td>
            <td>
                ${f.estado !== 'ANULADA' ? `<button type="button" class="btn-warning" onclick="anularFactura(${f.id})">Anular</button>` : ''}
                <button type="button" class="btn-danger" onclick="eliminarFactura(${f.id})">Eliminar</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function formatearFecha(fecha) {
    if (!fecha) return '-';
    if (typeof fecha === 'string' && fecha.length >= 10) {
        const parts = fecha.substring(0, 10).split('-');
        if (parts.length === 3) {
            return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
    }
    return new Date(fecha).toLocaleDateString('es-AR');
}

async function handleBuscar(event) {
    event.preventDefault();
    const montoVal = document.getElementById('filtro-monto').value;
    const estadoSelect = document.getElementById('filtro-estado');
    const estadoVal = estadoSelect ? estadoSelect.value.trim() : '';
    const filtros = {
        fechaDesde: document.getElementById('filtro-fecha-desde').value || undefined,
        fechaHasta: document.getElementById('filtro-fecha-hasta').value || undefined,
        estado: estadoVal || undefined,
        montoMinimo: montoVal ? parseFloat(montoVal) : undefined
    };
    await cargarFacturas(filtros);
}

async function handleLimpiarFiltros() {
    document.getElementById('form-filtros').reset();
    await cargarFacturas();
}

function handleAgregarDetalle() {
    const articuloIdInput = document.getElementById('detalle-articulo');
    const cantidadInput = document.getElementById('detalle-cantidad');

    const articuloId = parseInt(articuloIdInput.value);
    const cantidad = parseFloat(cantidadInput.value);

    if (isNaN(articuloId) || isNaN(cantidad) || articuloId <= 0 || cantidad <= 0) {
        alert('Ingrese un ID de artículo y cantidad válidos (mayores a cero).');
        return;
    }

    detallesLocales.push({ articuloId, cantidad });
    renderTablaDetalles();
    
    // Limpiar inputs
    articuloIdInput.value = '';
    cantidadInput.value = '1';
}

function renderTablaDetalles() {
    const tbody = document.querySelector('#tabla-detalles tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (detallesLocales.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: var(--text-muted);">Sin ítems cargados</td></tr>';
        return;
    }

    detallesLocales.forEach((d, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>Artículo ID ${d.articuloId}</td>
            <td>${d.cantidad}</td>
            <td><button type="button" class="btn-danger" onclick="quitarDetalle(${index})">Quitar</button></td>
        `;
        tbody.appendChild(tr);
    });
}

window.quitarDetalle = function(index) {
    detallesLocales.splice(index, 1);
    renderTablaDetalles();
};

window.anularFactura = async function(id) {
    if (confirm(`¿Está seguro de anular la factura con ID ${id}? (Anulación lógica)`)) {
        try {
            await facturaService.actualizarEstado(id, 'ANULADA', 'Anulada manualmente desde interfaz web');
            alert(`Factura #${id} anulada con éxito.`);
            await cargarFacturas();
        } catch (error) {
            console.error("Error al anular", error);
            alert(error.message || "Error al anular la factura");
        }
    }
};

window.eliminarFactura = async function(id) {
    if (confirm(`¿Está seguro de eliminar definitivamente la factura con ID ${id}? (Eliminación física)`)) {
        try {
            await facturaService.eliminarFactura(id);
            alert(`Factura #${id} eliminada.`);
            await cargarFacturas();
        } catch (error) {
            console.error("Error al eliminar", error);
            alert(error.message || "Error al eliminar la factura");
        }
    }
};

async function handleCrearFactura(event) {
    event.preventDefault();

    if (detallesLocales.length === 0) {
        alert("Debe agregar al menos un detalle (renglón) a la factura.");
        return;
    }

    const clienteIdVal = document.getElementById('alta-cliente').value;

    const factura = {
        puntoVentaId: parseInt(document.getElementById('alta-punto-venta').value),
        clienteId: clienteIdVal ? parseInt(clienteIdVal) : null,
        condicionIvaId: parseInt(document.getElementById('alta-condicion-iva').value),
        tipoMonedaId: parseInt(document.getElementById('alta-tipo-moneda').value),
        fechaEmision: document.getElementById('alta-fecha').value,
        importeCobrado: 0,
        estado: 'ACTIVA',
        detalles: detallesLocales
    };

    try {
        const creada = await facturaService.crearFactura(factura);
        alert(`Factura #${creada.id} (N° ${creada.numeroFactura}) creada exitosamente.`);
        document.getElementById('form-alta').reset();
        
        // Restaurar valores por defecto
        const hoy = new Date().toISOString().split('T')[0];
        document.getElementById('alta-fecha').value = hoy;
        document.getElementById('alta-punto-venta').value = '1';
        document.getElementById('alta-condicion-iva').value = '1';
        document.getElementById('alta-tipo-moneda').value = '1';
        
        detallesLocales = [];
        renderTablaDetalles();
        await cargarFacturas();
    } catch (error) {
        console.error("Error al crear factura", error);
        alert(error.message || "Error al crear la factura");
    }
}
