package com.ejemplo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cliente")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"facturas"})
@EqualsAndHashCode(callSuper = true, exclude = {"facturas"})
public class Cliente extends AuditoriaApp {

    @Column(nullable = false)
    private String denominacion;

    private String cuit;

    private String domicilio;

    private String email;

    @ManyToOne
    @JoinColumn(name = "condicion_iva_id", nullable = false)
    private CondicionIva condicionIva;

    @OneToMany(mappedBy = "cliente")
    private List<FacturaVenta> facturas = new ArrayList<>();
}
