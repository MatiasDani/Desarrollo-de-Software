package com.ejemplo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FacturaRequestDTO {
    private Long puntoVentaId;
    private Long clienteId;
    private Long condicionIvaId;
    private Long tipoMonedaId;
    private Date fechaEmision;
    private double importeCobrado;
    private String observaciones;
    private String estado;
    private List<FacturaDetalleRequestDTO> detalles;
}
