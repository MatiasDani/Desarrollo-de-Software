package com.ejemplo.config;

import com.ejemplo.entity.Articulo;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.CondicionIva;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.PuntoVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.repository.ArticuloRepository;
import com.ejemplo.repository.ClienteRepository;
import com.ejemplo.repository.CondicionIvaRepository;
import com.ejemplo.repository.FacturaVentaRepository;
import com.ejemplo.repository.PuntoVentaRepository;
import com.ejemplo.repository.TipoMonedaRepository;
import com.ejemplo.service.ReporteService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.sql.Date;

@Component
public class CargaDatos implements CommandLineRunner {

    private final CondicionIvaRepository condicionIvaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final ClienteRepository clienteRepository;
    private final ArticuloRepository articuloRepository;
    private final FacturaVentaRepository facturaVentaRepository;
    private final ReporteService reporteService;

    public CargaDatos(CondicionIvaRepository condicionIvaRepository, TipoMonedaRepository tipoMonedaRepository,
                      PuntoVentaRepository puntoVentaRepository, ClienteRepository clienteRepository,
                      ArticuloRepository articuloRepository, FacturaVentaRepository facturaVentaRepository,
                      ReporteService reporteService) {
        this.condicionIvaRepository = condicionIvaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.clienteRepository = clienteRepository;
        this.articuloRepository = articuloRepository;
        this.facturaVentaRepository = facturaVentaRepository;
        this.reporteService = reporteService;
    }

    @Override
    public void run(String... args) throws Exception {
        CondicionIva responsableInscripto = crearCondicionIva(1, "IVA Responsable Inscripto");
        CondicionIva exento = crearCondicionIva(4, "IVA Sujeto Exento");
        CondicionIva consumidorFinal = crearCondicionIva(5, "Consumidor Final");
        CondicionIva monotributo = crearCondicionIva(6, "Responsable Monotributo");

        TipoMoneda pesos = new TipoMoneda();
        pesos.setCodigo("ARS");
        pesos.setDenominacion("Peso Argentino");
        pesos.setCotizacion(1);
        tipoMonedaRepository.save(pesos);

        PuntoVenta central = crearPuntoVenta(1, "Sucursal Central", "San Martín 1200, Mendoza");
        PuntoVenta godoyCruz = crearPuntoVenta(2, "Sucursal Godoy Cruz", "Perú 450, Godoy Cruz");

        Cliente empresaTech = crearCliente("Empresa Tech S.A.", "30-71234567-8", "compras@empresatech.com", responsableInscripto);
        Cliente distribuidora = crearCliente("Distribuidora Andina S.R.L.", "30-70987654-3", "admin@andina.com", responsableInscripto);
        Cliente juanPerez = crearCliente("Juan Pérez", "20-30111222-5", "juanperez@gmail.com", monotributo);
        Cliente fundacion = crearCliente("Fundación Educar", "30-69876543-1", "contacto@educar.org", exento);

        Articulo notebook = crearArticulo("A001", "Notebook 15 pulgadas", 950000);
        Articulo mouse = crearArticulo("A002", "Mouse inalámbrico", 18000);
        Articulo teclado = crearArticulo("A003", "Teclado mecánico", 65000);
        Articulo monitor = crearArticulo("A004", "Monitor 24 pulgadas", 280000);
        Articulo auriculares = crearArticulo("A005", "Auriculares", 45000);
        Articulo webcam = crearArticulo("A006", "Webcam HD", 38000);
        Articulo cableHdmi = crearArticulo("A007", "Cable HDMI", 6500);
        Articulo pendrive = crearArticulo("A008", "Pendrive 64GB", 12000);

        FacturaVenta f1 = crearFactura(1001L, "2026-03-15", central, null, consumidorFinal, pesos, "EMITIDA");
        f1.agregarDetalle(mouse, 1);
        f1.agregarDetalle(cableHdmi, 2);
        guardarFactura(f1);

        FacturaVenta f2 = crearFactura(1002L, "2026-03-20", central, empresaTech, responsableInscripto, pesos, "EMITIDA");
        f2.agregarDetalle(notebook, 2);
        f2.agregarDetalle(monitor, 2);
        f2.agregarDetalle(teclado, 2);
        f2.agregarDetalle(mouse, 2);
        f2.agregarDetalle(webcam, 1);
        guardarFactura(f2);

        FacturaVenta f3 = crearFactura(1003L, "2026-03-28", godoyCruz, juanPerez, monotributo, pesos, "ANULADA");
        f3.agregarDetalle(auriculares, 1);
        f3.agregarDetalle(pendrive, 3);
        f3.setFechaAnulacion(Date.valueOf("2026-03-29"));
        f3.setObservaciones("Error en los datos del cliente");
        guardarFactura(f3);

        FacturaVenta f4 = crearFactura(1004L, "2026-04-02", godoyCruz, distribuidora, responsableInscripto, pesos, "EMITIDA");
        f4.agregarDetalle(monitor, 5);
        f4.agregarDetalle(cableHdmi, 10);
        f4.agregarDetalle(teclado, 5);
        guardarFactura(f4);

        FacturaVenta f5 = crearFactura(1005L, "2026-04-10", godoyCruz, null, consumidorFinal, pesos, "EMITIDA");
        f5.agregarDetalle(pendrive, 2);
        f5.agregarDetalle(mouse, 1);
        guardarFactura(f5);

        FacturaVenta f6 = crearFactura(1006L, "2026-04-18", central, empresaTech, responsableInscripto, pesos, "EMITIDA");
        f6.agregarDetalle(webcam, 4);
        f6.agregarDetalle(auriculares, 4);
        f6.agregarDetalle(mouse, 4);
        f6.agregarDetalle(teclado, 4);
        guardarFactura(f6);

        FacturaVenta f7 = crearFactura(1007L, "2026-05-05", central, fundacion, exento, pesos, "EMITIDA");
        f7.agregarDetalle(notebook, 3);
        f7.agregarDetalle(mouse, 3);
        guardarFactura(f7);

        FacturaVenta f8 = crearFactura(1008L, "2026-05-12", central, distribuidora, responsableInscripto, pesos, "ANULADA");
        f8.agregarDetalle(monitor, 1);
        f8.agregarDetalle(cableHdmi, 1);
        f8.agregarDetalle(webcam, 1);
        f8.setFechaAnulacion(Date.valueOf("2026-05-13"));
        f8.setObservaciones("El cliente rechazó la compra");
        guardarFactura(f8);

        System.out.println("Se cargaron " + facturaVentaRepository.count() + " facturas");

        reporteService.guardarArchivos();
    }

    private CondicionIva crearCondicionIva(int codigo, String denominacion) {
        CondicionIva condicionIva = new CondicionIva();
        condicionIva.setCodigo(codigo);
        condicionIva.setDenominacion(denominacion);
        return condicionIvaRepository.save(condicionIva);
    }

    private PuntoVenta crearPuntoVenta(int numero, String descripcion, String domicilio) {
        PuntoVenta puntoVenta = new PuntoVenta();
        puntoVenta.setNumero(numero);
        puntoVenta.setDescripcion(descripcion);
        puntoVenta.setDomicilio(domicilio);
        return puntoVentaRepository.save(puntoVenta);
    }

    private Cliente crearCliente(String denominacion, String cuit, String email, CondicionIva condicionIva) {
        Cliente cliente = new Cliente();
        cliente.setDenominacion(denominacion);
        cliente.setCuit(cuit);
        cliente.setEmail(email);
        cliente.setCondicionIva(condicionIva);
        return clienteRepository.save(cliente);
    }

    private Articulo crearArticulo(String codigo, String denominacion, double precio) {
        Articulo articulo = new Articulo();
        articulo.setCodigo(codigo);
        articulo.setDenominacion(denominacion);
        articulo.setPrecioVenta(precio);
        return articuloRepository.save(articulo);
    }

    private FacturaVenta crearFactura(Long numero, String fecha, PuntoVenta puntoVenta, Cliente cliente,
                                      CondicionIva condicionIva, TipoMoneda moneda, String estado) {
        return FacturaVenta.builder()
                .numero(numero)
                .fechaEmision(Date.valueOf(fecha))
                .puntoVenta(puntoVenta)
                .cliente(cliente)
                .condicionIva(condicionIva)
                .tipoMoneda(moneda)
                .estado(estado)
                .resultadoAfip("A")
                .cae("7400000000" + numero)
                .build();
    }

    private void guardarFactura(FacturaVenta factura) {
        factura.setImporteCobrado(factura.getImporteTotal());
        factura.calcularTotal();
        facturaVentaRepository.save(factura);
    }
}
