package com.ejemplo.service;

import com.ejemplo.dto.FacturaReporteDTO;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

@Service
public class ReporteService {

    private final FacturaService facturaService;

    public ReporteService(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    public byte[] generarPdf() {
        List<FacturaReporteDTO> facturas = facturaService.obtenerReporte();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        ByteArrayOutputStream salida = new ByteArrayOutputStream();

        Document documento = new Document(PageSize.A4.rotate());
        try {
            PdfWriter.getInstance(documento, salida);
            documento.open();

            Font fuenteTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Paragraph titulo = new Paragraph("Reporte de Ventas", fuenteTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(15);
            documento.add(titulo);

            PdfPTable tabla = new PdfPTable(7);
            tabla.setWidthPercentage(100);

            String[] columnas = {"N° Factura", "Fecha", "Cliente", "Condición IVA", "Punto de Venta", "Importe Total", "Cant. Ítems"};
            Font fuenteEncabezado = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);
            for (String columna : columnas) {
                PdfPCell celda = new PdfPCell(new Phrase(columna, fuenteEncabezado));
                celda.setBackgroundColor(new Color(40, 70, 130));
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                celda.setPadding(5);
                tabla.addCell(celda);
            }

            Font fuenteDatos = FontFactory.getFont(FontFactory.HELVETICA, 9);
            double totalGeneral = 0;
            for (FacturaReporteDTO f : facturas) {
                tabla.addCell(new Phrase(String.valueOf(f.getNumeroFactura()), fuenteDatos));
                tabla.addCell(new Phrase(formatoFecha.format(f.getFechaEmision()), fuenteDatos));
                tabla.addCell(new Phrase(f.getClienteDenominacion(), fuenteDatos));
                tabla.addCell(new Phrase(f.getCondicionIva(), fuenteDatos));
                tabla.addCell(new Phrase(f.getPuntoVentaDescripcion(), fuenteDatos));
                tabla.addCell(new Phrase(String.format("$ %.2f", f.getImporteTotal()), fuenteDatos));
                tabla.addCell(new Phrase(String.valueOf(f.getCantidadItems()), fuenteDatos));
                totalGeneral = totalGeneral + f.getImporteTotal();
            }

            documento.add(tabla);

            Paragraph total = new Paragraph("Total facturado: $ " + String.format("%.2f", totalGeneral),
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12));
            total.setAlignment(Element.ALIGN_RIGHT);
            total.setSpacingBefore(10);
            documento.add(total);

            documento.close();
        } catch (Exception e) {
            throw new RuntimeException("Error al generar el PDF", e);
        }
        return salida.toByteArray();
    }

    public byte[] generarExcel() throws IOException {
        List<FacturaReporteDTO> facturas = facturaService.obtenerReporte();

        Workbook libro = new XSSFWorkbook();
        Sheet hoja = libro.createSheet("Facturas");

        CellStyle estiloFecha = libro.createCellStyle();
        estiloFecha.setDataFormat(libro.getCreationHelper().createDataFormat().getFormat("dd/mm/yyyy"));

        CellStyle estiloEncabezado = libro.createCellStyle();
        org.apache.poi.ss.usermodel.Font fuenteNegrita = libro.createFont();
        fuenteNegrita.setBold(true);
        estiloEncabezado.setFont(fuenteNegrita);

        String[] columnas = {"N° Factura", "Fecha Emisión", "Cliente", "Condición IVA", "Punto de Venta", "Importe Total", "Cantidad Ítems"};
        Row encabezado = hoja.createRow(0);
        for (int i = 0; i < columnas.length; i++) {
            Cell celda = encabezado.createCell(i);
            celda.setCellValue(columnas[i]);
            celda.setCellStyle(estiloEncabezado);
        }

        int numeroFila = 1;
        for (FacturaReporteDTO f : facturas) {
            Row fila = hoja.createRow(numeroFila);
            fila.createCell(0).setCellValue(f.getNumeroFactura());
            Cell celdaFecha = fila.createCell(1);
            celdaFecha.setCellValue(f.getFechaEmision());
            celdaFecha.setCellStyle(estiloFecha);
            fila.createCell(2).setCellValue(f.getClienteDenominacion());
            fila.createCell(3).setCellValue(f.getCondicionIva());
            fila.createCell(4).setCellValue(f.getPuntoVentaDescripcion());
            fila.createCell(5).setCellValue(f.getImporteTotal());
            fila.createCell(6).setCellValue(f.getCantidadItems());
            numeroFila++;
        }

        Row filaTotal = hoja.createRow(numeroFila);
        Cell textoTotal = filaTotal.createCell(4);
        textoTotal.setCellValue("TOTAL");
        textoTotal.setCellStyle(estiloEncabezado);
        filaTotal.createCell(5).setCellFormula("SUM(F2:F" + numeroFila + ")");

        for (int i = 0; i < columnas.length; i++) {
            hoja.autoSizeColumn(i);
        }

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        libro.write(salida);
        libro.close();
        return salida.toByteArray();
    }

    public void guardarArchivos() throws IOException {
        java.io.File carpeta = new java.io.File("reportes");
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }

        FileOutputStream pdf = new FileOutputStream("reportes/reporte-facturas.pdf");
        pdf.write(generarPdf());
        pdf.close();

        FileOutputStream excel = new FileOutputStream("reportes/reporte-facturas.xlsx");
        excel.write(generarExcel());
        excel.close();

        System.out.println("Reportes generados en la carpeta: " + carpeta.getAbsolutePath());
    }
}
