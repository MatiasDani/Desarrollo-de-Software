package com.ejemplo.entity;

import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public abstract class AuditoriaApp extends EntityId {

    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaAlta;

    @Temporal(TemporalType.TIMESTAMP)
    protected Date fechaModificacion;

    protected String usuarioAlta;

    protected String usuarioModificacion;

    @PrePersist
    public void prePersist() {
        fechaAlta = new Date();
        fechaModificacion = new Date();
        if (usuarioAlta == null) {
            usuarioAlta = "admin";
        }
        usuarioModificacion = usuarioAlta;
    }

    @PreUpdate
    public void preUpdate() {
        fechaModificacion = new Date();
    }
}
