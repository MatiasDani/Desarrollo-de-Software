package com.ejemplo.service;

import com.ejemplo.dto.FacturaDetalleRequestDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.entity.Articulo;
import com.ejemplo.entity.Cliente;
import com.ejemplo.entity.CondicionIva;
import com.ejemplo.entity.FacturaVenta;
import com.ejemplo.entity.PuntoVenta;
import com.ejemplo.entity.TipoMoneda;
import com.ejemplo.exception.RecursoNoEncontradoException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaService {

    private final EntityManager em;

    public FacturaService(EntityManager em) {
        this.em = em;
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> obtenerReporte() {
        String jpql = "SELECT new com.ejemplo.dto.FacturaReporteDTO(" +
                "   f.id, " +
                "   f.numero, " +
                "   f.fechaEmision, " +
                "   COALESCE(c.denominacion, 'Consumidor Final'), " +
                "   ci.denominacion, " +
                "   pv.descripcion, " +
                "   f.importeTotal, " +
                "   COUNT(d), " +
                "   f.estado " +
                ") " +
                "FROM FacturaVenta f " +
                "LEFT JOIN f.cliente c " +
                "JOIN f.condicionIva ci " +
                "JOIN f.puntoVenta pv " +
                "JOIN f.detalles d " +
                "GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, pv.descripcion, f.importeTotal, f.estado " +
                "ORDER BY f.numero";

        return em.createQuery(jpql, FacturaReporteDTO.class).getResultList();
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        StringBuilder jpql = new StringBuilder(
                "SELECT new com.ejemplo.dto.FacturaReporteDTO(" +
                "    f.id, f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'), " +
                "    ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d), f.estado" +
                ") " +
                "FROM FacturaVenta f " +
                "LEFT JOIN f.cliente c " +
                "JOIN f.condicionIva ci " +
                "JOIN f.puntoVenta pv " +
                "JOIN f.detalles d " +
                "WHERE 1=1 "
        );

        Map<String, Object> params = new HashMap<>();

        if (fechaDesde != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", estado.trim().toUpperCase());
        }
        if (montoMinimo != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }

        jpql.append("GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, pv.descripcion, f.importeTotal, f.estado ");
        jpql.append("ORDER BY f.numero");

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(), FacturaReporteDTO.class);
        params.forEach(query::setParameter);

        return query.getResultList();
    }

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.getPuntoVentaId() == null || dto.getCondicionIvaId() == null || dto.getTipoMonedaId() == null) {
            throw new IllegalArgumentException("Los IDs de PuntoVenta, CondicionIva y TipoMoneda son requeridos");
        }

        PuntoVenta puntoVenta = em.find(PuntoVenta.class, dto.getPuntoVentaId());
        CondicionIva condicionIva = em.find(CondicionIva.class, dto.getCondicionIvaId());
        TipoMoneda tipoMoneda = em.find(TipoMoneda.class, dto.getTipoMonedaId());
        
        if (puntoVenta == null) throw new RecursoNoEncontradoException("Punto de venta no encontrado con ID: " + dto.getPuntoVentaId());
        if (condicionIva == null) throw new RecursoNoEncontradoException("Condición de IVA no encontrada con ID: " + dto.getCondicionIvaId());
        if (tipoMoneda == null) throw new RecursoNoEncontradoException("Tipo de moneda no encontrado con ID: " + dto.getTipoMonedaId());

        Cliente cliente = null;
        if (dto.getClienteId() != null) {
            cliente = em.find(Cliente.class, dto.getClienteId());
            if (cliente == null) throw new RecursoNoEncontradoException("Cliente no encontrado con ID: " + dto.getClienteId());
        }

        FacturaVenta factura = new FacturaVenta();
        factura.setFechaEmision(dto.getFechaEmision() != null ? dto.getFechaEmision() : new Date());
        factura.setPuntoVenta(puntoVenta);
        factura.setCondicionIva(condicionIva);
        factura.setTipoMoneda(tipoMoneda);
        factura.setCliente(cliente);
        factura.setImporteCobrado(dto.getImporteCobrado());
        factura.setObservaciones(dto.getObservaciones());
        factura.setEstado(dto.getEstado() != null && !dto.getEstado().trim().isEmpty() ? dto.getEstado().trim().toUpperCase() : "ACTIVA");
        
        Long maxNum = em.createQuery("SELECT MAX(f.numero) FROM FacturaVenta f", Long.class).getSingleResult();
        factura.setNumero(maxNum == null ? 1 : maxNum + 1);

        if (dto.getDetalles() != null) {
            for (FacturaDetalleRequestDTO detDto : dto.getDetalles()) {
                Articulo articulo = em.find(Articulo.class, detDto.getArticuloId());
                if (articulo == null) {
                    throw new RecursoNoEncontradoException("Artículo no encontrado con ID: " + detDto.getArticuloId());
                }
                factura.agregarDetalle(articulo, detDto.getCantidad());
            }
        }
        
        em.persist(factura);
        em.flush();

        return new FacturaReporteDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getCliente() != null ? factura.getCliente().getDenominacion() : "Consumidor Final",
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getImporteTotal(),
                (long) factura.getDetalles().size(),
                factura.getEstado()
        );
    }

    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }

        if (dto.getEstado() != null && !dto.getEstado().trim().isEmpty()) {
            String nuevoEstado = dto.getEstado().trim().toUpperCase();
            factura.setEstado(nuevoEstado);
            if ("ANULADA".equals(nuevoEstado) && factura.getFechaAnulacion() == null) {
                factura.setFechaAnulacion(new Date());
            }
        }

        if (dto.getObservaciones() != null) {
            factura.setObservaciones(dto.getObservaciones());
        }

        if (dto.getFechaEmision() != null) {
            factura.setFechaEmision(dto.getFechaEmision());
        }

        if (dto.getPuntoVentaId() != null) {
            PuntoVenta pv = em.find(PuntoVenta.class, dto.getPuntoVentaId());
            if (pv == null) throw new RecursoNoEncontradoException("Punto de venta no encontrado con ID: " + dto.getPuntoVentaId());
            factura.setPuntoVenta(pv);
        }

        if (dto.getClienteId() != null) {
            Cliente cli = em.find(Cliente.class, dto.getClienteId());
            if (cli == null) throw new RecursoNoEncontradoException("Cliente no encontrado con ID: " + dto.getClienteId());
            factura.setCliente(cli);
        }

        if (dto.getCondicionIvaId() != null) {
            CondicionIva ci = em.find(CondicionIva.class, dto.getCondicionIvaId());
            if (ci == null) throw new RecursoNoEncontradoException("Condición de IVA no encontrada con ID: " + dto.getCondicionIvaId());
            factura.setCondicionIva(ci);
        }

        if (dto.getTipoMonedaId() != null) {
            TipoMoneda tm = em.find(TipoMoneda.class, dto.getTipoMonedaId());
            if (tm == null) throw new RecursoNoEncontradoException("Tipo de moneda no encontrado con ID: " + dto.getTipoMonedaId());
            factura.setTipoMoneda(tm);
        }

        if (dto.getImporteCobrado() > 0) {
            factura.setImporteCobrado(dto.getImporteCobrado());
        }

        // Actualizar ítems si fueron proporcionados en la petición
        if (dto.getDetalles() != null) {
            factura.getDetalles().clear();
            for (FacturaDetalleRequestDTO detDto : dto.getDetalles()) {
                Articulo articulo = em.find(Articulo.class, detDto.getArticuloId());
                if (articulo == null) {
                    throw new RecursoNoEncontradoException("Artículo no encontrado con ID: " + detDto.getArticuloId());
                }
                factura.agregarDetalle(articulo, detDto.getCantidad());
            }
        }

        factura.calcularTotal();
        em.merge(factura);

        return new FacturaReporteDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getCliente() != null ? factura.getCliente().getDenominacion() : "Consumidor Final",
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getImporteTotal(),
                (long) factura.getDetalles().size(),
                factura.getEstado()
        );
    }

    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con ID: " + id);
        }
        em.remove(factura);
    }
}
