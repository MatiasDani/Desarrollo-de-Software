package com.ejemplo;

import com.ejemplo.dto.FacturaDetalleRequestDTO;
import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.dto.FacturaRequestDTO;
import com.ejemplo.exception.RecursoNoEncontradoException;
import com.ejemplo.service.FacturaService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class FacturacionApplicationTests {

	@Autowired
	private FacturaService facturaService;

	@Test
	void elReporteTraeTodasLasFacturas() {
		List<FacturaReporteDTO> reporte = facturaService.obtenerReporte();
		assertTrue(reporte.size() >= 8);
	}

	@Test
	void filtraPorEstado() {
		List<FacturaReporteDTO> anuladas = facturaService.buscarFacturasFiltradas(null, null, "ANULADA", null);
		assertTrue(anuladas.size() >= 2);
	}

	@Test
	void filtraPorMontoMinimo() {
		List<FacturaReporteDTO> resultado = facturaService.buscarFacturasFiltradas(null, null, null, 1000000.0);
		for (FacturaReporteDTO f : resultado) {
			assertTrue(f.getImporteTotal() >= 1000000.0);
		}
	}

	@Test
	void crearActualizarYEliminarFactura() {
		// 1. Crear factura (POST)
		FacturaRequestDTO createDto = FacturaRequestDTO.builder()
				.puntoVentaId(1L)
				.clienteId(1L)
				.condicionIvaId(1L)
				.tipoMonedaId(1L)
				.fechaEmision(new Date())
				.observaciones("Factura de prueba")
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().articuloId(1L).cantidad(2.0).build(),
						FacturaDetalleRequestDTO.builder().articuloId(2L).cantidad(1.0).build()
				))
				.build();

		FacturaReporteDTO creada = facturaService.crear(createDto);
		assertNotNull(creada.getId());
		assertEquals("ACTIVA", creada.getEstado());
		assertEquals(2, creada.getCantidadItems());
		assertTrue(creada.getImporteTotal() > 0);

		// 2. Actualizar cabecera e ítems (PUT)
		FacturaRequestDTO updateDto = FacturaRequestDTO.builder()
				.observaciones("Factura modificada con nuevos ítems")
				.estado("ACTIVA")
				.detalles(List.of(
						FacturaDetalleRequestDTO.builder().articuloId(3L).cantidad(5.0).build()
				))
				.build();

		FacturaReporteDTO actualizada = facturaService.actualizar(creada.getId(), updateDto);
		assertEquals(creada.getId(), actualizada.getId());
		assertEquals(1, actualizada.getCantidadItems());

		// 3. Anular factura (Anulación lógica)
		FacturaRequestDTO anularDto = FacturaRequestDTO.builder()
				.estado("ANULADA")
				.observaciones("Anulada por test")
				.build();
		FacturaReporteDTO anulada = facturaService.actualizar(creada.getId(), anularDto);
		assertEquals("ANULADA", anulada.getEstado());

		// 4. Eliminar factura (Eliminación física)
		facturaService.eliminar(creada.getId());

		// 5. Verificar que ya no existe (404)
		assertThrows(RecursoNoEncontradoException.class, () -> {
			facturaService.actualizar(creada.getId(), updateDto);
		});
	}
}
