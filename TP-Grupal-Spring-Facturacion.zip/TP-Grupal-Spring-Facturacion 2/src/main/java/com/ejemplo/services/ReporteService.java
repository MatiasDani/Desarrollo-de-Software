package com.ejemplo.services;

import com.ejemplo.dto.FacturaReporteDTO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

@Service
public class ReporteService {

    private final FacturaService facturaService;

    public ReporteService(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    public byte[] generarPdf() throws DocumentException {
        List<FacturaReporteDTO> facturas = facturaService.obtenerReporte();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(documento, out);
        documento.open();

        Font fuenteTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
        Paragraph titulo = new Paragraph("Reporte de Ventas", fuenteTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        documento.add(titulo);

        PdfPTable tabla = new PdfPTable(7);
        tabla.setWidthPercentage(100);
        tabla.setWidths(new float[]{1.2f, 1.3f, 2.5f, 2.5f, 2f, 1.8f, 1.2f});

        String[] columnas = {"N° Factura", "Fecha", "Cliente", "Condición IVA", "Punto de Venta", "Importe Total", "Items"};
        Font fuenteEncabezado = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, BaseColor.WHITE);
        for (String columna : columnas) {
            PdfPCell celda = new PdfPCell(new Phrase(columna, fuenteEncabezado));
            celda.setBackgroundColor(BaseColor.DARK_GRAY);
            celda.setHorizontalAlignment(Element.ALIGN_CENTER);
            celda.setPadding(5);
            tabla.addCell(celda);
        }

        Font fuenteNormal = FontFactory.getFont(FontFactory.HELVETICA, 9);
        double total = 0;
        for (FacturaReporteDTO f : facturas) {
            tabla.addCell(new Phrase(String.valueOf(f.getNumeroFactura()), fuenteNormal));
            tabla.addCell(new Phrase(sdf.format(f.getFechaEmision()), fuenteNormal));
            tabla.addCell(new Phrase(f.getClienteDenominacion(), fuenteNormal));
            tabla.addCell(new Phrase(f.getCondicionIva(), fuenteNormal));
            tabla.addCell(new Phrase(f.getPuntoVentaDescripcion(), fuenteNormal));

            PdfPCell celdaImporte = new PdfPCell(new Phrase(String.format("$ %.2f", f.getImporteTotal()), fuenteNormal));
            celdaImporte.setHorizontalAlignment(Element.ALIGN_RIGHT);
            tabla.addCell(celdaImporte);

            PdfPCell celdaItems = new PdfPCell(new Phrase(String.valueOf(f.getCantidadItems()), fuenteNormal));
            celdaItems.setHorizontalAlignment(Element.ALIGN_CENTER);
            tabla.addCell(celdaItems);

            total = total + f.getImporteTotal();
        }
        documento.add(tabla);

        Paragraph pie = new Paragraph("Total facturado: $ " + String.format("%.2f", total),
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12));
        pie.setAlignment(Element.ALIGN_RIGHT);
        pie.setSpacingBefore(10);
        documento.add(pie);

        documento.close();
        return out.toByteArray();
    }

    public byte[] generarExcel() throws IOException {
        List<FacturaReporteDTO> facturas = facturaService.obtenerReporte();

        XSSFWorkbook libro = new XSSFWorkbook();
        Sheet hoja = libro.createSheet("Facturas");

        CellStyle estiloEncabezado = libro.createCellStyle();
        org.apache.poi.ss.usermodel.Font negrita = libro.createFont();
        negrita.setBold(true);
        estiloEncabezado.setFont(negrita);

        CellStyle estiloFecha = libro.createCellStyle();
        estiloFecha.setDataFormat(libro.createDataFormat().getFormat("dd/mm/yyyy"));

        CellStyle estiloImporte = libro.createCellStyle();
        estiloImporte.setDataFormat(libro.createDataFormat().getFormat("#,##0.00"));

        String[] columnas = {"N° Factura", "Fecha Emisión", "Cliente", "Condición IVA", "Punto de Venta", "Importe Total", "Cantidad Items"};
        Row encabezado = hoja.createRow(0);
        for (int i = 0; i < columnas.length; i++) {
            Cell celda = encabezado.createCell(i);
            celda.setCellValue(columnas[i]);
            celda.setCellStyle(estiloEncabezado);
        }

        int fila = 1;
        for (FacturaReporteDTO f : facturas) {
            Row row = hoja.createRow(fila);
            row.createCell(0).setCellValue(f.getNumeroFactura());

            Cell celdaFecha = row.createCell(1);
            celdaFecha.setCellValue(f.getFechaEmision());
            celdaFecha.setCellStyle(estiloFecha);

            row.createCell(2).setCellValue(f.getClienteDenominacion());
            row.createCell(3).setCellValue(f.getCondicionIva());
            row.createCell(4).setCellValue(f.getPuntoVentaDescripcion());

            Cell celdaImporte = row.createCell(5);
            celdaImporte.setCellValue(f.getImporteTotal());
            celdaImporte.setCellStyle(estiloImporte);

            row.createCell(6).setCellValue(f.getCantidadItems());
            fila++;
        }

        Row filaTotal = hoja.createRow(fila);
        Cell celdaTexto = filaTotal.createCell(4);
        celdaTexto.setCellValue("TOTAL");
        celdaTexto.setCellStyle(estiloEncabezado);
        Cell celdaTotal = filaTotal.createCell(5);
        celdaTotal.setCellFormula("SUM(F2:F" + fila + ")");
        celdaTotal.setCellStyle(estiloImporte);

        for (int i = 0; i < columnas.length; i++) {
            hoja.autoSizeColumn(i);
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        libro.write(out);
        libro.close();
        return out.toByteArray();
    }

    public void guardarReportes() throws IOException, DocumentException {
        File carpeta = new File("reportes");
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }

        FileOutputStream pdf = new FileOutputStream("reportes/reporte_facturas.pdf");
        pdf.write(generarPdf());
        pdf.close();

        FileOutputStream excel = new FileOutputStream("reportes/reporte_facturas.xlsx");
        excel.write(generarExcel());
        excel.close();

        System.out.println("Reportes generados en: " + carpeta.getAbsolutePath());
    }
}
