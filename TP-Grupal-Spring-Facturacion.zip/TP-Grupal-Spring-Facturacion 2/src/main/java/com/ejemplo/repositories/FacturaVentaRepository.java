package com.ejemplo.repositories;

import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.entities.FacturaVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FacturaVentaRepository extends JpaRepository<FacturaVenta, Long> {

    @Query("SELECT new com.ejemplo.dto.FacturaReporteDTO(" +
            "   f.numero, " +
            "   f.fechaEmision, " +
            "   COALESCE(c.denominacion, 'Consumidor Final'), " +
            "   ci.denominacion, " +
            "   pv.descripcion, " +
            "   f.importeTotal, " +
            "   COUNT(d) " +
            ") " +
            "FROM FacturaVenta f " +
            "LEFT JOIN f.cliente c " +
            "JOIN f.condicionIva ci " +
            "JOIN f.puntoVenta pv " +
            "JOIN f.detalles d " +
            "GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, pv.descripcion, f.importeTotal " +
            "ORDER BY f.numero")
    List<FacturaReporteDTO> obtenerReporte();
}
