package com.ejemplo.config;

import com.ejemplo.dto.FacturaReporteDTO;
import com.ejemplo.entities.*;
import com.ejemplo.repositories.*;
import com.ejemplo.services.FacturaService;
import com.ejemplo.services.ReporteService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class CargaDatos implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final RubroRepository rubroRepository;
    private final MarcaRepository marcaRepository;
    private final ArticuloRepository articuloRepository;
    private final ListaPrecioRepository listaPrecioRepository;
    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final ContactoRepository contactoRepository;
    private final DomicilioRepository domicilioRepository;
    private final ClienteRepository clienteRepository;
    private final FacturaVentaRepository facturaVentaRepository;
    private final FacturaService facturaService;
    private final ReporteService reporteService;

    private Usuario admin;
    private Date hoy;

    public CargaDatos(UsuarioRepository usuarioRepository, RubroRepository rubroRepository,
                      MarcaRepository marcaRepository, ArticuloRepository articuloRepository,
                      ListaPrecioRepository listaPrecioRepository, ListaPrecioArticuloRepository listaPrecioArticuloRepository,
                      PuntoVentaRepository puntoVentaRepository, TipoMonedaRepository tipoMonedaRepository,
                      CondicionIvaRepository condicionIvaRepository, ContactoRepository contactoRepository,
                      DomicilioRepository domicilioRepository, ClienteRepository clienteRepository,
                      FacturaVentaRepository facturaVentaRepository, FacturaService facturaService,
                      ReporteService reporteService) {
        this.usuarioRepository = usuarioRepository;
        this.rubroRepository = rubroRepository;
        this.marcaRepository = marcaRepository;
        this.articuloRepository = articuloRepository;
        this.listaPrecioRepository = listaPrecioRepository;
        this.listaPrecioArticuloRepository = listaPrecioArticuloRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.contactoRepository = contactoRepository;
        this.domicilioRepository = domicilioRepository;
        this.clienteRepository = clienteRepository;
        this.facturaVentaRepository = facturaVentaRepository;
        this.facturaService = facturaService;
        this.reporteService = reporteService;
    }

    @Override
    public void run(String... args) throws Exception {
        if (facturaVentaRepository.count() == 0) {
            cargarDatos();
        }

        List<FacturaReporteDTO> reporte = facturaService.obtenerReporte();
        System.out.println("\n--- REPORTE DE FACTURAS ---");
        for (FacturaReporteDTO f : reporte) {
            System.out.println("Factura N°: " + f.getNumeroFactura() + " | " + f.getFechaEmision() + " | " + f.getClienteDenominacion()
                    + " | " + f.getCondicionIva() + " | " + f.getPuntoVentaDescripcion()
                    + " | $" + f.getImporteTotal() + " | Items: " + f.getCantidadItems());
        }

        reporteService.guardarReportes();
    }

    private void cargarDatos() {
        hoy = new Date();

        admin = usuarioRepository.save(Usuario.builder()
                .usuario("admin").clave("123456").nombre("Luka").apellido("Garro").build());

        usuarioRepository.save(Usuario.builder()
                .usuario("vendedor").clave("vendedor123").nombre("Martina").apellido("Lopez").build());

        Rubro electronica = rubroRepository.save(Rubro.builder()
                .denominacion("Electrónica").codigo(101)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        Rubro informatica = rubroRepository.save(Rubro.builder()
                .denominacion("Informática").codigo(102)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        Marca sony = marcaRepository.save(Marca.builder()
                .denominacion("Sony").codigo(501)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        Marca samsung = marcaRepository.save(Marca.builder()
                .denominacion("Samsung").codigo(502)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        Marca logitech = marcaRepository.save(Marca.builder()
                .denominacion("Logitech").codigo(503)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        Articulo tv = guardarArticulo("ART-001", "Smart TV 55 Pulgadas", electronica, sony);
        Articulo celular = guardarArticulo("ART-002", "Celular Galaxy A55", electronica, samsung);
        Articulo monitor = guardarArticulo("ART-003", "Monitor 24 Pulgadas", informatica, samsung);
        Articulo mouse = guardarArticulo("ART-004", "Mouse Inalámbrico", informatica, logitech);
        Articulo teclado = guardarArticulo("ART-005", "Teclado Mecánico", informatica, logitech);

        ListaPrecio listaGeneral = listaPrecioRepository.save(ListaPrecio.builder()
                .codigo("LP-01").denominacion("Lista General de Contado")
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        ListaPrecioArticulo precioTv = guardarPrecio(listaGeneral, tv, 750000.0);
        ListaPrecioArticulo precioCelular = guardarPrecio(listaGeneral, celular, 520000.0);
        ListaPrecioArticulo precioMonitor = guardarPrecio(listaGeneral, monitor, 210000.0);
        ListaPrecioArticulo precioMouse = guardarPrecio(listaGeneral, mouse, 25000.0);
        ListaPrecioArticulo precioTeclado = guardarPrecio(listaGeneral, teclado, 68000.5);

        PuntoVenta central = puntoVentaRepository.save(PuntoVenta.builder()
                .numero(1).descripcion("Sucursal Central").tipoEmision("Facturación Electrónica").domicilioComercial("Av. San Martín 1050")
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        PuntoVenta godoyCruz = puntoVentaRepository.save(PuntoVenta.builder()
                .numero(2).descripcion("Sucursal Godoy Cruz").tipoEmision("Facturación Electrónica").domicilioComercial("Perito Moreno 320")
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        TipoMoneda peso = tipoMonedaRepository.save(TipoMoneda.builder()
                .codigoAfip("PES").denominacion("Peso Argentino").simbolo("$")
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        tipoMonedaRepository.save(TipoMoneda.builder()
                .codigoAfip("DOL").denominacion("Dólar Estadounidense").simbolo("US$")
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());

        CondicionIva responsableInscripto = guardarCondicionIva("IVA Responsable Inscripto", 1);
        CondicionIva exento = guardarCondicionIva("IVA Sujeto Exento", 4);
        CondicionIva consumidorFinal = guardarCondicionIva("Consumidor Final", 5);
        CondicionIva monotributo = guardarCondicionIva("Responsable Monotributo", 6);

        Cliente juan = guardarCliente("20-38123456-9", "Juan Pérez", "juanperez@correo.com", "2614000000", "2615555555", "Las Heras", "450");
        Cliente empresa = guardarCliente("30-71234567-8", "Empresa Tech S.A.", "compras@empresatech.com", "2614231000", "2616123456", "Belgrano", "1200");
        Cliente fundacion = guardarCliente("30-70987654-1", "Fundación Andes", "contacto@fundacionandes.org", "2614445566", "2617778899", "Colón", "85");

        FacturaVenta f1 = crearFactura(1001L, "2026-03-15", null, consumidorFinal, central, peso, "EMITIDA");
        f1.addDetalle(crearDetalle(precioMouse, 2));
        f1.addDetalle(crearDetalle(precioTeclado, 1));
        guardarFactura(f1);

        FacturaVenta f2 = crearFactura(1002L, "2026-03-20", empresa, responsableInscripto, central, peso, "EMITIDA");
        f2.addDetalle(crearDetalle(precioMonitor, 3));
        f2.addDetalle(crearDetalle(precioMouse, 3));
        f2.addDetalle(crearDetalle(precioTeclado, 3));
        f2.addDetalle(crearDetalle(precioCelular, 1));
        f2.addDetalle(crearDetalle(precioTv, 1));
        guardarFactura(f2);

        FacturaVenta f3 = crearFactura(1003L, "2026-04-02", juan, monotributo, godoyCruz, peso, "EMITIDA");
        f3.addDetalle(crearDetalle(precioTv, 2));
        guardarFactura(f3);

        FacturaVenta f4 = crearFactura(1004L, "2026-04-18", fundacion, exento, central, peso, "ANULADA");
        f4.addDetalle(crearDetalle(precioCelular, 1));
        f4.addDetalle(crearDetalle(precioMouse, 1));
        f4.setFechaAnulacion(java.sql.Date.valueOf("2026-04-19"));
        f4.setObservaciones("Anulada por error en los datos del cliente");
        guardarFactura(f4);

        FacturaVenta f5 = crearFactura(1005L, "2026-05-05", null, consumidorFinal, godoyCruz, peso, "EMITIDA");
        f5.addDetalle(crearDetalle(precioCelular, 1));
        f5.addDetalle(crearDetalle(precioMouse, 1));
        f5.addDetalle(crearDetalle(precioTeclado, 1));
        guardarFactura(f5);

        FacturaVenta f6 = crearFactura(1006L, "2026-06-10", empresa, responsableInscripto, godoyCruz, peso, "EMITIDA");
        f6.addDetalle(crearDetalle(precioMonitor, 10));
        f6.addDetalle(crearDetalle(precioTeclado, 10));
        guardarFactura(f6);

        System.out.println("\n>>> Datos iniciales cargados correctamente");
    }

    private Articulo guardarArticulo(String codigo, String denominacion, Rubro rubro, Marca marca) {
        return articuloRepository.save(Articulo.builder()
                .codigo(codigo).denominacion(denominacion).rubro(rubro).marca(marca)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());
    }

    private ListaPrecioArticulo guardarPrecio(ListaPrecio lista, Articulo articulo, double precio) {
        return listaPrecioArticuloRepository.save(ListaPrecioArticulo.builder()
                .listaPrecio(lista).articulo(articulo).precioVenta(precio)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());
    }

    private CondicionIva guardarCondicionIva(String denominacion, int codigoAfip) {
        return condicionIvaRepository.save(CondicionIva.builder()
                .denominacion(denominacion).codigoAfip(codigoAfip)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());
    }

    private Cliente guardarCliente(String cuit, String denominacion, String email, String telefono, String celular, String calle, String numero) {
        Contacto contacto = contactoRepository.save(Contacto.builder()
                .email(email).telefono(telefono).celular(celular).build());

        Domicilio domicilio = domicilioRepository.save(Domicilio.builder()
                .nombreCalle(calle).numeroCalle(numero).build());

        return clienteRepository.save(Cliente.builder()
                .cuitCuil(cuit).denominacion(denominacion).contacto(contacto).domicilio(domicilio)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin).build());
    }

    private FacturaVenta crearFactura(Long numero, String fecha, Cliente cliente, CondicionIva condicionIva,
                                      PuntoVenta puntoVenta, TipoMoneda moneda, String estado) {
        FacturaVenta factura = FacturaVenta.builder()
                .numero(numero)
                .fechaEmision(java.sql.Date.valueOf(fecha))
                .cliente(cliente)
                .condicionIva(condicionIva)
                .puntoVenta(puntoVenta)
                .tipoMoneda(moneda)
                .estado(estado)
                .fechaAlta(hoy).fechaModificacion(hoy).usuarioCarga(admin).usuarioModificacion(admin)
                .build();

        if (estado.equals("EMITIDA")) {
            factura.setCae("7612" + numero + "000123");
            factura.setCaeFechaVencimiento(java.sql.Date.valueOf(java.time.LocalDate.parse(fecha).plusDays(10)));
            factura.setResultadoAfip("A");
        }
        return factura;
    }

    private FacturaVentaDetalle crearDetalle(ListaPrecioArticulo precio, double cantidad) {
        double subtotal = cantidad * precio.getPrecioVenta();
        double neto = Math.round(subtotal / 1.21 * 100.0) / 100.0;
        double iva = Math.round((subtotal - neto) * 100.0) / 100.0;

        return FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precio)
                .descripcion(precio.getArticulo().getDenominacion())
                .cantidad(cantidad)
                .precioUnitario(precio.getPrecioVenta())
                .porcentajeBonificacion(0)
                .importeNeto(neto)
                .importeIva(iva)
                .importeSubtotal(subtotal)
                .build();
    }

    private void guardarFactura(FacturaVenta factura) {
        double total = 0;
        for (FacturaVentaDetalle d : factura.getDetalles()) {
            total = total + d.getImporteSubtotal();
        }
        factura.setImporteTotal(total);

        if (factura.getEstado().equals("ANULADA")) {
            factura.setImporteCobrado(0);
            factura.setImporteSaldo(0);
        } else {
            factura.setImporteCobrado(total);
            factura.setImporteSaldo(0);
        }

        facturaVentaRepository.save(factura);
    }
}
