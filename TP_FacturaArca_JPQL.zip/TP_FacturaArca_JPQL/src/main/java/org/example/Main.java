package org.example;

import org.example.entities.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Date;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            //Recreo la base y carga todos los datos de prueba
            CargadorDatos.cargarDatos(em);

            System.out.println("\n========== INICIO DE CONSULTAS JPQL ==========\n");

            // Llamandas a cada ejercicio:
            ejercicio01(em);
            ejercicio02(em);
            ejercicio03(em);
            ejercicio04(em);
            ejercicio05(em);
            ejercicio06(em);
            ejercicio07(em);
            ejercicio08(em);
            ejercicio09(em);
            ejercicio10(em);
            ejercicio11(em);
            ejercicio12(em);
            ejercicio13(em);
            ejercicio14(em);
            ejercicio15(em);
            ejercicio16(em);
            ejercicio17(em);
            ejercicio18(em);
            ejercicio19(em);
            ejercicio20(em);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    // EJERCICIO 1
    public static void ejercicio01(EntityManager em) {
        System.out.println("--- Ejercicio 1 ---");
        String jpql = "SELECT fv FROM FacturaVenta fv";
        List<FacturaVenta> facturas = em.createQuery(jpql, FacturaVenta.class).getResultList();

        for (FacturaVenta f : facturas) {
            System.out.println("Factura Nro: " + f.getNumero() + " | Fecha: " + f.getFechaEmision() + " | Total: $" + f.getImporteTotal());
        }
    }

    //EJERCICIO 2
    public static void ejercicio02(EntityManager em) {
        System.out.println("--- Ejercicio 2 ---");
        String jpql = "SELECT fv.numero, fv.fechaEmision, fv.importeTotal FROM FacturaVenta fv";
        List<Object[]> resultados = em.createQuery(jpql, Object[].class).getResultList();

        for (Object[] fila : resultados) {
            Long numero = (Long) fila[0];
            Date fecha = (Date) fila[1];
            Double total = (Double) fila[2];
            System.out.println("Nro: " + numero + " | Fecha: " + fecha + " | Total: $" + total);
        }
    }

    //EJERCICIO 3
    public static void ejercicio03(EntityManager em) {
        System.out.println("--- Ejercicio 3 ---");
        String jpql = "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :denominacion";

        List<Articulo> articulos = em.createQuery(jpql, Articulo.class)
                .setParameter("denominacion", "Electrónica")
                .getResultList();

        for (Articulo a : articulos) {
            System.out.println("Codigo: " + a.getCodigo() + " | Denominación: " + a.getDenominacion() +
                    " | Rubro: " + a.getRubro().getDenominacion());
        }
    }

    //EJERCICIO 4
    public static void ejercicio04(EntityManager em) {
        System.out.println("--- Ejercicio 4 ---");
        String jpql = "SELECT f FROM FacturaVenta f WHERE f.fechaEmision BETWEEN :fechaDesde AND :fechaHasta";

        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            Date desde = sdf.parse("2024-01-01");
            Date hasta = sdf.parse("2024-03-15");

            List<FacturaVenta> facturas = em.createQuery(jpql, FacturaVenta.class)
                    .setParameter("fechaDesde", desde)
                    .setParameter("fechaHasta", hasta)
                    .getResultList();

            for (FacturaVenta f : facturas) {
                System.out.println("Factura Nro: " + f.getNumero() + " | Fecha: " + f.getFechaEmision() +
                        " | Total: $" + f.getImporteTotal());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //EJERCICIO 5
    public static void ejercicio05(EntityManager em) {
        System.out.println("--- Ejercicio 5 ---");
        String jpql = "SELECT f FROM FacturaVenta f " +
                "WHERE f.estado = :estado " +
                "AND f.importeTotal > :minImporte " +
                "AND f.fechaAnulacion IS NULL";

        List<FacturaVenta> facturas = em.createQuery(jpql, FacturaVenta.class)
                .setParameter("estado", "EMITIDA")
                .setParameter("minImporte", 10000.0)
                .getResultList();

        for (FacturaVenta f : facturas) {
            System.out.println("Factura Nro: " + f.getNumero() + " | Total: $" + f.getImporteTotal() +
                    " | Estado: " + f.getEstado() + " | Anulación: " + f.getFechaAnulacion());
        }
    }

    //EJERCICIO 6
    public static void ejercicio06(EntityManager em) {
        System.out.println("--- Ejercicio 6 ---");
        String jpql = "SELECT c FROM Cliente c " +
                "WHERE LOWER(c.denominacion) LIKE :denominacionPatron " +
                "OR c.cuitCuil LIKE :cuitPrefijo";

        List<Cliente> clientes = em.createQuery(jpql, Cliente.class)
                .setParameter("denominacionPatron", "%tech%")
                .setParameter("cuitPrefijo", "20-%")
                .getResultList();

        for (Cliente c : clientes) {
            System.out.println("Cliente: " + c.getDenominacion() + " | CUIT: " + c.getCuitCuil());
        }
    }

    //EJERCICIO 7
    public static void ejercicio07(EntityManager em) {
        System.out.println("--- Ejercicio 7 ---");
        String jpql = "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC";

        List<String> estados = em.createQuery(jpql, String.class).getResultList();

        for (String estado : estados) {
            System.out.println("Estado registrado: " + estado);
        }
    }

    //EJERCICIO 8
    public static void ejercicio08(EntityManager em) {
        System.out.println("--- Ejercicio 8 ---");
        String jpql = "SELECT COUNT(f), SUM(f.importeTotal), AVG(f.importeTotal) " +
                "FROM FacturaVenta f WHERE f.estado = :estado";

        Object[] resultado = em.createQuery(jpql, Object[].class)
                .setParameter("estado", "EMITIDA")
                .getSingleResult();

        Long cantidad = (Long) resultado[0];
        Double suma = (Double) resultado[1];
        Double promedio = (Double) resultado[2];

        System.out.println("Facturas emitidas: " + cantidad + " | Suma total: $" + suma +
                " | Promedio: $" + promedio);
    }

    //EJERCICIO 9
    public static void ejercicio09(EntityManager em) {
        System.out.println("--- Ejercicio 9 ---");
        String jpql = "SELECT pv FROM PuntoVenta pv WHERE pv.numero IN (:numeros)";

        List<Integer> numerosBuscados = java.util.Arrays.asList(1, 2, 5);

        List<PuntoVenta> pvs = em.createQuery(jpql, PuntoVenta.class)
                .setParameter("numeros", numerosBuscados)
                .getResultList();

        for (PuntoVenta pv : pvs) {
            System.out.println("Punto de Venta Nro: " + pv.getNumero() + " - " + pv.getDescripcion());
        }
    }

    //EJERCICIO 10
    public static void ejercicio10(EntityManager em) {
        System.out.println("--- Ejercicio 10 ---");
        String jpql = "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :usuario";

        List<FacturaVenta> facturas = em.createQuery(jpql, FacturaVenta.class)
                .setParameter("usuario", "jperez")
                .getResultList();

        for (FacturaVenta f : facturas) {
            System.out.println("Factura Nro: " + f.getNumero() + " cargada por: " + f.getUsuarioCarga().getUsuario());
        }
    }

    //EJERCICIO 11
    public static void ejercicio11(EntityManager em) {
        System.out.println("--- Ejercicio 11 ---");
        String jpql = "SELECT d FROM FacturaVentaDetalle d " +
                "INNER JOIN d.factura f " +
                "WHERE f.puntoVenta.numero = :pvNumero";

        List<FacturaVentaDetalle> detalles = em.createQuery(jpql, FacturaVentaDetalle.class)
                .setParameter("pvNumero", 1)
                .getResultList();

        for (FacturaVentaDetalle d : detalles) {
            System.out.println("Detalle: " + d.getDescripcion() + " | Subtotal: $" + d.getImporteSubtotal() +
                    " (Factura Nro " + d.getFactura().getNumero() + ")");
        }
    }

    //EJERCICIO 12
    public static void ejercicio12(EntityManager em) {
        System.out.println("--- Ejercicio 12 ---");
        String jpql = "SELECT a.denominacion, m.denominacion FROM Articulo a LEFT JOIN a.marca m";

        List<Object[]> resultados = em.createQuery(jpql, Object[].class).getResultList();

        for (Object[] fila : resultados) {
            String art = (String) fila[0];
            String marca = fila[1] != null ? (String) fila[1] : "[SIN MARCA]";
            System.out.println("Artículo: " + art + " | Marca: " + marca);
        }
    }

    //EJERCICIO 13
    public static void ejercicio13(EntityManager em) {
        System.out.println("--- Ejercicio 13 ---");
        String jpql = "SELECT DISTINCT f FROM FacturaVenta f " +
                "JOIN f.detalles d " +
                "JOIN d.listaPrecioArticulo lpa " +
                "JOIN lpa.articulo a " +
                "JOIN a.marca m " +
                "WHERE m.denominacion = :nombreMarca";

        List<FacturaVenta> facturas = em.createQuery(jpql, FacturaVenta.class)
                .setParameter("nombreMarca", "Logitech")
                .getResultList();

        for (FacturaVenta f : facturas) {
            System.out.println("Factura Nro " + f.getNumero() + " contiene artículos de la marca buscada.");
        }
    }

    //EJERCICIO 14
    public static void ejercicio14(EntityManager em) {
        System.out.println("--- Ejercicio 14 ---");
        String jpql = "SELECT f FROM FacturaVenta f " +
                "WHERE f.importeTotal > (SELECT AVG(f2.importeTotal) FROM FacturaVenta f2)";

        List<FacturaVenta> facturas = em.createQuery(jpql, FacturaVenta.class).getResultList();

        for (FacturaVenta f : facturas) {
            System.out.println("Factura Nro " + f.getNumero() + " | Importe: $" + f.getImporteTotal());
        }
    }

    //EJERCICIO 15
    public static void ejercicio15(EntityManager em) {
        System.out.println("--- Ejercicio 15 ---");
        String jpql = "SELECT pv.descripcion, COUNT(f), SUM(f.importeTotal) " +
                "FROM FacturaVenta f " +
                "JOIN f.puntoVenta pv " +
                "GROUP BY pv.descripcion";

        List<Object[]> resultados = em.createQuery(jpql, Object[].class).getResultList();

        for (Object[] fila : resultados) {
            String desc = (String) fila[0];
            Long cant = (Long) fila[1];
            Double suma = (Double) fila[2];
            System.out.println("Punto de Venta: " + desc + " | Facturas: " + cant + " | Total Facturado: $" + suma);
        }
    }

    //EJERCICIO 16
    public static void ejercicio16(EntityManager em) {
        System.out.println("--- Ejercicio 16 ---");
        String jpql = "SELECT u.usuario, COUNT(f) " +
                "FROM FacturaVenta f " +
                "JOIN f.usuarioCarga u " +
                "GROUP BY u.usuario " +
                "HAVING COUNT(f) > :cantidadMinima";

        List<Object[]> resultados = em.createQuery(jpql, Object[].class)
                .setParameter("cantidadMinima", 5L)
                .getResultList();

        for (Object[] fila : resultados) {
            System.out.println("Usuario: " + fila[0] + " | Total facturas: " + fila[1]);
        }
    }

    //EJERCICIO 17
    public static void ejercicio17(EntityManager em) {
        System.out.println("--- Ejercicio 17 ---");
        String jpql = "SELECT m.denominacion, SUM(d.cantidad), SUM(d.importeSubtotal) " +
                "FROM FacturaVentaDetalle d " +
                "JOIN d.listaPrecioArticulo lpa " +
                "JOIN lpa.articulo a " +
                "JOIN a.marca m " +
                "GROUP BY m.denominacion";

        List<Object[]> resultados = em.createQuery(jpql, Object[].class).getResultList();

        for (Object[] fila : resultados) {
            String marca = (String) fila[0];
            Double cantidad = (Double) fila[1];
            Double subtotal = (Double) fila[2];
            System.out.println("Marca: " + marca + " | Unidades vendidas: " + cantidad + " | Total: $" + subtotal);
        }
    }

    //EJERCICIO 18
    public static void ejercicio18(EntityManager em) {
        System.out.println("--- Ejercicio 18 ---");
        String jpql = "SELECT m FROM Marca m WHERE EXISTS (" +
                "  SELECT d FROM FacturaVentaDetalle d " +
                "  WHERE d.listaPrecioArticulo.articulo.marca = m" +
                ")";

        List<Marca> marcas = em.createQuery(jpql, Marca.class).getResultList();

        for (Marca m : marcas) {
            System.out.println("Marca con ventas: " + m.getDenominacion());
        }
    }

    //EJERCICIO 19
    public static void ejercicio19(EntityManager em) {
        System.out.println("--- Ejercicio 19 ---");
        String jpql = "SELECT a FROM Articulo a WHERE NOT EXISTS (" +
                "  SELECT d FROM FacturaVentaDetalle d " +
                "  WHERE d.listaPrecioArticulo.articulo = a" +
                ")";

        List<Articulo> articulos = em.createQuery(jpql, Articulo.class).getResultList();

        for (Articulo a : articulos) {
            System.out.println("Artículo sin ventas registradas: " + a.getDenominacion() + " (" + a.getCodigo() + ")");
        }
    }

    //EJERCICIO 20
    public static void ejercicio20(EntityManager em) {
        System.out.println("--- Ejercicio 20 ---");
        String jpql = "SELECT f.numero, f.importeTotal, " +
                "CASE " +
                "  WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' " +
                "  WHEN f.importeTotal >= 10000 AND f.importeTotal <= 50000 THEN 'MEDIO VALOR' " +
                "  ELSE 'BAJO VALOR' " +
                "END " +
                "FROM FacturaVenta f " +
                "ORDER BY f.importeTotal DESC";

        List<Object[]> resultados = em.createQuery(jpql, Object[].class).getResultList();

        for (Object[] fila : resultados) {
            Long numero = (Long) fila[0];
            Double total = (Double) fila[1];
            String categoria = (String) fila[2];
            System.out.println("Factura Nro " + numero + " | Total: $" + total + " | Categoría: " + categoria);
        }
    }



}