package org.example;

import org.example.entities.*;

import javax.persistence.EntityManager;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CargadorDatos {

    public static void cargarDatos(EntityManager em) {
        em.getTransaction().begin();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date ahora = new Date();

            // 1. USUARIOS

            Usuario u1 = new Usuario();
            u1.setUsuario("jperez");
            u1.setClave("1234");
            u1.setNombre("Juan");
            u1.setApellido("Perez");
            em.persist(u1);

            Usuario u2 = new Usuario();
            u2.setUsuario("mgomez");
            u2.setClave("pass");
            u2.setNombre("Maria");
            u2.setApellido("Gomez");
            em.persist(u2);

            // 2. DOMICILIOS, CONTACTOS Y CLIENTES

            Domicilio d1 = new Domicilio();
            d1.setNombreCalle("San Martin");
            d1.setNumeroCalle("1024");
            em.persist(d1);

            Contacto c1 = new Contacto();
            c1.setEmail("contacto@globaltech.com");
            c1.setTelefono("261445566");
            c1.setCelular("2611545678");
            em.persist(c1);

            Cliente cli1 = new Cliente();
            cli1.setDenominacion("Global Tech Solutions SA");
            cli1.setCuitCuil("20-30405060-7");
            cli1.setDomicilio(d1);
            cli1.setContacto(c1);
            cli1.setFechaAlta(ahora);
            cli1.setFechaModificacion(ahora);
            cli1.setUsuarioCarga(u1);
            cli1.setUsuarioModificacion(u1);
            em.persist(cli1);

            Domicilio d2 = new Domicilio();
            d2.setNombreCalle("Belgrano");
            d2.setNumeroCalle("550");
            em.persist(d2);

            Contacto c2 = new Contacto();
            c2.setEmail("ana.lopez@gmail.com");
            c2.setTelefono("261778899");
            c2.setCelular("2611599887");
            em.persist(c2);

            Cliente cli2 = new Cliente();
            cli2.setDenominacion("Ana Laura Lopez");
            cli2.setCuitCuil("27-28394012-4");
            cli2.setDomicilio(d2);
            cli2.setContacto(c2);
            cli2.setFechaAlta(ahora);
            cli2.setFechaModificacion(ahora);
            cli2.setUsuarioCarga(u1);
            cli2.setUsuarioModificacion(u1);
            em.persist(cli2);

            // 3. PUNTOS DE VENTA (N° 1, 2 y 5)

            PuntoVenta pv1 = new PuntoVenta();
            pv1.setNumero(1);
            pv1.setDescripcion("Sucursal Mendoza Centro");
            pv1.setTipoEmision("Electronica");
            pv1.setDomicilioComercial("San Martin 100");
            pv1.setFechaAlta(ahora);
            pv1.setFechaModificacion(ahora);
            pv1.setUsuarioCarga(u1);
            pv1.setUsuarioModificacion(u1);
            em.persist(pv1);

            PuntoVenta pv2 = new PuntoVenta();
            pv2.setNumero(2);
            pv2.setDescripcion("Sucursal Godoy Cruz");
            pv2.setTipoEmision("Electronica");
            pv2.setDomicilioComercial("Rivadavia 450");
            pv2.setFechaAlta(ahora);
            pv2.setFechaModificacion(ahora);
            pv2.setUsuarioCarga(u1);
            pv2.setUsuarioModificacion(u1);
            em.persist(pv2);

            PuntoVenta pv5 = new PuntoVenta();
            pv5.setNumero(5);
            pv5.setDescripcion("Punto Web Ecommerce");
            pv5.setTipoEmision("Web");
            pv5.setDomicilioComercial("Servidor Cloud");
            pv5.setFechaAlta(ahora);
            pv5.setFechaModificacion(ahora);
            pv5.setUsuarioCarga(u2);
            pv5.setUsuarioModificacion(u2);
            em.persist(pv5);

            // 4. RUBROS Y MARCAS

            Rubro rElectronica = new Rubro();
            rElectronica.setCodigo(100);
            rElectronica.setDenominacion("Electrónica");
            rElectronica.setFechaAlta(ahora);
            rElectronica.setFechaModificacion(ahora);
            rElectronica.setUsuarioCarga(u1);
            rElectronica.setUsuarioModificacion(u1);
            em.persist(rElectronica);

            Rubro rInformatica = new Rubro();
            rInformatica.setCodigo(200);
            rInformatica.setDenominacion("Informática");
            rInformatica.setFechaAlta(ahora);
            rInformatica.setFechaModificacion(ahora);
            rInformatica.setUsuarioCarga(u1);
            rInformatica.setUsuarioModificacion(u1);
            em.persist(rInformatica);

            Marca mLogitech = new Marca();
            mLogitech.setCodigo(10);
            mLogitech.setDenominacion("Logitech");
            mLogitech.setFechaAlta(ahora);
            mLogitech.setFechaModificacion(ahora);
            mLogitech.setUsuarioCarga(u1);
            mLogitech.setUsuarioModificacion(u1);
            em.persist(mLogitech);

            Marca mSamsung = new Marca();
            mSamsung.setCodigo(20);
            mSamsung.setDenominacion("Samsung");
            mSamsung.setFechaAlta(ahora);
            mSamsung.setFechaModificacion(ahora);
            mSamsung.setUsuarioCarga(u1);
            mSamsung.setUsuarioModificacion(u1);
            em.persist(mSamsung);

            Marca mSony = new Marca(); // Sin ventas (para NOT EXISTS)
            mSony.setCodigo(30);
            mSony.setDenominacion("Sony");
            mSony.setFechaAlta(ahora);
            mSony.setFechaModificacion(ahora);
            mSony.setUsuarioCarga(u1);
            mSony.setUsuarioModificacion(u1);
            em.persist(mSony);

            // 5. ARTÍCULOS Y LISTAS DE PRECIOS

            ListaPrecio lp = new ListaPrecio();
            lp.setCodigo("LP-PUBLICO");
            lp.setDenominacion("Lista General Público");
            lp.setFechaAlta(ahora);
            lp.setFechaModificacion(ahora);
            lp.setUsuarioCarga(u1);
            lp.setUsuarioModificacion(u1);
            em.persist(lp);

            // Art 1: Mouse Logitech (Electrónica)
            Articulo aMouse = new Articulo();
            aMouse.setCodigo("ART-LOG-01");
            aMouse.setDenominacion("Mouse Inalámbrico M170");
            aMouse.setRubro(rElectronica);
            aMouse.setMarca(mLogitech);
            aMouse.setFechaAlta(ahora);
            aMouse.setFechaModificacion(ahora);
            aMouse.setUsuarioCarga(u1);
            aMouse.setUsuarioModificacion(u1);
            em.persist(aMouse);

            ListaPrecioArticulo lpaMouse = new ListaPrecioArticulo();
            lpaMouse.setListaPrecio(lp);
            lpaMouse.setArticulo(aMouse);
            lpaMouse.setPrecioVenta(8000.0);
            lpaMouse.setFechaAlta(ahora);
            lpaMouse.setFechaModificacion(ahora);
            lpaMouse.setUsuarioCarga(u1);
            lpaMouse.setUsuarioModificacion(u1);
            em.persist(lpaMouse);

            // Art 2: Monitor Samsung (Electrónica)
            Articulo aMonitor = new Articulo();
            aMonitor.setCodigo("ART-SAM-01");
            aMonitor.setDenominacion("Monitor Curvo 24 pulgadas");
            aMonitor.setRubro(rElectronica);
            aMonitor.setMarca(mSamsung);
            aMonitor.setFechaAlta(ahora);
            aMonitor.setFechaModificacion(ahora);
            aMonitor.setUsuarioCarga(u1);
            aMonitor.setUsuarioModificacion(u1);
            em.persist(aMonitor);

            ListaPrecioArticulo lpaMonitor = new ListaPrecioArticulo();
            lpaMonitor.setListaPrecio(lp);
            lpaMonitor.setArticulo(aMonitor);
            lpaMonitor.setPrecioVenta(80000.0);
            lpaMonitor.setFechaAlta(ahora);
            lpaMonitor.setFechaModificacion(ahora);
            lpaMonitor.setUsuarioCarga(u1);
            lpaMonitor.setUsuarioModificacion(u1);
            em.persist(lpaMonitor);

            // Art 3: Genérico sin marca (para LEFT JOIN)
            Articulo aCable = new Articulo();
            aCable.setCodigo("ART-GEN-01");
            aCable.setDenominacion("Cable HDMI 2.0 Macho-Macho 2m");
            aCable.setRubro(rInformatica);
            aCable.setMarca(null);
            aCable.setFechaAlta(ahora);
            aCable.setFechaModificacion(ahora);
            aCable.setUsuarioCarga(u1);
            aCable.setUsuarioModificacion(u1);
            em.persist(aCable);

            ListaPrecioArticulo lpaCable = new ListaPrecioArticulo();
            lpaCable.setListaPrecio(lp);
            lpaCable.setArticulo(aCable);
            lpaCable.setPrecioVenta(3500.0);
            lpaCable.setFechaAlta(ahora);
            lpaCable.setFechaModificacion(ahora);
            lpaCable.setUsuarioCarga(u1);
            lpaCable.setUsuarioModificacion(u1);
            em.persist(lpaCable);

            // Art 4: Sony nunca vendido (para NOT EXISTS)
            Articulo aAuriSony = new Articulo();
            aAuriSony.setCodigo("ART-SON-01");
            aAuriSony.setDenominacion("Auriculares Sony WH-1000XM4");
            aAuriSony.setRubro(rElectronica);
            aAuriSony.setMarca(mSony);
            aAuriSony.setFechaAlta(ahora);
            aAuriSony.setFechaModificacion(ahora);
            aAuriSony.setUsuarioCarga(u1);
            aAuriSony.setUsuarioModificacion(u1);
            em.persist(aAuriSony);

            ListaPrecioArticulo lpaAuriSony = new ListaPrecioArticulo();
            lpaAuriSony.setListaPrecio(lp);
            lpaAuriSony.setArticulo(aAuriSony);
            lpaAuriSony.setPrecioVenta(150000.0);
            lpaAuriSony.setFechaAlta(ahora);
            lpaAuriSony.setFechaModificacion(ahora);
            lpaAuriSony.setUsuarioCarga(u1);
            lpaAuriSony.setUsuarioModificacion(u1);
            em.persist(lpaAuriSony);

            // 6. FACTURAS DE VENTA

            // F1: $8.000 (<10k, BAJO VALOR)
            FacturaVenta f1 = crearFactura(101L, sdf.parse("2024-01-15"), pv1, "EMITIDA", 8000.0, null, u1, ahora);
            f1.addDetalle(crearDetalle(lpaMouse, 1.0, 8000.0, 8000.0));
            em.persist(f1);

            // F2: $24.000 (10k - 50k, MEDIO VALOR)
            FacturaVenta f2 = crearFactura(102L, sdf.parse("2024-02-10"), pv1, "EMITIDA", 24000.0, null, u1, ahora);
            f2.addDetalle(crearDetalle(lpaMouse, 3.0, 8000.0, 24000.0));
            em.persist(f2);

            // F3: $80.000 (>50k, ALTO VALOR)
            FacturaVenta f3 = crearFactura(103L, sdf.parse("2024-03-05"), pv2, "EMITIDA", 80000.0, null, u1, ahora);
            f3.addDetalle(crearDetalle(lpaMonitor, 1.0, 80000.0, 80000.0));
            em.persist(f3);

            // F4: $16.000 (Anulada con fechaAnulacion)
            FacturaVenta f4 = crearFactura(104L, sdf.parse("2024-03-20"), pv2, "ANULADA", 16000.0, sdf.parse("2024-03-22"), u1, ahora);
            f4.addDetalle(crearDetalle(lpaMouse, 2.0, 8000.0, 16000.0));
            em.persist(f4);

            // F5: $7.000 (Cobrada)
            FacturaVenta f5 = crearFactura(105L, sdf.parse("2024-04-12"), pv5, "COBRADA", 7000.0, null, u1, ahora);
            f5.addDetalle(crearDetalle(lpaCable, 2.0, 3500.0, 7000.0));
            em.persist(f5);

            // F6: $88.000 (Pendiente, lleva a jperez a 6 facturas)
            FacturaVenta f6 = crearFactura(106L, sdf.parse("2024-05-01"), pv5, "PENDIENTE", 88000.0, null, u1, ahora);
            f6.addDetalle(crearDetalle(lpaMonitor, 1.0, 80000.0, 80000.0));
            f6.addDetalle(crearDetalle(lpaMouse, 1.0, 8000.0, 8000.0));
            em.persist(f6);

            // F7: $10.500 (Usuario mgomez)
            FacturaVenta f7 = crearFactura(107L, sdf.parse("2024-05-18"), pv1, "EMITIDA", 10500.0, null, u2, ahora);
            f7.addDetalle(crearDetalle(lpaCable, 3.0, 3500.0, 10500.0));
            em.persist(f7);

            em.getTransaction().commit();
            System.out.println("-> Base recreada y datos cargados exitosamente.");
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        }
    }

    private static FacturaVenta crearFactura(Long numero, Date fechaEmision, PuntoVenta pv, String estado,
                                             double importeTotal, Date fechaAnulacion, Usuario usuario, Date ahora) {
        FacturaVenta f = new FacturaVenta();
        f.setNumero(numero);
        f.setFechaEmision(fechaEmision);
        f.setPuntoVenta(pv);
        f.setEstado(estado);
        f.setImporteTotal(importeTotal);
        f.setImporteCobrado(estado.equals("COBRADA") ? importeTotal : 0.0);
        f.setImporteSaldo(estado.equals("COBRADA") ? 0.0 : importeTotal);
        f.setFechaAnulacion(fechaAnulacion);
        f.setFechaAlta(ahora);
        f.setFechaModificacion(ahora);
        f.setUsuarioCarga(usuario);
        f.setUsuarioModificacion(usuario);
        return f;
    }

    private static FacturaVentaDetalle crearDetalle(ListaPrecioArticulo lpa, double cant, double unitario, double subtotal) {
        FacturaVentaDetalle det = new FacturaVentaDetalle();
        det.setListaPrecioArticulo(lpa);
        det.setDescripcion(lpa.getArticulo().getDenominacion());
        det.setCantidad(cant);
        det.setPrecioUnitario(unitario);
        det.setImporteSubtotal(subtotal);
        det.setImporteNeto(subtotal / 1.21);
        det.setImporteIva(subtotal - (subtotal / 1.21));
        det.setPorcentajeBonificacion(0.0);
        return det;
    }
}