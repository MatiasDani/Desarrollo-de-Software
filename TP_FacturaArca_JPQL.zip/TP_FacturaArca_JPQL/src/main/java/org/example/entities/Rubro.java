package org.example.entities;

import javax.persistence.*;

@Entity
@Table(name = "rubros")
public class Rubro extends AuditoriaApp {
    @Column(nullable = false)
    private String denominacion;
    @Column(nullable = false)
    private Integer codigo;

    public Rubro() {
    }

    public String getDenominacion() {
        return denominacion;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }
}